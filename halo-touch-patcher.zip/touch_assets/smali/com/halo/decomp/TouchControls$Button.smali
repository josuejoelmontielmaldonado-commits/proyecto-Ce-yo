.class final Lcom/halo/decomp/TouchControls$Button;
.super Ljava/lang/Object;
.source "TouchControls.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/halo/decomp/TouchControls;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1a
    name = "Button"
.end annotation


# instance fields
.field final bottomDp:F

.field final code:I

.field cx:F

.field cy:F

.field fx:F

.field fy:F

.field hidden:Z

.field final icon:I

.field key:I

.field final label:Ljava/lang/String;

.field lastX:F

.field lastY:F

.field final leftDp:F

.field pointer:I

.field r:F

.field final radiusDp:F

.field final rightDp:F

.field scale:F

.field final topDp:F


# direct methods
.method constructor <init>(Ljava/lang/String;IFFFFF)V
    .registers 9

    .line 154
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, -0x1

    .line 143
    iput v0, p0, Lcom/halo/decomp/TouchControls$Button;->pointer:I

    const/high16 v0, 0x7fc00000    # Float.NaN

    .line 149
    iput v0, p0, Lcom/halo/decomp/TouchControls$Button;->fx:F

    .line 150
    iput v0, p0, Lcom/halo/decomp/TouchControls$Button;->fy:F

    const/high16 v0, 0x3f800000    # 1.0f

    .line 151
    iput v0, p0, Lcom/halo/decomp/TouchControls$Button;->scale:F

    const/4 v0, 0x0

    .line 152
    iput-boolean v0, p0, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    .line 155
    iput-object p1, p0, Lcom/halo/decomp/TouchControls$Button;->label:Ljava/lang/String;

    .line 156
    iput p2, p0, Lcom/halo/decomp/TouchControls$Button;->code:I

    .line 157
    # invokes: Lcom/halo/decomp/TouchControls;->keyFor(I)I
    invoke-static {p2}, Lcom/halo/decomp/TouchControls;->access$000(I)I

    move-result p2

    iput p2, p0, Lcom/halo/decomp/TouchControls$Button;->key:I

    .line 158
    # invokes: Lcom/halo/decomp/TouchControls;->iconFor(Ljava/lang/String;)I
    invoke-static {p1}, Lcom/halo/decomp/TouchControls;->access$100(Ljava/lang/String;)I

    move-result p1

    iput p1, p0, Lcom/halo/decomp/TouchControls$Button;->icon:I

    .line 159
    iput p3, p0, Lcom/halo/decomp/TouchControls$Button;->leftDp:F

    .line 160
    iput p4, p0, Lcom/halo/decomp/TouchControls$Button;->rightDp:F

    .line 161
    iput p5, p0, Lcom/halo/decomp/TouchControls$Button;->topDp:F

    .line 162
    iput p6, p0, Lcom/halo/decomp/TouchControls$Button;->bottomDp:F

    .line 163
    iput p7, p0, Lcom/halo/decomp/TouchControls$Button;->radiusDp:F

    return-void
.end method
