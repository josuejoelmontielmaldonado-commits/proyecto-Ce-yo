.class Lcom/halo/decomp/TouchControls$1;
.super Ljava/lang/Object;
.source "TouchControls.java"

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/halo/decomp/TouchControls;-><init>(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/halo/decomp/TouchControls;


# direct methods
.method constructor <init>(Lcom/halo/decomp/TouchControls;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 237
    iput-object p1, p0, Lcom/halo/decomp/TouchControls$1;->this$0:Lcom/halo/decomp/TouchControls;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public run()V
    .registers 4

    .line 240
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$1;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->active:Z
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$200(Lcom/halo/decomp/TouchControls;)Z

    move-result v0

    if-eqz v0, :cond_28

    iget-object v0, p0, Lcom/halo/decomp/TouchControls$1;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->attached:Z
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$300(Lcom/halo/decomp/TouchControls;)Z

    move-result v0

    if-nez v0, :cond_28

    .line 241
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$1;->this$0:Lcom/halo/decomp/TouchControls;

    # invokes: Lcom/halo/decomp/TouchControls;->push()V
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$400(Lcom/halo/decomp/TouchControls;)V

    .line 242
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$1;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->attached:Z
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$300(Lcom/halo/decomp/TouchControls;)Z

    move-result v0

    if-nez v0, :cond_28

    .line 243
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$1;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->handler:Landroid/os/Handler;
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$500(Lcom/halo/decomp/TouchControls;)Landroid/os/Handler;

    move-result-object v0

    const-wide/16 v1, 0x1f4

    invoke-virtual {v0, p0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_28
    return-void
.end method
