.class final Lcom/halo/decomp/TouchIcons;
.super Ljava/lang/Object;
.source "TouchIcons.java"


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/halo/decomp/TouchIcons$Pen;
    }
.end annotation


# static fields
.field static final BACK:I = 0xa

.field static final CROUCH:I = 0x9

.field static final FIRE:I = 0x0

.field static final GRENADE:I = 0x5

.field static final GRENADE_SWAP:I = 0x6

.field static final JUMP:I = 0x1

.field static final LIGHT:I = 0x8

.field static final MELEE:I = 0x3

.field static final PAUSE:I = 0xb

.field static final RELOAD:I = 0x2

.field static final SWAP_WEAPON:I = 0x4

.field static final ZOOM:I = 0x7


# direct methods
.method private constructor <init>()V
    .locals 0

    .prologue
    .line 21
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method private static chevron(Lcom/halo/decomp/TouchIcons$Pen;FFFFZ)V
    .locals 3

    .prologue
    .line 116
    if-eqz p5, :cond_0

    const/high16 v0, 0x3f800000    # 1.0f

    .line 117
    :goto_0
    sub-float v1, p1, p3

    mul-float v2, v0, p4

    add-float/2addr v2, p2

    invoke-interface {p0, v1, v2, p1, p2}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 118
    add-float v1, p1, p3

    mul-float/2addr v0, p4

    add-float/2addr v0, p2

    invoke-interface {p0, p1, p2, v1, v0}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 119
    return-void

    .line 116
    :cond_0
    const/high16 v0, -0x40800000    # -1.0f

    goto :goto_0
.end method

.method static draw(Lcom/halo/decomp/TouchIcons$Pen;IFFF)V
    .locals 16

    .prologue
    .line 24
    packed-switch p1, :pswitch_data_0

    .line 113
    :cond_0
    :goto_0
    return-void

    .line 26
    :pswitch_0
    const v4, 0x3eae147b    # 0.34f

    mul-float v4, v4, p4

    const/4 v5, 0x0

    move-object/from16 v0, p0

    move/from16 v1, p2

    move/from16 v2, p3

    invoke-interface {v0, v1, v2, v4, v5}, Lcom/halo/decomp/TouchIcons$Pen;->circle(FFFZ)V

    .line 27
    const v4, 0x3d8f5c29    # 0.07f

    mul-float v4, v4, p4

    const/4 v5, 0x1

    move-object/from16 v0, p0

    move/from16 v1, p2

    move/from16 v2, p3

    invoke-interface {v0, v1, v2, v4, v5}, Lcom/halo/decomp/TouchIcons$Pen;->circle(FFFZ)V

    .line 28
    const/high16 v4, 0x3f000000    # 0.5f

    mul-float v4, v4, p4

    const v5, 0x3f3d70a4    # 0.74f

    mul-float v5, v5, p4

    .line 29
    sub-float v6, p2, v5

    sub-float v7, p2, v4

    move-object/from16 v0, p0

    move/from16 v1, p3

    move/from16 v2, p3

    invoke-interface {v0, v6, v1, v7, v2}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 30
    add-float v6, p2, v4

    add-float v7, p2, v5

    move-object/from16 v0, p0

    move/from16 v1, p3

    move/from16 v2, p3

    invoke-interface {v0, v6, v1, v7, v2}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 31
    sub-float v6, p3, v5

    sub-float v7, p3, v4

    move-object/from16 v0, p0

    move/from16 v1, p2

    move/from16 v2, p2

    invoke-interface {v0, v1, v6, v2, v7}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 32
    add-float v4, v4, p3

    add-float v5, v5, p3

    move-object/from16 v0, p0

    move/from16 v1, p2

    move/from16 v2, p2

    invoke-interface {v0, v1, v4, v2, v5}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    goto :goto_0

    .line 36
    :pswitch_1
    const v4, 0x3e8f5c29    # 0.28f

    mul-float v4, v4, p4

    sub-float v6, p3, v4

    const v4, 0x3ed70a3d    # 0.42f

    mul-float v7, v4, p4

    const v4, 0x3e99999a    # 0.3f

    mul-float v8, v4, p4

    const/4 v9, 0x1

    move-object/from16 v4, p0

    move/from16 v5, p2

    invoke-static/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons;->chevron(Lcom/halo/decomp/TouchIcons$Pen;FFFFZ)V

    .line 37
    const v4, 0x3d75c28f    # 0.06f

    mul-float v4, v4, p4

    add-float v6, p3, v4

    const v4, 0x3ed70a3d    # 0.42f

    mul-float v7, v4, p4

    const v4, 0x3e99999a    # 0.3f

    mul-float v8, v4, p4

    const/4 v9, 0x1

    move-object/from16 v4, p0

    move/from16 v5, p2

    invoke-static/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons;->chevron(Lcom/halo/decomp/TouchIcons$Pen;FFFFZ)V

    goto/16 :goto_0

    .line 40
    :pswitch_2
    const v4, 0x3e6147ae    # 0.22f

    mul-float v4, v4, p4

    sub-float v6, p3, v4

    const v4, 0x3ed70a3d    # 0.42f

    mul-float v7, v4, p4

    const v4, 0x3e99999a    # 0.3f

    mul-float v8, v4, p4

    const/4 v9, 0x0

    move-object/from16 v4, p0

    move/from16 v5, p2

    invoke-static/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons;->chevron(Lcom/halo/decomp/TouchIcons$Pen;FFFFZ)V

    .line 41
    const v4, 0x3df5c28f    # 0.12f

    mul-float v4, v4, p4

    add-float v6, p3, v4

    const v4, 0x3ed70a3d    # 0.42f

    mul-float v7, v4, p4

    const v4, 0x3e99999a    # 0.3f

    mul-float v8, v4, p4

    const/4 v9, 0x0

    move-object/from16 v4, p0

    move/from16 v5, p2

    invoke-static/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons;->chevron(Lcom/halo/decomp/TouchIcons$Pen;FFFFZ)V

    goto/16 :goto_0

    .line 44
    :pswitch_3
    const v4, 0x3ecccccd    # 0.4f

    mul-float v7, v4, p4

    const/high16 v8, 0x41c80000    # 25.0f

    const v9, 0x438e8000    # 285.0f

    add-float v4, v8, v9

    float-to-double v4, v4

    invoke-static {v4, v5}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v4

    double-to-float v10, v4

    move-object/from16 v4, p0

    move/from16 v5, p2

    move/from16 v6, p3

    .line 45
    invoke-interface/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons$Pen;->arc(FFFFF)V

    .line 46
    float-to-double v4, v10

    invoke-static {v4, v5}, Ljava/lang/Math;->cos(D)D

    move-result-wide v4

    double-to-float v4, v4

    mul-float/2addr v4, v7

    add-float v5, p2, v4

    float-to-double v8, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v4, v8

    mul-float/2addr v4, v7

    add-float v6, p3, v4

    .line 48
    float-to-double v8, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->sin(D)D

    move-result-wide v8

    double-to-float v4, v8

    neg-float v7, v4

    float-to-double v8, v10

    invoke-static {v8, v9}, Ljava/lang/Math;->cos(D)D

    move-result-wide v8

    double-to-float v8, v8

    const v4, 0x3e6147ae    # 0.22f

    mul-float v9, v4, p4

    move-object/from16 v4, p0

    invoke-static/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons;->head(Lcom/halo/decomp/TouchIcons$Pen;FFFFF)V

    goto/16 :goto_0

    .line 52
    :pswitch_4
    const/4 v4, 0x0

    move v5, v4

    :goto_1
    const/16 v4, 0x8

    if-ge v5, v4, :cond_0

    .line 53
    mul-int/lit8 v4, v5, 0x2d

    int-to-double v6, v4

    const-wide v8, 0x4036800000000000L    # 22.5

    add-double/2addr v6, v8

    invoke-static {v6, v7}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v6

    .line 54
    rem-int/lit8 v4, v5, 0x2

    if-nez v4, :cond_1

    const v4, 0x3f3851ec    # 0.72f

    :goto_2
    mul-float v4, v4, p4

    const v8, 0x3e23d70a    # 0.16f

    mul-float v8, v8, p4

    .line 55
    invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D

    move-result-wide v10

    double-to-float v9, v10

    mul-float/2addr v9, v8

    add-float v9, v9, p2

    invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    double-to-float v10, v10

    mul-float/2addr v8, v10

    add-float v8, v8, p3

    .line 56
    invoke-static {v6, v7}, Ljava/lang/Math;->cos(D)D

    move-result-wide v10

    double-to-float v10, v10

    mul-float/2addr v10, v4

    add-float v10, v10, p2

    invoke-static {v6, v7}, Ljava/lang/Math;->sin(D)D

    move-result-wide v6

    double-to-float v6, v6

    mul-float/2addr v4, v6

    add-float v4, v4, p3

    .line 55
    move-object/from16 v0, p0

    invoke-interface {v0, v9, v8, v10, v4}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 52
    add-int/lit8 v4, v5, 0x1

    move v5, v4

    goto :goto_1

    .line 54
    :cond_1
    const/high16 v4, 0x3f000000    # 0.5f

    goto :goto_2

    .line 61
    :pswitch_5
    const v4, 0x3ee147ae    # 0.44f

    mul-float v10, v4, p4

    const v4, 0x3e4ccccd    # 0.2f

    mul-float v11, v4, p4

    .line 62
    sub-float v4, p2, v10

    sub-float v5, p3, v11

    add-float v6, p2, v10

    sub-float v7, p3, v11

    move-object/from16 v0, p0

    invoke-interface {v0, v4, v5, v6, v7}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 63
    add-float v5, p2, v10

    sub-float v6, p3, v11

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v8, 0x0

    const v4, 0x3e4ccccd    # 0.2f

    mul-float v9, v4, p4

    move-object/from16 v4, p0

    invoke-static/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons;->head(Lcom/halo/decomp/TouchIcons$Pen;FFFFF)V

    .line 64
    add-float v4, p2, v10

    add-float v5, p3, v11

    sub-float v6, p2, v10

    add-float v7, p3, v11

    move-object/from16 v0, p0

    invoke-interface {v0, v4, v5, v6, v7}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 65
    sub-float v5, p2, v10

    add-float v6, p3, v11

    const/high16 v7, -0x40800000    # -1.0f

    const/4 v8, 0x0

    const v4, 0x3e4ccccd    # 0.2f

    mul-float v9, v4, p4

    move-object/from16 v4, p0

    invoke-static/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons;->head(Lcom/halo/decomp/TouchIcons$Pen;FFFFF)V

    goto/16 :goto_0

    .line 69
    :pswitch_6
    const/high16 v4, 0x3f800000    # 1.0f

    move-object/from16 v0, p0

    move/from16 v1, p2

    move/from16 v2, p3

    move/from16 v3, p4

    invoke-static {v0, v1, v2, v3, v4}, Lcom/halo/decomp/TouchIcons;->grenade(Lcom/halo/decomp/TouchIcons$Pen;FFFF)V

    goto/16 :goto_0

    .line 72
    :pswitch_7
    const v4, 0x3e23d70a    # 0.16f

    mul-float v4, v4, p4

    sub-float v4, p3, v4

    const v5, 0x3f28f5c3    # 0.66f

    move-object/from16 v0, p0

    move/from16 v1, p2

    move/from16 v2, p4

    invoke-static {v0, v1, v4, v2, v5}, Lcom/halo/decomp/TouchIcons;->grenade(Lcom/halo/decomp/TouchIcons$Pen;FFFF)V

    .line 73
    const v4, 0x3eae147b    # 0.34f

    mul-float v10, v4, p4

    const/high16 v4, 0x3f000000    # 0.5f

    mul-float v4, v4, p4

    add-float v6, p3, v4

    .line 74
    sub-float v4, p2, v10

    add-float v5, p2, v10

    move-object/from16 v0, p0

    invoke-interface {v0, v4, v6, v5, v6}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 75
    add-float v5, p2, v10

    const/high16 v7, 0x3f800000    # 1.0f

    const/4 v8, 0x0

    const v4, 0x3e19999a    # 0.15f

    mul-float v9, v4, p4

    move-object/from16 v4, p0

    invoke-static/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons;->head(Lcom/halo/decomp/TouchIcons$Pen;FFFFF)V

    .line 76
    sub-float v5, p2, v10

    const/high16 v7, -0x40800000    # -1.0f

    const/4 v8, 0x0

    const v4, 0x3e19999a    # 0.15f

    mul-float v9, v4, p4

    move-object/from16 v4, p0

    invoke-static/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons;->head(Lcom/halo/decomp/TouchIcons$Pen;FFFFF)V

    goto/16 :goto_0

    .line 80
    :pswitch_8
    const v4, 0x3dcccccd    # 0.1f

    mul-float v4, v4, p4

    sub-float v4, p2, v4

    const v5, 0x3dcccccd    # 0.1f

    mul-float v5, v5, p4

    sub-float v5, p3, v5

    const v6, 0x3e99999a    # 0.3f

    mul-float v6, v6, p4

    .line 81
    const/4 v7, 0x0

    move-object/from16 v0, p0

    invoke-interface {v0, v4, v5, v6, v7}, Lcom/halo/decomp/TouchIcons$Pen;->circle(FFFZ)V

    .line 82
    const v7, 0x3f3851ec    # 0.72f

    mul-float/2addr v7, v6

    add-float/2addr v7, v4

    const v8, 0x3f3851ec    # 0.72f

    mul-float/2addr v6, v8

    add-float/2addr v6, v5

    const v8, 0x3eeb851f    # 0.46f

    mul-float v8, v8, p4

    add-float v8, v8, p2

    const v9, 0x3eeb851f    # 0.46f

    mul-float v9, v9, p4

    add-float v9, v9, p3

    move-object/from16 v0, p0

    invoke-interface {v0, v7, v6, v8, v9}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 83
    const v6, 0x3e051eb8    # 0.13f

    mul-float v6, v6, p4

    sub-float v6, v4, v6

    const v7, 0x3e051eb8    # 0.13f

    mul-float v7, v7, p4

    add-float/2addr v7, v4

    move-object/from16 v0, p0

    invoke-interface {v0, v6, v5, v7, v5}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 84
    const v6, 0x3e051eb8    # 0.13f

    mul-float v6, v6, p4

    sub-float v6, v5, v6

    const v7, 0x3e051eb8    # 0.13f

    mul-float v7, v7, p4

    add-float/2addr v5, v7

    move-object/from16 v0, p0

    invoke-interface {v0, v4, v6, v4, v5}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    goto/16 :goto_0

    .line 88
    :pswitch_9
    const v4, 0x3da3d70a    # 0.08f

    mul-float v4, v4, p4

    sub-float v5, p3, v4

    const v4, 0x3e75c28f    # 0.24f

    mul-float v4, v4, p4

    .line 89
    const/4 v6, 0x0

    move-object/from16 v0, p0

    move/from16 v1, p2

    invoke-interface {v0, v1, v5, v4, v6}, Lcom/halo/decomp/TouchIcons$Pen;->circle(FFFZ)V

    .line 90
    const v6, 0x3df5c28f    # 0.12f

    mul-float v6, v6, p4

    sub-float v6, p2, v6

    const v7, 0x3e851eb8    # 0.26f

    mul-float v7, v7, p4

    add-float v7, v7, p3

    const v8, 0x3df5c28f    # 0.12f

    mul-float v8, v8, p4

    add-float v8, v8, p2

    const v9, 0x3e851eb8    # 0.26f

    mul-float v9, v9, p4

    add-float v9, v9, p3

    move-object/from16 v0, p0

    invoke-interface {v0, v6, v7, v8, v9}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 91
    const v6, 0x3da3d70a    # 0.08f

    mul-float v6, v6, p4

    sub-float v6, p2, v6

    const v7, 0x3ecccccd    # 0.4f

    mul-float v7, v7, p4

    add-float v7, v7, p3

    const v8, 0x3da3d70a    # 0.08f

    mul-float v8, v8, p4

    add-float v8, v8, p2

    const v9, 0x3ecccccd    # 0.4f

    mul-float v9, v9, p4

    add-float v9, v9, p3

    move-object/from16 v0, p0

    invoke-interface {v0, v6, v7, v8, v9}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 92
    const v6, 0x3dcccccd    # 0.1f

    mul-float v6, v6, p4

    add-float/2addr v6, v4

    const v7, 0x3e75c28f    # 0.24f

    mul-float v7, v7, p4

    add-float/2addr v7, v4

    .line 93
    const/4 v4, 0x5

    new-array v8, v4, [I

    fill-array-data v8, :array_0

    array-length v9, v8

    const/4 v4, 0x0

    :goto_3
    if-ge v4, v9, :cond_0

    aget v10, v8, v4

    .line 94
    int-to-double v10, v10

    invoke-static {v10, v11}, Ljava/lang/Math;->toRadians(D)D

    move-result-wide v10

    .line 95
    invoke-static {v10, v11}, Ljava/lang/Math;->cos(D)D

    move-result-wide v12

    double-to-float v12, v12

    mul-float/2addr v12, v6

    add-float v12, v12, p2

    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    move-result-wide v14

    double-to-float v13, v14

    mul-float/2addr v13, v6

    add-float/2addr v13, v5

    .line 96
    invoke-static {v10, v11}, Ljava/lang/Math;->cos(D)D

    move-result-wide v14

    double-to-float v14, v14

    mul-float/2addr v14, v7

    add-float v14, v14, p2

    invoke-static {v10, v11}, Ljava/lang/Math;->sin(D)D

    move-result-wide v10

    double-to-float v10, v10

    mul-float/2addr v10, v7

    add-float/2addr v10, v5

    .line 95
    move-object/from16 v0, p0

    invoke-interface {v0, v12, v13, v14, v10}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 93
    add-int/lit8 v4, v4, 0x1

    goto :goto_3

    .line 101
    :pswitch_a
    const v4, 0x3ed70a3d    # 0.42f

    mul-float v4, v4, p4

    .line 102
    add-float v5, p2, v4

    sub-float v6, p2, v4

    move-object/from16 v0, p0

    move/from16 v1, p3

    move/from16 v2, p3

    invoke-interface {v0, v5, v1, v6, v2}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 103
    sub-float v5, p2, v4

    const/high16 v7, -0x40800000    # -1.0f

    const/4 v8, 0x0

    const v4, 0x3e851eb8    # 0.26f

    mul-float v9, v4, p4

    move-object/from16 v4, p0

    move/from16 v6, p3

    invoke-static/range {v4 .. v9}, Lcom/halo/decomp/TouchIcons;->head(Lcom/halo/decomp/TouchIcons$Pen;FFFFF)V

    goto/16 :goto_0

    .line 107
    :pswitch_b
    const v4, 0x3ea3d70a    # 0.32f

    mul-float v4, v4, p4

    sub-float v4, p2, v4

    const v5, 0x3eb851ec    # 0.36f

    mul-float v5, v5, p4

    sub-float v5, p3, v5

    const v6, 0x3da3d70a    # 0.08f

    mul-float v6, v6, p4

    sub-float v6, p2, v6

    const v7, 0x3eb851ec    # 0.36f

    mul-float v7, v7, p4

    add-float v7, v7, p3

    move-object/from16 v0, p0

    invoke-interface {v0, v4, v5, v6, v7}, Lcom/halo/decomp/TouchIcons$Pen;->rect(FFFF)V

    .line 108
    const v4, 0x3da3d70a    # 0.08f

    mul-float v4, v4, p4

    add-float v4, v4, p2

    const v5, 0x3eb851ec    # 0.36f

    mul-float v5, v5, p4

    sub-float v5, p3, v5

    const v6, 0x3ea3d70a    # 0.32f

    mul-float v6, v6, p4

    add-float v6, v6, p2

    const v7, 0x3eb851ec    # 0.36f

    mul-float v7, v7, p4

    add-float v7, v7, p3

    move-object/from16 v0, p0

    invoke-interface {v0, v4, v5, v6, v7}, Lcom/halo/decomp/TouchIcons$Pen;->rect(FFFF)V

    goto/16 :goto_0

    .line 24
    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
        :pswitch_1
        :pswitch_3
        :pswitch_4
        :pswitch_5
        :pswitch_6
        :pswitch_7
        :pswitch_8
        :pswitch_9
        :pswitch_2
        :pswitch_a
        :pswitch_b
    .end packed-switch

    .line 93
    :array_0
    .array-data 4
        -0x5a
        -0x2d
        -0x87
        0x0
        0xb4
    .end array-data
.end method

.method private static grenade(Lcom/halo/decomp/TouchIcons$Pen;FFFF)V
    .locals 10

    .prologue
    const/4 v9, 0x0

    const v8, 0x3e99999a    # 0.3f

    const/high16 v7, 0x3f000000    # 0.5f

    const v6, 0x3de147ae    # 0.11f

    .line 134
    const v0, 0x3eae147b    # 0.34f

    mul-float/2addr v0, p3

    mul-float/2addr v0, p4

    const v1, 0x3df5c28f    # 0.12f

    mul-float/2addr v1, p3

    mul-float/2addr v1, p4

    add-float/2addr v1, p2

    .line 135
    invoke-interface {p0, p1, v1, v0, v9}, Lcom/halo/decomp/TouchIcons$Pen;->circle(FFFZ)V

    .line 136
    mul-float v2, v6, p3

    mul-float/2addr v2, p4

    sub-float v2, p1, v2

    sub-float v3, v1, v0

    mul-float v4, v6, p3

    mul-float/2addr v4, p4

    sub-float v4, p1, v4

    mul-float v5, v7, p3

    mul-float/2addr v5, p4

    sub-float v5, p2, v5

    invoke-interface {p0, v2, v3, v4, v5}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 137
    mul-float v2, v6, p3

    mul-float/2addr v2, p4

    add-float/2addr v2, p1

    sub-float v0, v1, v0

    mul-float v1, v6, p3

    mul-float/2addr v1, p4

    add-float/2addr v1, p1

    mul-float v3, v7, p3

    mul-float/2addr v3, p4

    sub-float v3, p2, v3

    invoke-interface {p0, v2, v0, v1, v3}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 138
    mul-float v0, v6, p3

    mul-float/2addr v0, p4

    sub-float v0, p1, v0

    mul-float v1, v7, p3

    mul-float/2addr v1, p4

    sub-float v1, p2, v1

    mul-float v2, v6, p3

    mul-float/2addr v2, p4

    add-float/2addr v2, p1

    mul-float v3, v7, p3

    mul-float/2addr v3, p4

    sub-float v3, p2, v3

    invoke-interface {p0, v0, v1, v2, v3}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 139
    mul-float v0, v6, p3

    mul-float/2addr v0, p4

    add-float/2addr v0, p1

    const v1, 0x3ee147ae    # 0.44f

    mul-float/2addr v1, p3

    mul-float/2addr v1, p4

    sub-float v1, p2, v1

    const v2, 0x3ed70a3d    # 0.42f

    mul-float/2addr v2, p3

    mul-float/2addr v2, p4

    add-float/2addr v2, p1

    mul-float v3, v8, p3

    mul-float/2addr v3, p4

    sub-float v3, p2, v3

    invoke-interface {p0, v0, v1, v2, v3}, Lcom/halo/decomp/TouchIcons$Pen;->line(FFFF)V

    .line 140
    mul-float v0, v8, p3

    mul-float/2addr v0, p4

    sub-float v0, p1, v0

    mul-float v1, v7, p3

    mul-float/2addr v1, p4

    sub-float v1, p2, v1

    const v2, 0x3dcccccd    # 0.1f

    mul-float/2addr v2, p3

    mul-float/2addr v2, p4

    invoke-interface {p0, v0, v1, v2, v9}, Lcom/halo/decomp/TouchIcons$Pen;->circle(FFFZ)V

    .line 141
    return-void
.end method

.method private static head(Lcom/halo/decomp/TouchIcons$Pen;FFFFF)V
    .locals 8

    .prologue
    const v6, 0x3f19999a    # 0.6f

    const v7, 0x3f333333    # 0.7f

    .line 123
    float-to-double v0, p3

    float-to-double v2, p4

    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v0

    double-to-float v0, v0

    .line 124
    div-float v1, p3, v0

    .line 125
    div-float v0, p4, v0

    .line 126
    neg-float v2, v0

    .line 127
    const/4 v3, 0x6

    new-array v3, v3, [F

    const/4 v4, 0x0

    mul-float v5, v1, p5

    mul-float/2addr v5, v6

    add-float/2addr v5, p1

    aput v5, v3, v4

    const/4 v4, 0x1

    mul-float v5, v0, p5

    mul-float/2addr v5, v6

    add-float/2addr v5, p2

    aput v5, v3, v4

    const/4 v4, 0x2

    mul-float v5, v1, p5

    mul-float/2addr v5, v7

    sub-float v5, p1, v5

    mul-float v6, v2, p5

    add-float/2addr v5, v6

    aput v5, v3, v4

    const/4 v4, 0x3

    mul-float v5, v0, p5

    mul-float/2addr v5, v7

    sub-float v5, p2, v5

    mul-float v6, v1, p5

    add-float/2addr v5, v6

    aput v5, v3, v4

    const/4 v4, 0x4

    mul-float v5, v1, p5

    mul-float/2addr v5, v7

    sub-float v5, p1, v5

    mul-float/2addr v2, p5

    sub-float v2, v5, v2

    aput v2, v3, v4

    const/4 v2, 0x5

    mul-float/2addr v0, p5

    mul-float/2addr v0, v7

    sub-float v0, p2, v0

    mul-float/2addr v1, p5

    sub-float/2addr v0, v1

    aput v0, v3, v2

    invoke-interface {p0, v3}, Lcom/halo/decomp/TouchIcons$Pen;->polygon([F)V

    .line 131
    return-void
.end method
