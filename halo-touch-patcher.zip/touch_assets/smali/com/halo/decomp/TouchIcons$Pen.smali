.class interface abstract Lcom/halo/decomp/TouchIcons$Pen;
.super Ljava/lang/Object;
.source "TouchIcons.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/halo/decomp/TouchIcons;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x608
    name = "Pen"
.end annotation


# virtual methods
.method public abstract arc(FFFFF)V
.end method

.method public abstract circle(FFFZ)V
.end method

.method public abstract line(FFFF)V
.end method

.method public abstract polygon([F)V
.end method

.method public abstract rect(FFFF)V
.end method
