.class Lcom/halo/decomp/TouchControls$7;
.super Ljava/lang/Object;
.source "TouchControls.java"

# interfaces
.implements Landroid/widget/CompoundButton$OnCheckedChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/halo/decomp/TouchControls;->openSettings()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/halo/decomp/TouchControls;


# direct methods
.method constructor <init>(Lcom/halo/decomp/TouchControls;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 960
    iput-object p1, p0, Lcom/halo/decomp/TouchControls$7;->this$0:Lcom/halo/decomp/TouchControls;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onCheckedChanged(Landroid/widget/CompoundButton;Z)V
    .registers 3

    .line 963
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$7;->this$0:Lcom/halo/decomp/TouchControls;

    # setter for: Lcom/halo/decomp/TouchControls;->gyroInvertY:Z
    invoke-static {p1, p2}, Lcom/halo/decomp/TouchControls;->access$1802(Lcom/halo/decomp/TouchControls;Z)Z

    .line 964
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$7;->this$0:Lcom/halo/decomp/TouchControls;

    # invokes: Lcom/halo/decomp/TouchControls;->saveSettings()V
    invoke-static {p1}, Lcom/halo/decomp/TouchControls;->access$700(Lcom/halo/decomp/TouchControls;)V

    return-void
.end method
