.class public Lcom/halo/decomp/TouchControls;
.super Landroid/view/View;
.source "TouchControls.java"

# interfaces
.implements Landroid/hardware/input/InputManager$InputDeviceListener;
.implements Landroid/hardware/SensorEventListener;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/halo/decomp/TouchControls$Button;,
        Lcom/halo/decomp/TouchControls$CanvasPen;,
        Lcom/halo/decomp/TouchControls$Seek;
    }
.end annotation


# static fields
.field private static final A:I = 0x0

.field private static final ARROW_ON:F = 0.6f

.field private static final B:I = 0x1

.field private static final BACK:I = 0x4

.field private static final BAR_ITEMS:I = 0x4

.field private static final DISC:I = 0x22000000

.field private static final DISC_PRESSED:I = 0x55ffffff

.field private static final EDIT_BG:I = -0x33efdfd0

.field private static final EDIT_HIDDEN:I = 0x66ff8a80

.field private static final EDIT_SELECTED:I = -0x2ab1

.field private static final GYRO_PIXELS_PER_RADIAN:F = 600.0f

.field private static final ICON:I = -0x22000001

.field private static final ICON_SHADOW:I = 0x66000000

.field private static final KEY_ON:F = 0.35f

.field private static final L1:I = 0x9

.field private static final L3:I = 0x7

.field private static final LOOK_GAIN:F = 1.1f

.field private static final LT:I = -0x1

.field private static final PREFS:Ljava/lang/String; = "halotouch"

.field private static final R1:I = 0xa

.field private static final R3:I = 0x8

.field private static final RING:I = 0x55ffffff

.field private static final RT:I = -0x2

.field private static final START:I = 0x6

.field private static final STICK_BASE:I = 0x30ffffff

.field private static final STICK_KNOB:I = -0x7f000001

.field private static final X:I = 0x2

.field private static final Y:I = 0x3


# instance fields
.field private active:Z

.field private attached:Z

.field private final buttons:[Lcom/halo/decomp/TouchControls$Button;

.field private dialogOpen:Z

.field private final dp:F

.field private dragDX:F

.field private dragDY:F

.field private dragPointer:I

.field private editMode:Z

.field private final fill:Landroid/graphics/Paint;

.field private first:Z

.field private gearPointer:I

.field private gyroInvertX:Z

.field private gyroInvertY:Z

.field private gyroOn:Z

.field private gyroPrevRight:F

.field private gyroPrevRotation:I

.field private gyroPrevTime:J

.field private gyroPrevUp:F

.field private gyroRegistered:Z

.field private gyroSens:F

.field private gyroSensor:Landroid/hardware/Sensor;

.field private final handler:Landroid/os/Handler;

.field private final icon:Landroid/graphics/Paint;

.field private invertY:Z

.field private final keysDown:Ljava/util/HashSet;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashSet<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field private lookPointer:I

.field private lookSens:F

.field private lookX:F

.field private lookY:F

.field private mouseState:I

.field private moveDX:F

.field private moveDY:F

.field private movePointer:I

.field private moveX:F

.field private moveY:F

.field private opacity:F

.field private final pen:Lcom/halo/decomp/TouchControls$CanvasPen;

.field private final prefs:Landroid/content/SharedPreferences;

.field private final retry:Ljava/lang/Runnable;

.field private selected:Lcom/halo/decomp/TouchControls$Button;

.field private sensors:Landroid/hardware/SensorManager;

.field private size:F

.field private final stroke:Landroid/graphics/Paint;

.field private final text:Landroid/graphics/Paint;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    .line 129
    const-string v0, "halotouch"

    invoke-static {v0}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .registers 26

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    .line 214
    invoke-direct/range {p0 .. p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/high16 v2, 0x3f800000    # 1.0f

    .line 98
    iput v2, v0, Lcom/halo/decomp/TouchControls;->size:F

    .line 99
    iput v2, v0, Lcom/halo/decomp/TouchControls;->lookSens:F

    const/4 v3, 0x0

    .line 100
    iput-boolean v3, v0, Lcom/halo/decomp/TouchControls;->invertY:Z

    .line 101
    iput v2, v0, Lcom/halo/decomp/TouchControls;->opacity:F

    .line 105
    iput-boolean v3, v0, Lcom/halo/decomp/TouchControls;->gyroOn:Z

    .line 106
    iput v2, v0, Lcom/halo/decomp/TouchControls;->gyroSens:F

    .line 107
    iput-boolean v3, v0, Lcom/halo/decomp/TouchControls;->gyroInvertX:Z

    .line 108
    iput-boolean v3, v0, Lcom/halo/decomp/TouchControls;->gyroInvertY:Z

    .line 111
    iput-boolean v3, v0, Lcom/halo/decomp/TouchControls;->gyroRegistered:Z

    const-wide/16 v4, 0x0

    .line 112
    iput-wide v4, v0, Lcom/halo/decomp/TouchControls;->gyroPrevTime:J

    const/4 v2, -0x1

    .line 113
    iput v2, v0, Lcom/halo/decomp/TouchControls;->gyroPrevRotation:I

    const/4 v4, 0x0

    .line 114
    iput v4, v0, Lcom/halo/decomp/TouchControls;->gyroPrevUp:F

    .line 115
    iput v4, v0, Lcom/halo/decomp/TouchControls;->gyroPrevRight:F

    .line 118
    iput v2, v0, Lcom/halo/decomp/TouchControls;->gearPointer:I

    .line 119
    iput-boolean v3, v0, Lcom/halo/decomp/TouchControls;->editMode:Z

    const/4 v4, 0x0

    .line 120
    iput-object v4, v0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    .line 121
    iput v2, v0, Lcom/halo/decomp/TouchControls;->dragPointer:I

    .line 124
    iput-boolean v3, v0, Lcom/halo/decomp/TouchControls;->dialogOpen:Z

    const/16 v5, 0xc

    .line 216
    new-array v5, v5, [Lcom/halo/decomp/TouchControls$Button;

    new-instance v14, Lcom/halo/decomp/TouchControls$Button;

    const/high16 v12, 0x42e60000    # 115.0f

    const/high16 v13, 0x42380000    # 46.0f

    const-string v7, "FIRE"

    const/4 v8, -0x2

    const/high16 v23, 0x7fc00000    # Float.NaN

    const/high16 v10, 0x42be0000    # 95.0f

    move-object v6, v14

    move/from16 v9, v23

    move/from16 v11, v23

    invoke-direct/range {v6 .. v13}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    aput-object v14, v5, v3

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const/high16 v21, 0x42340000    # 45.0f

    const/high16 v22, 0x41f00000    # 30.0f

    const-string v16, "JUMP"

    const/16 v17, 0x0

    const/high16 v19, 0x43430000    # 195.0f

    move-object v15, v6

    move/from16 v18, v23

    move/from16 v20, v23

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/4 v7, 0x1

    aput-object v6, v5, v7

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const/high16 v21, 0x43160000    # 150.0f

    const-string v16, "USE"

    const/16 v17, 0x2

    const/high16 v19, 0x434d0000    # 205.0f

    move-object v15, v6

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/4 v8, 0x2

    aput-object v6, v5, v8

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const/high16 v21, 0x43570000    # 215.0f

    const/high16 v22, 0x41e00000    # 28.0f

    const-string v16, "MELEE"

    const/16 v17, 0x1

    const/high16 v19, 0x42c80000    # 100.0f

    move-object v15, v6

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/4 v8, 0x3

    aput-object v6, v5, v8

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const/high16 v22, 0x41b00000    # 22.0f

    const-string v16, "WPN"

    const/16 v17, 0x3

    const/high16 v19, 0x42180000    # 38.0f

    move-object v15, v6

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/4 v8, 0x4

    aput-object v6, v5, v8

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const/high16 v21, 0x42480000    # 50.0f

    const/high16 v22, 0x41d00000    # 26.0f

    const-string v16, "GREN"

    const/16 v17, -0x1

    const/high16 v19, 0x420c0000    # 35.0f

    move-object v15, v6

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/4 v9, 0x5

    aput-object v6, v5, v9

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const/high16 v20, 0x42200000    # 40.0f

    const/high16 v22, 0x41c00000    # 24.0f

    const-string v16, "GRN2"

    const/16 v17, 0xa

    const/high16 v19, 0x43480000    # 200.0f

    move-object v15, v6

    move/from16 v21, v23

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/4 v9, 0x6

    aput-object v6, v5, v9

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const-string v16, "ZOOM"

    const/16 v17, 0x8

    const/high16 v19, 0x42700000    # 60.0f

    move-object v15, v6

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/4 v9, 0x7

    aput-object v6, v5, v9

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const-string v16, "LIGHT"

    const/16 v17, 0x9

    const/high16 v18, 0x42700000    # 60.0f

    move-object v15, v6

    move/from16 v19, v23

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/16 v9, 0x8

    aput-object v6, v5, v9

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const-string v16, "CROUCH"

    const/16 v17, 0x7

    const/high16 v18, 0x43020000    # 130.0f

    move-object v15, v6

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/16 v9, 0x9

    aput-object v6, v5, v9

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const/high16 v20, 0x41f00000    # 30.0f

    const/high16 v22, 0x41a00000    # 20.0f

    const-string v16, "BACK"

    const/16 v17, 0x4

    move-object v15, v6

    move/from16 v18, v23

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/16 v9, 0xa

    aput-object v6, v5, v9

    new-instance v6, Lcom/halo/decomp/TouchControls$Button;

    const-string v16, "START"

    const/16 v17, 0x6

    move-object v15, v6

    invoke-direct/range {v15 .. v22}, Lcom/halo/decomp/TouchControls$Button;-><init>(Ljava/lang/String;IFFFFF)V

    const/16 v9, 0xb

    aput-object v6, v5, v9

    iput-object v5, v0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    .line 229
    new-instance v5, Landroid/graphics/Paint;

    invoke-direct {v5, v7}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v5, v0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    .line 230
    new-instance v6, Landroid/graphics/Paint;

    invoke-direct {v6, v7}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v6, v0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    .line 231
    new-instance v9, Landroid/graphics/Paint;

    invoke-direct {v9, v7}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v9, v0, Lcom/halo/decomp/TouchControls;->text:Landroid/graphics/Paint;

    .line 232
    new-instance v10, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v11

    invoke-direct {v10, v11}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    iput-object v10, v0, Lcom/halo/decomp/TouchControls;->handler:Landroid/os/Handler;

    .line 233
    iput v2, v0, Lcom/halo/decomp/TouchControls;->movePointer:I

    .line 234
    iput v2, v0, Lcom/halo/decomp/TouchControls;->lookPointer:I

    .line 235
    new-instance v10, Ljava/util/HashSet;

    invoke-direct {v10}, Ljava/util/HashSet;-><init>()V

    iput-object v10, v0, Lcom/halo/decomp/TouchControls;->keysDown:Ljava/util/HashSet;

    .line 236
    iput-boolean v7, v0, Lcom/halo/decomp/TouchControls;->active:Z

    .line 237
    new-instance v10, Lcom/halo/decomp/TouchControls$1;

    invoke-direct {v10, v0}, Lcom/halo/decomp/TouchControls$1;-><init>(Lcom/halo/decomp/TouchControls;)V

    iput-object v10, v0, Lcom/halo/decomp/TouchControls;->retry:Ljava/lang/Runnable;

    .line 248
    iput-boolean v7, v0, Lcom/halo/decomp/TouchControls;->first:Z

    .line 249
    new-instance v10, Landroid/graphics/Paint;

    invoke-direct {v10, v7}, Landroid/graphics/Paint;-><init>(I)V

    iput-object v10, v0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    .line 250
    new-instance v7, Lcom/halo/decomp/TouchControls$CanvasPen;

    invoke-direct {v7, v0, v4}, Lcom/halo/decomp/TouchControls$CanvasPen;-><init>(Lcom/halo/decomp/TouchControls;Lcom/halo/decomp/TouchControls$1;)V

    iput-object v7, v0, Lcom/halo/decomp/TouchControls;->pen:Lcom/halo/decomp/TouchControls$CanvasPen;

    .line 251
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    invoke-virtual {v4}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object v4

    iget v4, v4, Landroid/util/DisplayMetrics;->density:F

    iput v4, v0, Lcom/halo/decomp/TouchControls;->dp:F

    .line 252
    sget-object v7, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v5, v7}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 253
    sget-object v5, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v6, v5}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/high16 v5, 0x40000000    # 2.0f

    mul-float/2addr v5, v4

    .line 254
    invoke-virtual {v6, v5}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 255
    sget-object v5, Landroid/graphics/Paint$Align;->CENTER:Landroid/graphics/Paint$Align;

    invoke-virtual {v9, v5}, Landroid/graphics/Paint;->setTextAlign(Landroid/graphics/Paint$Align;)V

    .line 256
    invoke-virtual {v9, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/high16 v2, 0x41300000    # 11.0f

    mul-float/2addr v4, v2

    .line 257
    invoke-virtual {v9, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    .line 258
    const-string v2, "halotouch"

    invoke-virtual {v1, v2, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    iput-object v2, v0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    .line 259
    invoke-direct/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->loadSettings()V

    .line 260
    const-string v2, "sensor"

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    .line 261
    instance-of v2, v1, Landroid/hardware/SensorManager;

    if-eqz v2, :cond_1a4

    .line 262
    check-cast v1, Landroid/hardware/SensorManager;

    iput-object v1, v0, Lcom/halo/decomp/TouchControls;->sensors:Landroid/hardware/SensorManager;

    .line 263
    invoke-virtual {v1, v8}, Landroid/hardware/SensorManager;->getDefaultSensor(I)Landroid/hardware/Sensor;

    move-result-object v1

    iput-object v1, v0, Lcom/halo/decomp/TouchControls;->gyroSensor:Landroid/hardware/Sensor;

    :cond_1a4
    return-void
.end method

.method static synthetic access$000(I)I
    .registers 1

    .line 41
    invoke-static {p0}, Lcom/halo/decomp/TouchControls;->keyFor(I)I

    move-result p0

    return p0
.end method

.method static synthetic access$100(Ljava/lang/String;)I
    .registers 1

    .line 41
    invoke-static {p0}, Lcom/halo/decomp/TouchControls;->iconFor(Ljava/lang/String;)I

    move-result p0

    return p0
.end method

.method static synthetic access$1000(F)Ljava/lang/String;
    .registers 1

    .line 41
    invoke-static {p0}, Lcom/halo/decomp/TouchControls;->pct(F)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1100(Lcom/halo/decomp/TouchControls;)V
    .registers 1

    .line 41
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->layout()V

    return-void
.end method

.method static synthetic access$1200(Lcom/halo/decomp/TouchControls;)F
    .registers 1

    .line 41
    iget p0, p0, Lcom/halo/decomp/TouchControls;->lookSens:F

    return p0
.end method

.method static synthetic access$1202(Lcom/halo/decomp/TouchControls;F)F
    .registers 2

    .line 41
    iput p1, p0, Lcom/halo/decomp/TouchControls;->lookSens:F

    return p1
.end method

.method static synthetic access$1300(FFF)F
    .registers 3

    .line 41
    invoke-static {p0, p1, p2}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result p0

    return p0
.end method

.method static synthetic access$1400(F)Ljava/lang/String;
    .registers 1

    .line 41
    invoke-static {p0}, Lcom/halo/decomp/TouchControls;->times(F)Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method static synthetic access$1502(Lcom/halo/decomp/TouchControls;Z)Z
    .registers 2

    .line 41
    iput-boolean p1, p0, Lcom/halo/decomp/TouchControls;->gyroOn:Z

    return p1
.end method

.method static synthetic access$1600(Lcom/halo/decomp/TouchControls;)F
    .registers 1

    .line 41
    iget p0, p0, Lcom/halo/decomp/TouchControls;->gyroSens:F

    return p0
.end method

.method static synthetic access$1602(Lcom/halo/decomp/TouchControls;F)F
    .registers 2

    .line 41
    iput p1, p0, Lcom/halo/decomp/TouchControls;->gyroSens:F

    return p1
.end method

.method static synthetic access$1702(Lcom/halo/decomp/TouchControls;Z)Z
    .registers 2

    .line 41
    iput-boolean p1, p0, Lcom/halo/decomp/TouchControls;->gyroInvertX:Z

    return p1
.end method

.method static synthetic access$1802(Lcom/halo/decomp/TouchControls;Z)Z
    .registers 2

    .line 41
    iput-boolean p1, p0, Lcom/halo/decomp/TouchControls;->gyroInvertY:Z

    return p1
.end method

.method static synthetic access$1902(Lcom/halo/decomp/TouchControls;Z)Z
    .registers 2

    .line 41
    iput-boolean p1, p0, Lcom/halo/decomp/TouchControls;->invertY:Z

    return p1
.end method

.method static synthetic access$200(Lcom/halo/decomp/TouchControls;)Z
    .registers 1

    .line 41
    iget-boolean p0, p0, Lcom/halo/decomp/TouchControls;->active:Z

    return p0
.end method

.method static synthetic access$2000(Lcom/halo/decomp/TouchControls;)F
    .registers 1

    .line 41
    iget p0, p0, Lcom/halo/decomp/TouchControls;->opacity:F

    return p0
.end method

.method static synthetic access$2002(Lcom/halo/decomp/TouchControls;F)F
    .registers 2

    .line 41
    iput p1, p0, Lcom/halo/decomp/TouchControls;->opacity:F

    return p1
.end method

.method static synthetic access$2102(Lcom/halo/decomp/TouchControls;Z)Z
    .registers 2

    .line 41
    iput-boolean p1, p0, Lcom/halo/decomp/TouchControls;->dialogOpen:Z

    return p1
.end method

.method static synthetic access$2200(Lcom/halo/decomp/TouchControls;)V
    .registers 1

    .line 41
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->updateGyro()V

    return-void
.end method

.method static synthetic access$2300(Lcom/halo/decomp/TouchControls;)V
    .registers 1

    .line 41
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->confirmReset()V

    return-void
.end method

.method static synthetic access$2400(Lcom/halo/decomp/TouchControls;)V
    .registers 1

    .line 41
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->enterEdit()V

    return-void
.end method

.method static synthetic access$2500(Lcom/halo/decomp/TouchControls;)V
    .registers 1

    .line 41
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->resetSettings()V

    return-void
.end method

.method static synthetic access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;
    .registers 1

    .line 41
    iget-object p0, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    return-object p0
.end method

.method static synthetic access$2700(Lcom/halo/decomp/TouchControls;)F
    .registers 1

    .line 41
    iget p0, p0, Lcom/halo/decomp/TouchControls;->dp:F

    return p0
.end method

.method static synthetic access$300(Lcom/halo/decomp/TouchControls;)Z
    .registers 1

    .line 41
    iget-boolean p0, p0, Lcom/halo/decomp/TouchControls;->attached:Z

    return p0
.end method

.method static synthetic access$400(Lcom/halo/decomp/TouchControls;)V
    .registers 1

    .line 41
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->push()V

    return-void
.end method

.method static synthetic access$500(Lcom/halo/decomp/TouchControls;)Landroid/os/Handler;
    .registers 1

    .line 41
    iget-object p0, p0, Lcom/halo/decomp/TouchControls;->handler:Landroid/os/Handler;

    return-object p0
.end method

.method static synthetic access$700(Lcom/halo/decomp/TouchControls;)V
    .registers 1

    .line 41
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->saveSettings()V

    return-void
.end method

.method static synthetic access$900(Lcom/halo/decomp/TouchControls;)F
    .registers 1

    .line 41
    iget p0, p0, Lcom/halo/decomp/TouchControls;->size:F

    return p0
.end method

.method static synthetic access$902(Lcom/halo/decomp/TouchControls;F)F
    .registers 2

    .line 41
    iput p1, p0, Lcom/halo/decomp/TouchControls;->size:F

    return p1
.end method

.method private static axis(F)I
    .registers 2

    const v0, 0x46fffe00    # 32767.0f

    mul-float/2addr p0, v0

    .line 752
    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    const/16 v0, 0x7fff

    invoke-static {v0, p0}, Ljava/lang/Math;->min(II)I

    move-result p0

    const/16 v0, -0x8000

    invoke-static {v0, p0}, Ljava/lang/Math;->max(II)I

    move-result p0

    return p0
.end method

.method private barAction(I)V
    .registers 7

    if-eqz p1, :cond_17

    const/4 v0, 0x1

    if-ne p1, v0, :cond_6

    goto :goto_17

    :cond_6
    const/4 v1, 0x2

    if-ne p1, v1, :cond_13

    .line 1109
    iget-object p1, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    if-eqz p1, :cond_4e

    .line 1110
    iget-boolean v1, p1, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    xor-int/2addr v0, v1

    iput-boolean v0, p1, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    goto :goto_4e

    .line 1113
    :cond_13
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->exitEdit()V

    return-void

    :cond_17
    :goto_17
    if-nez p1, :cond_1d

    const p1, -0x42333333    # -0.1f

    goto :goto_20

    :cond_1d
    const p1, 0x3dcccccd    # 0.1f

    .line 1102
    :goto_20
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    const/high16 v1, 0x40000000    # 2.0f

    const/high16 v2, 0x3f000000    # 0.5f

    const/high16 v3, 0x41200000    # 10.0f

    if-eqz v0, :cond_3b

    .line 1103
    iget v4, v0, Lcom/halo/decomp/TouchControls$Button;->scale:F

    add-float/2addr v4, p1

    mul-float/2addr v4, v3

    invoke-static {v4}, Ljava/lang/Math;->round(F)I

    move-result p1

    int-to-float p1, p1

    div-float/2addr p1, v3

    invoke-static {p1, v2, v1}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result p1

    iput p1, v0, Lcom/halo/decomp/TouchControls$Button;->scale:F

    goto :goto_4b

    .line 1105
    :cond_3b
    iget v0, p0, Lcom/halo/decomp/TouchControls;->size:F

    add-float/2addr v0, p1

    mul-float/2addr v0, v3

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result p1

    int-to-float p1, p1

    div-float/2addr p1, v3

    invoke-static {p1, v2, v1}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result p1

    iput p1, p0, Lcom/halo/decomp/TouchControls;->size:F

    .line 1107
    :goto_4b
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->layout()V

    .line 1116
    :cond_4e
    :goto_4e
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->saveSettings()V

    .line 1117
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return-void
.end method

.method private barGap()F
    .registers 3

    const/high16 v0, 0x40c00000    # 6.0f

    .line 1070
    iget v1, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v1, v0

    return v1
.end method

.method private barH()F
    .registers 3

    const/high16 v0, 0x42180000    # 38.0f

    .line 1074
    iget v1, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v1, v0

    return v1
.end method

.method private barHit(FF)I
    .registers 8

    .line 1087
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->barTop()F

    move-result v0

    cmpg-float v0, p2, v0

    const/4 v1, -0x1

    if-ltz v0, :cond_3c

    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->barTop()F

    move-result v0

    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->barH()F

    move-result v2

    add-float/2addr v0, v2

    cmpl-float p2, p2, v0

    if-lez p2, :cond_17

    goto :goto_3c

    :cond_17
    const/4 p2, 0x0

    :goto_18
    const/4 v0, 0x4

    if-ge p2, v0, :cond_3c

    .line 1091
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->barLeft()F

    move-result v0

    int-to-float v2, p2

    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->barItemW()F

    move-result v3

    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->barGap()F

    move-result v4

    add-float/2addr v3, v4

    mul-float/2addr v2, v3

    add-float/2addr v0, v2

    cmpl-float v2, p1, v0

    if-ltz v2, :cond_39

    .line 1092
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->barItemW()F

    move-result v2

    add-float/2addr v0, v2

    cmpg-float v0, p1, v0

    if-gtz v0, :cond_39

    return p2

    :cond_39
    add-int/lit8 p2, p2, 0x1

    goto :goto_18

    :cond_3c
    :goto_3c
    return v1
.end method

.method private barItemW()F
    .registers 3

    const/high16 v0, 0x42a80000    # 84.0f

    .line 1066
    iget v1, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v1, v0

    return v1
.end method

.method private barLeft()F
    .registers 4

    const/high16 v0, 0x40800000    # 4.0f

    .line 1078
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->barItemW()F

    move-result v1

    mul-float/2addr v1, v0

    const/high16 v0, 0x40400000    # 3.0f

    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->barGap()F

    move-result v2

    mul-float/2addr v2, v0

    add-float/2addr v1, v2

    .line 1079
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getWidth()I

    move-result v0

    int-to-float v0, v0

    sub-float/2addr v0, v1

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    return v0
.end method

.method private barTop()F
    .registers 3

    .line 1083
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getHeight()I

    move-result v0

    int-to-float v0, v0

    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->barH()F

    move-result v1

    sub-float/2addr v0, v1

    const/high16 v1, 0x40000000    # 2.0f

    div-float/2addr v0, v1

    return v0
.end method

.method private static clamp(FFF)F
    .registers 4

    cmpg-float v0, p0, p1

    if-gez v0, :cond_6

    move p0, p1

    goto :goto_b

    :cond_6
    cmpl-float p1, p0, p2

    if-lez p1, :cond_b

    move p0, p2

    :cond_b
    :goto_b
    return p0
.end method

.method private confirmReset()V
    .registers 4

    .line 1030
    new-instance v0, Landroid/app/AlertDialog$Builder;

    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    .line 1031
    const-string v1, "Restablecer"

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v2, "Se restauran tama\u00f1o, posici\u00f3n, sensibilidad y opacidad de todos los botones."

    .line 1032
    invoke-virtual {v0, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    new-instance v2, Lcom/halo/decomp/TouchControls$13;

    invoke-direct {v2, p0}, Lcom/halo/decomp/TouchControls$13;-><init>(Lcom/halo/decomp/TouchControls;)V

    .line 1033
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const-string v1, "Cancelar"

    const/4 v2, 0x0

    .line 1039
    invoke-virtual {v0, v1, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    .line 1040
    invoke-virtual {v0}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private drawEditBar(Landroid/graphics/Canvas;)V
    .registers 20

    move-object/from16 v0, p0

    move-object/from16 v9, p1

    .line 1301
    invoke-direct/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->barH()F

    move-result v10

    .line 1302
    invoke-direct/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->barTop()F

    move-result v11

    const/4 v12, 0x4

    .line 1303
    new-array v13, v12, [Ljava/lang/String;

    const-string v1, "TAMA\u00d1O \u2212"

    const/4 v2, 0x0

    aput-object v1, v13, v2

    const/4 v1, 0x1

    const-string v3, "TAMA\u00d1O +"

    aput-object v3, v13, v1

    .line 1304
    iget-object v1, v0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    if-eqz v1, :cond_24

    iget-boolean v1, v1, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    if-eqz v1, :cond_24

    const-string v1, "MOSTRAR"

    goto :goto_26

    :cond_24
    const-string v1, "OCULTAR"

    :goto_26
    const/4 v3, 0x2

    aput-object v1, v13, v3

    const/4 v1, 0x3

    const-string v3, "LISTO"

    aput-object v3, v13, v1

    .line 1305
    iget-object v1, v0, Lcom/halo/decomp/TouchControls;->text:Landroid/graphics/Paint;

    const/high16 v3, 0x41300000    # 11.0f

    iget v4, v0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v4, v3

    invoke-virtual {v1, v4}, Landroid/graphics/Paint;->setTextSize(F)V

    move v14, v2

    :goto_39
    const/4 v15, -0x1

    const v1, -0x33efdfd0    # -3.7781696E7f

    const/high16 v16, 0x40000000    # 2.0f

    const/high16 v2, 0x41000000    # 8.0f

    if-ge v14, v12, :cond_91

    .line 1307
    invoke-direct/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->barLeft()F

    move-result v3

    int-to-float v4, v14

    invoke-direct/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->barItemW()F

    move-result v5

    invoke-direct/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->barGap()F

    move-result v6

    add-float/2addr v5, v6

    mul-float/2addr v4, v5

    add-float v17, v3, v4

    .line 1308
    iget-object v3, v0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    invoke-virtual {v3, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 1309
    invoke-direct/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->barItemW()F

    move-result v1

    add-float v4, v17, v1

    add-float v5, v11, v10

    iget v1, v0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float v6, v1, v2

    mul-float v7, v1, v2

    iget-object v8, v0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    move/from16 v2, v17

    move v3, v11

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 1310
    iget-object v1, v0, Lcom/halo/decomp/TouchControls;->text:Landroid/graphics/Paint;

    invoke-virtual {v1, v15}, Landroid/graphics/Paint;->setColor(I)V

    .line 1311
    aget-object v1, v13, v14

    invoke-direct/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->barItemW()F

    move-result v2

    div-float v2, v2, v16

    add-float v2, v17, v2

    div-float v3, v10, v16

    add-float/2addr v3, v11

    const/high16 v4, 0x40800000    # 4.0f

    iget v5, v0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v5, v4

    add-float/2addr v3, v5

    iget-object v4, v0, Lcom/halo/decomp/TouchControls;->text:Landroid/graphics/Paint;

    invoke-virtual {v9, v1, v2, v3, v4}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    add-int/lit8 v14, v14, 0x1

    goto :goto_39

    .line 1314
    :cond_91
    iget-object v3, v0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    if-nez v3, :cond_99

    .line 1315
    const-string v3, "Toca un bot\u00f3n para elegirlo y arr\u00e1stralo. TAMA\u00d1O cambia todos."

    :goto_97
    move-object v10, v3

    goto :goto_cc

    .line 1317
    :cond_99
    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v4, v0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    iget-object v4, v4, Lcom/halo/decomp/TouchControls$Button;->label:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    const-string v4, " \u00b7 tama\u00f1o "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, v0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    iget v4, v4, Lcom/halo/decomp/TouchControls$Button;->scale:F

    invoke-static {v4}, Lcom/halo/decomp/TouchControls;->pct(F)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    iget-object v4, v0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    iget-boolean v4, v4, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    if-eqz v4, :cond_c1

    const-string v4, " \u00b7 oculto"

    goto :goto_c3

    :cond_c1
    const-string v4, ""

    :goto_c3
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    goto :goto_97

    .line 1319
    :goto_cc
    invoke-virtual/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->getWidth()I

    move-result v3

    int-to-float v3, v3

    iget v4, v0, Lcom/halo/decomp/TouchControls;->dp:F

    const/high16 v5, 0x41800000    # 16.0f

    mul-float/2addr v5, v4

    sub-float/2addr v3, v5

    const/high16 v5, 0x43d20000    # 420.0f

    mul-float/2addr v4, v5

    invoke-static {v3, v4}, Ljava/lang/Math;->min(FF)F

    move-result v3

    .line 1320
    invoke-virtual/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->getWidth()I

    move-result v4

    int-to-float v4, v4

    sub-float/2addr v4, v3

    div-float v4, v4, v16

    const/high16 v5, 0x42100000    # 36.0f

    .line 1321
    iget v6, v0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v6, v5

    sub-float/2addr v11, v6

    .line 1322
    iget-object v5, v0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    invoke-virtual {v5, v1}, Landroid/graphics/Paint;->setColor(I)V

    add-float v5, v4, v3

    .line 1323
    iget v1, v0, Lcom/halo/decomp/TouchControls;->dp:F

    const/high16 v3, 0x41e00000    # 28.0f

    mul-float/2addr v3, v1

    add-float v6, v11, v3

    mul-float v7, v1, v2

    mul-float v8, v1, v2

    iget-object v12, v0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    move-object/from16 v1, p1

    move v2, v4

    move v3, v11

    move v4, v5

    move v5, v6

    move v6, v7

    move v7, v8

    move-object v8, v12

    invoke-virtual/range {v1 .. v8}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 1324
    iget-object v1, v0, Lcom/halo/decomp/TouchControls;->text:Landroid/graphics/Paint;

    invoke-virtual {v1, v15}, Landroid/graphics/Paint;->setColor(I)V

    .line 1325
    invoke-virtual/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->getWidth()I

    move-result v1

    int-to-float v1, v1

    div-float v1, v1, v16

    const/high16 v2, 0x41900000    # 18.0f

    iget v3, v0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v3, v2

    add-float/2addr v11, v3

    iget-object v2, v0, Lcom/halo/decomp/TouchControls;->text:Landroid/graphics/Paint;

    invoke-virtual {v9, v10, v1, v11, v2}, Landroid/graphics/Canvas;->drawText(Ljava/lang/String;FFLandroid/graphics/Paint;)V

    return-void
.end method

.method private drawGear(Landroid/graphics/Canvas;)V
    .registers 16

    .line 1281
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->gearX()F

    move-result v0

    .line 1282
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->gearY()F

    move-result v1

    .line 1283
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->gearR()F

    move-result v2

    .line 1284
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    iget v4, p0, Lcom/halo/decomp/TouchControls;->gearPointer:I

    if-ltz v4, :cond_16

    const v4, 0x55ffffff    # 3.518437E13f

    goto :goto_18

    :cond_16
    const/high16 v4, 0x22000000

    :goto_18
    invoke-direct {p0, v4}, Lcom/halo/decomp/TouchControls;->fade(I)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 1285
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1286
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    iget v4, p0, Lcom/halo/decomp/TouchControls;->dp:F

    const/high16 v5, 0x3fc00000    # 1.5f

    mul-float/2addr v4, v5

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1287
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v2, v3}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1288
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    iget v4, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v4, v5

    const v5, 0x3df5c28f    # 0.12f

    mul-float/2addr v5, v2

    invoke-static {v4, v5}, Ljava/lang/Math;->max(FF)F

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1289
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1290
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    const v4, -0x22000001

    invoke-direct {p0, v4}, Lcom/halo/decomp/TouchControls;->fade(I)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    const v3, 0x3eae147b    # 0.34f

    mul-float/2addr v3, v2

    .line 1291
    iget-object v4, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    invoke-virtual {p1, v0, v1, v3, v4}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/4 v3, 0x0

    :goto_60
    const/16 v4, 0x8

    if-ge v3, v4, :cond_96

    int-to-double v4, v3

    const-wide v6, 0x400921fb54442d18L    # Math.PI

    mul-double/2addr v4, v6

    const-wide/high16 v6, 0x4010000000000000L    # 4.0

    div-double/2addr v4, v6

    .line 1294
    invoke-static {v4, v5}, Ljava/lang/Math;->cos(D)D

    move-result-wide v6

    double-to-float v6, v6

    .line 1295
    invoke-static {v4, v5}, Ljava/lang/Math;->sin(D)D

    move-result-wide v4

    double-to-float v4, v4

    mul-float/2addr v6, v2

    const v5, 0x3f051eb8    # 0.52f

    mul-float v7, v6, v5

    add-float v9, v0, v7

    mul-float/2addr v4, v2

    mul-float/2addr v5, v4

    add-float v10, v1, v5

    const v5, 0x3f47ae14    # 0.78f

    mul-float/2addr v6, v5

    add-float v11, v0, v6

    mul-float/2addr v4, v5

    add-float v12, v1, v4

    .line 1296
    iget-object v13, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    move-object v8, p1

    invoke-virtual/range {v8 .. v13}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    add-int/lit8 v3, v3, 0x1

    goto :goto_60

    :cond_96
    return-void
.end method

.method private drawStick(Landroid/graphics/Canvas;IFFFFF)V
    .registers 9

    if-ltz p2, :cond_31

    .line 1330
    iget-object p2, p0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    const v0, 0x30ffffff

    invoke-direct {p0, v0}, Lcom/halo/decomp/TouchControls;->fade(I)I

    move-result v0

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 1331
    iget-object p2, p0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    invoke-virtual {p1, p3, p4, p7, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1332
    iget-object p2, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    invoke-virtual {p1, p3, p4, p7, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1333
    iget-object p2, p0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    const v0, -0x7f000001

    invoke-direct {p0, v0}, Lcom/halo/decomp/TouchControls;->fade(I)I

    move-result v0

    invoke-virtual {p2, v0}, Landroid/graphics/Paint;->setColor(I)V

    mul-float/2addr p5, p7

    add-float/2addr p5, p3

    mul-float/2addr p6, p7

    add-float/2addr p6, p4

    const p2, 0x3ecccccd    # 0.4f

    mul-float/2addr p7, p2

    .line 1334
    iget-object p2, p0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    invoke-virtual {p1, p5, p6, p7, p2}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    :cond_31
    return-void
.end method

.method private editTouch(Landroid/view/MotionEvent;)Z
    .registers 10

    .line 1121
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    .line 1122
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v1

    const/4 v2, 0x1

    if-eqz v0, :cond_90

    if-eq v0, v2, :cond_7e

    const/4 v3, 0x2

    if-eq v0, v3, :cond_1a

    const/4 v3, 0x3

    if-eq v0, v3, :cond_7e

    const/4 v3, 0x5

    if-eq v0, v3, :cond_90

    const/4 v3, 0x6

    if-eq v0, v3, :cond_7e

    return v2

    .line 1149
    :cond_1a
    iget v0, p0, Lcom/halo/decomp/TouchControls;->dragPointer:I

    if-ltz v0, :cond_7a

    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    if-eqz v0, :cond_7a

    const/4 v0, 0x0

    .line 1150
    :goto_23
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v1

    if-ge v0, v1, :cond_7a

    .line 1151
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v1

    iget v3, p0, Lcom/halo/decomp/TouchControls;->dragPointer:I

    if-ne v1, v3, :cond_77

    .line 1152
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getWidth()I

    move-result v1

    .line 1153
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getHeight()I

    move-result v3

    .line 1154
    iget-object v4, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    iget v4, v4, Lcom/halo/decomp/TouchControls$Button;->r:F

    .line 1155
    iget-object v5, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v6

    iget v7, p0, Lcom/halo/decomp/TouchControls;->dragDX:F

    sub-float/2addr v6, v7

    int-to-float v1, v1

    sub-float v7, v1, v4

    invoke-static {v4, v7}, Ljava/lang/Math;->max(FF)F

    move-result v7

    invoke-static {v6, v4, v7}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result v6

    iput v6, v5, Lcom/halo/decomp/TouchControls$Button;->cx:F

    .line 1156
    iget-object v5, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v6

    iget v7, p0, Lcom/halo/decomp/TouchControls;->dragDY:F

    sub-float/2addr v6, v7

    int-to-float v3, v3

    sub-float v7, v3, v4

    invoke-static {v4, v7}, Ljava/lang/Math;->max(FF)F

    move-result v7

    invoke-static {v6, v4, v7}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result v4

    iput v4, v5, Lcom/halo/decomp/TouchControls$Button;->cy:F

    .line 1157
    iget-object v4, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    iget v5, v4, Lcom/halo/decomp/TouchControls$Button;->cx:F

    div-float/2addr v5, v1

    iput v5, v4, Lcom/halo/decomp/TouchControls$Button;->fx:F

    .line 1158
    iget-object v1, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    iget v4, v1, Lcom/halo/decomp/TouchControls$Button;->cy:F

    div-float/2addr v4, v3

    iput v4, v1, Lcom/halo/decomp/TouchControls$Button;->fy:F

    :cond_77
    add-int/lit8 v0, v0, 0x1

    goto :goto_23

    .line 1162
    :cond_7a
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return v2

    .line 1168
    :cond_7e
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result p1

    .line 1169
    iget v0, p0, Lcom/halo/decomp/TouchControls;->dragPointer:I

    if-ne p1, v0, :cond_8c

    const/4 p1, -0x1

    .line 1170
    iput p1, p0, Lcom/halo/decomp/TouchControls;->dragPointer:I

    .line 1171
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->saveSettings()V

    .line 1173
    :cond_8c
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return v2

    .line 1126
    :cond_90
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    .line 1127
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getX(I)F

    move-result v3

    .line 1128
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getY(I)F

    move-result p1

    .line 1129
    invoke-direct {p0, v3, p1}, Lcom/halo/decomp/TouchControls;->barHit(FF)I

    move-result v1

    if-ltz v1, :cond_a6

    .line 1131
    invoke-direct {p0, v1}, Lcom/halo/decomp/TouchControls;->barAction(I)V

    return v2

    .line 1134
    :cond_a6
    iget v1, p0, Lcom/halo/decomp/TouchControls;->dragPointer:I

    if-gez v1, :cond_c2

    .line 1135
    invoke-direct {p0, v3, p1, v2}, Lcom/halo/decomp/TouchControls;->hit(FFZ)Lcom/halo/decomp/TouchControls$Button;

    move-result-object v1

    if-eqz v1, :cond_bf

    .line 1137
    iput-object v1, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    .line 1138
    iput v0, p0, Lcom/halo/decomp/TouchControls;->dragPointer:I

    .line 1139
    iget v0, v1, Lcom/halo/decomp/TouchControls$Button;->cx:F

    sub-float/2addr v3, v0

    iput v3, p0, Lcom/halo/decomp/TouchControls;->dragDX:F

    .line 1140
    iget v0, v1, Lcom/halo/decomp/TouchControls$Button;->cy:F

    sub-float/2addr p1, v0

    iput p1, p0, Lcom/halo/decomp/TouchControls;->dragDY:F

    goto :goto_c2

    :cond_bf
    const/4 p1, 0x0

    .line 1142
    iput-object p1, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    .line 1145
    :cond_c2
    :goto_c2
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return v2
.end method

.method private enterEdit()V
    .registers 2

    const/4 v0, 0x1

    .line 1046
    iput-boolean v0, p0, Lcom/halo/decomp/TouchControls;->editMode:Z

    const/4 v0, 0x0

    .line 1047
    iput-object v0, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    .line 1048
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->releaseAll()V

    .line 1049
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->updateGyro()V

    .line 1050
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return-void
.end method

.method private exitEdit()V
    .registers 2

    const/4 v0, 0x0

    .line 1054
    iput-boolean v0, p0, Lcom/halo/decomp/TouchControls;->editMode:Z

    const/4 v0, 0x0

    .line 1055
    iput-object v0, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    const/4 v0, -0x1

    .line 1056
    iput v0, p0, Lcom/halo/decomp/TouchControls;->dragPointer:I

    .line 1057
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->saveSettings()V

    .line 1058
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->layout()V

    .line 1059
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->releaseAll()V

    .line 1060
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->updateGyro()V

    return-void
.end method

.method private fade(I)I
    .registers 4

    ushr-int/lit8 v0, p1, 0x18

    and-int/lit16 v0, v0, 0xff

    int-to-float v0, v0

    .line 1184
    iget v1, p0, Lcom/halo/decomp/TouchControls;->opacity:F

    mul-float/2addr v0, v1

    invoke-static {v0}, Ljava/lang/Math;->round(F)I

    move-result v0

    shl-int/lit8 v0, v0, 0x18

    const v1, 0xffffff

    and-int/2addr p1, v1

    or-int/2addr p1, v0

    return p1
.end method

.method private gearHit(FF)Z
    .registers 5

    .line 518
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->gearX()F

    move-result v0

    sub-float/2addr p1, v0

    .line 519
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->gearY()F

    move-result v0

    sub-float/2addr p2, v0

    .line 520
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->gearR()F

    move-result v0

    const v1, 0x3fe66666    # 1.8f

    mul-float/2addr v0, v1

    mul-float/2addr p1, p1

    mul-float/2addr p2, p2

    add-float/2addr p1, p2

    mul-float/2addr v0, v0

    cmpg-float p1, p1, v0

    if-gtz p1, :cond_1c

    const/4 p1, 0x1

    goto :goto_1d

    :cond_1c
    const/4 p1, 0x0

    :goto_1d
    return p1
.end method

.method private gearR()F
    .registers 3

    const/high16 v0, 0x41600000    # 14.0f

    .line 514
    iget v1, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v1, v0

    return v1
.end method

.method private gearX()F
    .registers 3

    const/high16 v0, 0x41b00000    # 22.0f

    .line 506
    iget v1, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v1, v0

    return v1
.end method

.method private gearY()F
    .registers 3

    const/high16 v0, 0x41b00000    # 22.0f

    .line 510
    iget v1, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v1, v0

    return v1
.end method

.method private hit(FFZ)Lcom/halo/decomp/TouchControls$Button;
    .registers 10

    const/4 v0, 0x0

    .line 490
    :goto_1
    iget-object v1, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v2, v1

    if-ge v0, v2, :cond_28

    .line 491
    aget-object v1, v1, v0

    .line 492
    iget-boolean v2, v1, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    if-eqz v2, :cond_f

    if-nez p3, :cond_f

    goto :goto_25

    .line 495
    :cond_f
    iget v2, v1, Lcom/halo/decomp/TouchControls$Button;->cx:F

    sub-float v2, p1, v2

    .line 496
    iget v3, v1, Lcom/halo/decomp/TouchControls$Button;->cy:F

    sub-float v3, p2, v3

    .line 497
    iget v4, v1, Lcom/halo/decomp/TouchControls$Button;->r:F

    const/high16 v5, 0x3fa00000    # 1.25f

    mul-float/2addr v4, v5

    mul-float/2addr v2, v2

    mul-float/2addr v3, v3

    add-float/2addr v2, v3

    mul-float/2addr v4, v4

    cmpg-float v2, v2, v4

    if-gtz v2, :cond_25

    return-object v1

    :cond_25
    :goto_25
    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    :cond_28
    const/4 p1, 0x0

    return-object p1
.end method

.method private static iconFor(Ljava/lang/String;)I
    .registers 2

    .line 168
    const-string v0, "FIRE"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_a

    const/4 p0, 0x0

    return p0

    .line 169
    :cond_a
    const-string v0, "JUMP"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_14

    const/4 p0, 0x1

    return p0

    .line 170
    :cond_14
    const-string v0, "USE"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_1e

    const/4 p0, 0x2

    return p0

    .line 171
    :cond_1e
    const-string v0, "MELEE"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_28

    const/4 p0, 0x3

    return p0

    .line 172
    :cond_28
    const-string v0, "WPN"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_32

    const/4 p0, 0x4

    return p0

    .line 173
    :cond_32
    const-string v0, "GREN"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_3c

    const/4 p0, 0x5

    return p0

    .line 174
    :cond_3c
    const-string v0, "GRN2"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_46

    const/4 p0, 0x6

    return p0

    .line 175
    :cond_46
    const-string v0, "ZOOM"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_50

    const/4 p0, 0x7

    return p0

    .line 176
    :cond_50
    const-string v0, "LIGHT"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_5b

    const/16 p0, 0x8

    return p0

    .line 177
    :cond_5b
    const-string v0, "CROUCH"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_66

    const/16 p0, 0x9

    return p0

    .line 178
    :cond_66
    const-string v0, "BACK"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    if-eqz p0, :cond_71

    const/16 p0, 0xa

    return p0

    :cond_71
    const/16 p0, 0xb

    return p0
.end method

.method public static install(Landroid/app/Activity;)V
    .registers 4

    .line 210
    new-instance v0, Lcom/halo/decomp/TouchControls;

    invoke-direct {v0, p0}, Lcom/halo/decomp/TouchControls;-><init>(Landroid/content/Context;)V

    new-instance v1, Landroid/view/ViewGroup$LayoutParams;

    const/4 v2, -0x1

    invoke-direct {v1, v2, v2}, Landroid/view/ViewGroup$LayoutParams;-><init>(II)V

    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->addContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method private static isPhysicalPad(I)Z
    .registers 4

    .line 376
    invoke-static {p0}, Landroid/view/InputDevice;->getDevice(I)Landroid/view/InputDevice;

    move-result-object p0

    const/4 v0, 0x0

    if-eqz p0, :cond_1f

    .line 377
    invoke-virtual {p0}, Landroid/view/InputDevice;->isVirtual()Z

    move-result v1

    if-eqz v1, :cond_e

    goto :goto_1f

    .line 380
    :cond_e
    invoke-virtual {p0}, Landroid/view/InputDevice;->getSources()I

    move-result p0

    const v1, 0x1000010

    and-int v2, p0, v1

    if-ne v2, v1, :cond_1f

    const/16 v1, 0x401

    and-int/2addr p0, v1

    if-ne p0, v1, :cond_1f

    const/4 v0, 0x1

    :cond_1f
    :goto_1f
    return v0
.end method

.method private static keyFor(I)I
    .registers 1

    packed-switch p0, :pswitch_data_24

    :pswitch_3
    const/4 p0, 0x0

    return p0

    :pswitch_5
    const/16 p0, 0x34

    return p0

    :pswitch_8
    const/16 p0, 0x2d

    return p0

    :pswitch_b
    const/16 p0, 0x36

    return p0

    :pswitch_e
    const/16 p0, 0x1f

    return p0

    :pswitch_11
    const/16 p0, 0x6f

    return p0

    :pswitch_14
    const/16 p0, 0x83

    return p0

    :pswitch_17
    const/16 p0, 0x3d

    return p0

    :pswitch_1a
    const/16 p0, 0x21

    return p0

    :pswitch_1d
    const/16 p0, 0x22

    return p0

    :pswitch_20
    const/16 p0, 0x3e

    return p0

    nop

    :pswitch_data_24
    .packed-switch 0x0
        :pswitch_20
        :pswitch_1d
        :pswitch_1a
        :pswitch_17
        :pswitch_14
        :pswitch_3
        :pswitch_11
        :pswitch_e
        :pswitch_b
        :pswitch_8
        :pswitch_5
    .end packed-switch
.end method

.method private layout()V
    .registers 11

    .line 449
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getWidth()I

    move-result v0

    .line 450
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getHeight()I

    move-result v1

    if-lez v0, :cond_c8

    if-gtz v1, :cond_e

    goto/16 :goto_c8

    :cond_e
    const/4 v2, 0x0

    .line 454
    :goto_f
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v4, v3

    if-ge v2, v4, :cond_c8

    .line 455
    aget-object v3, v3, v2

    .line 456
    iget v4, v3, Lcom/halo/decomp/TouchControls$Button;->radiusDp:F

    iget v5, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v4, v5

    iget v5, p0, Lcom/halo/decomp/TouchControls;->size:F

    mul-float/2addr v4, v5

    iget v5, v3, Lcom/halo/decomp/TouchControls$Button;->scale:F

    mul-float/2addr v4, v5

    iput v4, v3, Lcom/halo/decomp/TouchControls$Button;->r:F

    .line 459
    iget v4, v3, Lcom/halo/decomp/TouchControls$Button;->fx:F

    invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z

    move-result v4

    if-nez v4, :cond_3c

    iget v4, v3, Lcom/halo/decomp/TouchControls$Button;->fy:F

    invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z

    move-result v4

    if-nez v4, :cond_3c

    .line 460
    iget v4, v3, Lcom/halo/decomp/TouchControls$Button;->fx:F

    int-to-float v5, v0

    mul-float/2addr v4, v5

    .line 461
    iget v5, v3, Lcom/halo/decomp/TouchControls$Button;->fy:F

    int-to-float v6, v1

    mul-float/2addr v5, v6

    goto :goto_a0

    .line 463
    :cond_3c
    iget v4, v3, Lcom/halo/decomp/TouchControls$Button;->leftDp:F

    invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z

    move-result v4

    const/high16 v5, 0x40000000    # 2.0f

    if-nez v4, :cond_4c

    .line 464
    iget v4, v3, Lcom/halo/decomp/TouchControls$Button;->leftDp:F

    iget v6, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v4, v6

    goto :goto_5e

    .line 465
    :cond_4c
    iget v4, v3, Lcom/halo/decomp/TouchControls$Button;->rightDp:F

    invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z

    move-result v4

    if-nez v4, :cond_5c

    int-to-float v4, v0

    .line 466
    iget v6, v3, Lcom/halo/decomp/TouchControls$Button;->rightDp:F

    iget v7, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v6, v7

    sub-float/2addr v4, v6

    goto :goto_5e

    :cond_5c
    int-to-float v4, v0

    div-float/2addr v4, v5

    .line 470
    :goto_5e
    iget v6, v3, Lcom/halo/decomp/TouchControls$Button;->topDp:F

    invoke-static {v6}, Ljava/lang/Float;->isNaN(F)Z

    move-result v6

    if-nez v6, :cond_6f

    .line 471
    iget v6, v3, Lcom/halo/decomp/TouchControls$Button;->topDp:F

    iget v7, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v6, v7

    iget v7, v3, Lcom/halo/decomp/TouchControls$Button;->r:F

    add-float/2addr v6, v7

    goto :goto_81

    .line 472
    :cond_6f
    iget v6, v3, Lcom/halo/decomp/TouchControls$Button;->bottomDp:F

    invoke-static {v6}, Ljava/lang/Float;->isNaN(F)Z

    move-result v6

    if-nez v6, :cond_7f

    int-to-float v6, v1

    .line 473
    iget v7, v3, Lcom/halo/decomp/TouchControls$Button;->bottomDp:F

    iget v8, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v7, v8

    sub-float/2addr v6, v7

    goto :goto_81

    :cond_7f
    int-to-float v6, v1

    div-float/2addr v6, v5

    .line 477
    :goto_81
    iget v7, v3, Lcom/halo/decomp/TouchControls$Button;->code:I

    const/4 v8, 0x4

    const/high16 v9, 0x41a00000    # 20.0f

    if-ne v7, v8, :cond_91

    int-to-float v4, v0

    div-float/2addr v4, v5

    .line 478
    iget v7, v3, Lcom/halo/decomp/TouchControls$Button;->r:F

    iget v8, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v8, v9

    add-float/2addr v7, v8

    sub-float/2addr v4, v7

    .line 480
    :cond_91
    iget v7, v3, Lcom/halo/decomp/TouchControls$Button;->code:I

    const/4 v8, 0x6

    if-ne v7, v8, :cond_9f

    int-to-float v4, v0

    div-float/2addr v4, v5

    .line 481
    iget v5, v3, Lcom/halo/decomp/TouchControls$Button;->r:F

    iget v7, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v7, v9

    add-float/2addr v5, v7

    add-float/2addr v4, v5

    :cond_9f
    move v5, v6

    .line 484
    :goto_a0
    iget v6, v3, Lcom/halo/decomp/TouchControls$Button;->r:F

    iget v7, v3, Lcom/halo/decomp/TouchControls$Button;->r:F

    int-to-float v8, v0

    iget v9, v3, Lcom/halo/decomp/TouchControls$Button;->r:F

    sub-float/2addr v8, v9

    invoke-static {v7, v8}, Ljava/lang/Math;->max(FF)F

    move-result v7

    invoke-static {v4, v6, v7}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result v4

    iput v4, v3, Lcom/halo/decomp/TouchControls$Button;->cx:F

    .line 485
    iget v4, v3, Lcom/halo/decomp/TouchControls$Button;->r:F

    iget v6, v3, Lcom/halo/decomp/TouchControls$Button;->r:F

    int-to-float v7, v1

    iget v8, v3, Lcom/halo/decomp/TouchControls$Button;->r:F

    sub-float/2addr v7, v8

    invoke-static {v6, v7}, Ljava/lang/Math;->max(FF)F

    move-result v6

    invoke-static {v5, v4, v6}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result v4

    iput v4, v3, Lcom/halo/decomp/TouchControls$Button;->cy:F

    add-int/lit8 v2, v2, 0x1

    goto/16 :goto_f

    :cond_c8
    :goto_c8
    return-void
.end method

.method private loadSettings()V
    .registers 11

    .line 275
    :try_start_0
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    const-string v1, "size"

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    const/high16 v3, 0x3f000000    # 0.5f

    invoke-static {v0, v3, v1}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result v0

    iput v0, p0, Lcom/halo/decomp/TouchControls;->size:F

    .line 276
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "look"

    invoke-interface {v0, v4, v2}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v0

    const/high16 v4, 0x40800000    # 4.0f

    const/high16 v5, 0x3e800000    # 0.25f

    invoke-static {v0, v5, v4}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result v0

    iput v0, p0, Lcom/halo/decomp/TouchControls;->lookSens:F

    .line 277
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    const-string v6, "opacity"

    invoke-interface {v0, v6, v2}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v0

    const v6, 0x3e99999a    # 0.3f

    invoke-static {v0, v6, v2}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result v0

    iput v0, p0, Lcom/halo/decomp/TouchControls;->opacity:F

    .line 278
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    const-string v6, "invert"

    const/4 v7, 0x0

    invoke-interface {v0, v6, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/halo/decomp/TouchControls;->invertY:Z

    .line 279
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    const-string v6, "gyro"

    invoke-interface {v0, v6, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/halo/decomp/TouchControls;->gyroOn:Z

    .line 280
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    const-string v6, "gyroSens"

    invoke-interface {v0, v6, v2}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result v0

    invoke-static {v0, v5, v4}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result v0

    iput v0, p0, Lcom/halo/decomp/TouchControls;->gyroSens:F

    .line 281
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "gyroInvX"

    invoke-interface {v0, v4, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/halo/decomp/TouchControls;->gyroInvertX:Z

    .line 282
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    const-string v4, "gyroInvY"

    invoke-interface {v0, v4, v7}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, p0, Lcom/halo/decomp/TouchControls;->gyroInvertY:Z

    move v0, v7

    .line 283
    :goto_6f
    iget-object v4, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v4, v4

    if-ge v0, v4, :cond_dd

    .line 284
    iget-object v4, p0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "b"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v6, 0x0

    invoke-interface {v4, v5, v6}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    if-nez v4, :cond_91

    goto :goto_da

    .line 288
    :cond_91
    const-string v5, ","

    invoke-virtual {v4, v5}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v4

    .line 289
    array-length v5, v4
    :try_end_98
    .catch Ljava/lang/RuntimeException; {:try_start_0 .. :try_end_98} :catch_dd

    const/4 v6, 0x4

    if-ge v5, v6, :cond_9c

    goto :goto_da

    .line 293
    :cond_9c
    :try_start_9c
    iget-object v5, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    aget-object v5, v5, v0

    .line 294
    aget-object v6, v4, v7

    invoke-static {v6}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v6

    const/4 v8, 0x1

    .line 295
    aget-object v8, v4, v8

    invoke-static {v8}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v8

    const/4 v9, 0x2

    .line 296
    aget-object v9, v4, v9

    invoke-static {v9}, Ljava/lang/Float;->parseFloat(Ljava/lang/String;)F

    move-result v9

    invoke-static {v9, v3, v1}, Lcom/halo/decomp/TouchControls;->clamp(FFF)F

    move-result v9

    iput v9, v5, Lcom/halo/decomp/TouchControls$Button;->scale:F

    const/4 v9, 0x3

    .line 297
    aget-object v4, v4, v9

    const-string v9, "1"

    invoke-virtual {v4, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    iput-boolean v4, v5, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    const/4 v4, 0x0

    cmpl-float v9, v6, v4

    if-ltz v9, :cond_da

    cmpg-float v9, v6, v2

    if-gtz v9, :cond_da

    cmpl-float v4, v8, v4

    if-ltz v4, :cond_da

    cmpg-float v4, v8, v2

    if-gtz v4, :cond_da

    .line 299
    iput v6, v5, Lcom/halo/decomp/TouchControls$Button;->fx:F

    .line 300
    iput v8, v5, Lcom/halo/decomp/TouchControls$Button;->fy:F
    :try_end_da
    .catch Ljava/lang/NumberFormatException; {:try_start_9c .. :try_end_da} :catch_da
    .catch Ljava/lang/RuntimeException; {:try_start_9c .. :try_end_da} :catch_dd

    :catch_da
    :cond_da
    :goto_da
    add-int/lit8 v0, v0, 0x1

    goto :goto_6f

    :catch_dd
    :cond_dd
    return-void
.end method

.method private look(FF)V
    .registers 6

    .line 668
    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->active:Z

    if-eqz v0, :cond_26

    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->attached:Z

    if-eqz v0, :cond_26

    .line 669
    iget v0, p0, Lcom/halo/decomp/TouchControls;->lookSens:F

    mul-float/2addr p1, v0

    .line 670
    iget-boolean v1, p0, Lcom/halo/decomp/TouchControls;->invertY:Z

    if-eqz v1, :cond_12

    const/high16 v1, -0x40800000    # -1.0f

    goto :goto_14

    :cond_12
    const/high16 v1, 0x3f800000    # 1.0f

    :goto_14
    mul-float/2addr v0, v1

    mul-float/2addr p2, v0

    const/4 v0, 0x0

    cmpl-float v1, p1, v0

    if-nez v1, :cond_1f

    cmpl-float v0, p2, v0

    if-eqz v0, :cond_26

    .line 672
    :cond_1f
    iget v0, p0, Lcom/halo/decomp/TouchControls;->mouseState:I

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0, v1, p1, p2, v2}, Lorg/libsdl/app/SDLActivity;->onNativeMouse(IIFFZ)V

    :cond_26
    return-void
.end method

.method private static native nativeUpdate(ZIIIIIII)Z
.end method

.method private openSettings()V
    .registers 19

    move-object/from16 v0, p0

    .line 876
    iget-boolean v1, v0, Lcom/halo/decomp/TouchControls;->dialogOpen:Z

    if-eqz v1, :cond_7

    return-void

    .line 879
    :cond_7
    invoke-direct/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->releaseAll()V

    .line 880
    invoke-virtual/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->getContext()Landroid/content/Context;

    move-result-object v1

    const/high16 v2, 0x41800000    # 16.0f

    .line 881
    iget v3, v0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v3, v2

    invoke-static {v3}, Ljava/lang/Math;->round(F)I

    move-result v2

    .line 882
    new-instance v3, Landroid/widget/LinearLayout;

    invoke-direct {v3, v1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x1

    .line 883
    invoke-virtual {v3, v4}, Landroid/widget/LinearLayout;->setOrientation(I)V

    .line 884
    div-int/lit8 v5, v2, 0x2

    const/4 v6, 0x0

    invoke-virtual {v3, v2, v5, v2, v6}, Landroid/widget/LinearLayout;->setPadding(IIII)V

    .line 886
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 887
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "Tama\u00f1o de botones: "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v6, v0, Lcom/halo/decomp/TouchControls;->size:F

    invoke-static {v6}, Lcom/halo/decomp/TouchControls;->pct(F)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 888
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 889
    new-instance v5, Landroid/widget/SeekBar;

    invoke-direct {v5, v1}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x96

    .line 890
    invoke-virtual {v5, v6}, Landroid/widget/SeekBar;->setMax(I)V

    .line 891
    iget v6, v0, Lcom/halo/decomp/TouchControls;->size:F

    const/high16 v7, 0x42c80000    # 100.0f

    mul-float/2addr v6, v7

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    add-int/lit8 v6, v6, -0x32

    invoke-virtual {v5, v6}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 892
    new-instance v6, Lcom/halo/decomp/TouchControls$2;

    invoke-direct {v6, v0, v2}, Lcom/halo/decomp/TouchControls$2;-><init>(Lcom/halo/decomp/TouchControls;Landroid/widget/TextView;)V

    invoke-virtual {v5, v6}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 901
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 903
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 904
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "Sensibilidad de la c\u00e1mara: "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v6, v0, Lcom/halo/decomp/TouchControls;->lookSens:F

    invoke-static {v6}, Lcom/halo/decomp/TouchControls;->times(F)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 905
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 906
    new-instance v5, Landroid/widget/SeekBar;

    invoke-direct {v5, v1}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x64

    .line 907
    invoke-virtual {v5, v6}, Landroid/widget/SeekBar;->setMax(I)V

    .line 908
    iget v8, v0, Lcom/halo/decomp/TouchControls;->lookSens:F

    const/high16 v9, 0x3e800000    # 0.25f

    div-float/2addr v8, v9

    float-to-double v10, v8

    invoke-static {v10, v11}, Ljava/lang/Math;->log(D)D

    move-result-wide v10

    const-wide/high16 v12, 0x4059000000000000L    # 100.0

    mul-double/2addr v10, v12

    const-wide/high16 v14, 0x4030000000000000L    # 16.0

    invoke-static {v14, v15}, Ljava/lang/Math;->log(D)D

    move-result-wide v16

    div-double v10, v10, v16

    double-to-float v8, v10

    invoke-static {v8}, Ljava/lang/Math;->round(F)I

    move-result v8

    invoke-virtual {v5, v8}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 909
    new-instance v8, Lcom/halo/decomp/TouchControls$3;

    invoke-direct {v8, v0, v2}, Lcom/halo/decomp/TouchControls$3;-><init>(Lcom/halo/decomp/TouchControls;Landroid/widget/TextView;)V

    invoke-virtual {v5, v8}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 916
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 918
    new-instance v2, Landroid/widget/CheckBox;

    invoke-direct {v2, v1}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 919
    iget-object v5, v0, Lcom/halo/decomp/TouchControls;->gyroSensor:Landroid/hardware/Sensor;

    if-nez v5, :cond_c7

    const-string v5, "Giroscopio (no disponible en este tel\u00e9fono)"

    goto :goto_c9

    :cond_c7
    const-string v5, "Apuntar con el giroscopio"

    :goto_c9
    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    .line 920
    iget-boolean v5, v0, Lcom/halo/decomp/TouchControls;->gyroOn:Z

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 921
    new-instance v5, Lcom/halo/decomp/TouchControls$4;

    invoke-direct {v5, v0}, Lcom/halo/decomp/TouchControls$4;-><init>(Lcom/halo/decomp/TouchControls;)V

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 928
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 930
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 931
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v8, "Sensibilidad del giroscopio: "

    invoke-direct {v5, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v8, v0, Lcom/halo/decomp/TouchControls;->gyroSens:F

    invoke-static {v8}, Lcom/halo/decomp/TouchControls;->times(F)Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 932
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 933
    new-instance v5, Landroid/widget/SeekBar;

    invoke-direct {v5, v1}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    .line 934
    invoke-virtual {v5, v6}, Landroid/widget/SeekBar;->setMax(I)V

    .line 935
    iget v6, v0, Lcom/halo/decomp/TouchControls;->gyroSens:F

    div-float/2addr v6, v9

    float-to-double v8, v6

    invoke-static {v8, v9}, Ljava/lang/Math;->log(D)D

    move-result-wide v8

    mul-double/2addr v8, v12

    invoke-static {v14, v15}, Ljava/lang/Math;->log(D)D

    move-result-wide v10

    div-double/2addr v8, v10

    double-to-float v6, v8

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    invoke-virtual {v5, v6}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 936
    new-instance v6, Lcom/halo/decomp/TouchControls$5;

    invoke-direct {v6, v0, v2}, Lcom/halo/decomp/TouchControls$5;-><init>(Lcom/halo/decomp/TouchControls;Landroid/widget/TextView;)V

    invoke-virtual {v5, v6}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 943
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 945
    new-instance v2, Landroid/widget/CheckBox;

    invoke-direct {v2, v1}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 946
    const-string v5, "Invertir giroscopio horizontal"

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    .line 947
    iget-boolean v5, v0, Lcom/halo/decomp/TouchControls;->gyroInvertX:Z

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 948
    new-instance v5, Lcom/halo/decomp/TouchControls$6;

    invoke-direct {v5, v0}, Lcom/halo/decomp/TouchControls$6;-><init>(Lcom/halo/decomp/TouchControls;)V

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 955
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 957
    new-instance v2, Landroid/widget/CheckBox;

    invoke-direct {v2, v1}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 958
    const-string v5, "Invertir giroscopio vertical"

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    .line 959
    iget-boolean v5, v0, Lcom/halo/decomp/TouchControls;->gyroInvertY:Z

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 960
    new-instance v5, Lcom/halo/decomp/TouchControls$7;

    invoke-direct {v5, v0}, Lcom/halo/decomp/TouchControls$7;-><init>(Lcom/halo/decomp/TouchControls;)V

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 967
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 969
    new-instance v2, Landroid/widget/CheckBox;

    invoke-direct {v2, v1}, Landroid/widget/CheckBox;-><init>(Landroid/content/Context;)V

    .line 970
    const-string v5, "Invertir eje vertical de la c\u00e1mara"

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setText(Ljava/lang/CharSequence;)V

    .line 971
    iget-boolean v5, v0, Lcom/halo/decomp/TouchControls;->invertY:Z

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setChecked(Z)V

    .line 972
    new-instance v5, Lcom/halo/decomp/TouchControls$8;

    invoke-direct {v5, v0}, Lcom/halo/decomp/TouchControls$8;-><init>(Lcom/halo/decomp/TouchControls;)V

    invoke-virtual {v2, v5}, Landroid/widget/CheckBox;->setOnCheckedChangeListener(Landroid/widget/CompoundButton$OnCheckedChangeListener;)V

    .line 979
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 981
    new-instance v2, Landroid/widget/TextView;

    invoke-direct {v2, v1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    .line 982
    new-instance v5, Ljava/lang/StringBuilder;

    const-string v6, "Opacidad de los botones: "

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget v6, v0, Lcom/halo/decomp/TouchControls;->opacity:F

    invoke-static {v6}, Lcom/halo/decomp/TouchControls;->pct(F)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 983
    invoke-virtual {v3, v2}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 984
    new-instance v5, Landroid/widget/SeekBar;

    invoke-direct {v5, v1}, Landroid/widget/SeekBar;-><init>(Landroid/content/Context;)V

    const/16 v6, 0x46

    .line 985
    invoke-virtual {v5, v6}, Landroid/widget/SeekBar;->setMax(I)V

    .line 986
    iget v6, v0, Lcom/halo/decomp/TouchControls;->opacity:F

    mul-float/2addr v6, v7

    invoke-static {v6}, Ljava/lang/Math;->round(F)I

    move-result v6

    add-int/lit8 v6, v6, -0x1e

    invoke-virtual {v5, v6}, Landroid/widget/SeekBar;->setProgress(I)V

    .line 987
    new-instance v6, Lcom/halo/decomp/TouchControls$9;

    invoke-direct {v6, v0, v2}, Lcom/halo/decomp/TouchControls$9;-><init>(Lcom/halo/decomp/TouchControls;Landroid/widget/TextView;)V

    invoke-virtual {v5, v6}, Landroid/widget/SeekBar;->setOnSeekBarChangeListener(Landroid/widget/SeekBar$OnSeekBarChangeListener;)V

    .line 995
    invoke-virtual {v3, v5}, Landroid/widget/LinearLayout;->addView(Landroid/view/View;)V

    .line 997
    new-instance v2, Landroid/widget/ScrollView;

    invoke-direct {v2, v1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    .line 998
    invoke-virtual {v2, v3}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    .line 1000
    iput-boolean v4, v0, Lcom/halo/decomp/TouchControls;->dialogOpen:Z

    .line 1001
    invoke-direct/range {p0 .. p0}, Lcom/halo/decomp/TouchControls;->updateGyro()V

    .line 1002
    new-instance v3, Landroid/app/AlertDialog$Builder;

    invoke-direct {v3, v1}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const-string v1, "Controles t\u00e1ctiles"

    .line 1003
    invoke-virtual {v3, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    .line 1004
    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setView(Landroid/view/View;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    const-string v2, "Listo"

    const/4 v3, 0x0

    .line 1005
    invoke-virtual {v1, v2, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lcom/halo/decomp/TouchControls$12;

    invoke-direct {v2, v0}, Lcom/halo/decomp/TouchControls$12;-><init>(Lcom/halo/decomp/TouchControls;)V

    .line 1006
    const-string v3, "Editar disposici\u00f3n"

    invoke-virtual {v1, v3, v2}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lcom/halo/decomp/TouchControls$11;

    invoke-direct {v2, v0}, Lcom/halo/decomp/TouchControls$11;-><init>(Lcom/halo/decomp/TouchControls;)V

    .line 1012
    const-string v3, "Restablecer"

    invoke-virtual {v1, v3, v2}, Landroid/app/AlertDialog$Builder;->setNeutralButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    new-instance v2, Lcom/halo/decomp/TouchControls$10;

    invoke-direct {v2, v0}, Lcom/halo/decomp/TouchControls$10;-><init>(Lcom/halo/decomp/TouchControls;)V

    .line 1018
    invoke-virtual {v1, v2}, Landroid/app/AlertDialog$Builder;->setOnDismissListener(Landroid/content/DialogInterface$OnDismissListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v1

    .line 1026
    invoke-virtual {v1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    return-void
.end method

.method private static pct(F)Ljava/lang/String;
    .registers 3

    .line 868
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/high16 v1, 0x42c80000    # 100.0f

    mul-float/2addr p0, v1

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, "%"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private push()V
    .registers 14

    const/4 v0, 0x0

    move v1, v0

    move v3, v1

    move v10, v3

    move v11, v10

    .line 681
    :goto_5
    iget-object v2, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v4, v2

    const/4 v12, 0x1

    if-ge v1, v4, :cond_2d

    .line 682
    aget-object v2, v2, v1

    .line 683
    iget v4, v2, Lcom/halo/decomp/TouchControls$Button;->pointer:I

    if-ltz v4, :cond_2a

    iget-boolean v4, v2, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    if-nez v4, :cond_2a

    .line 684
    iget v4, v2, Lcom/halo/decomp/TouchControls$Button;->code:I

    const/4 v5, -0x1

    const/16 v6, 0x7fff

    if-ne v4, v5, :cond_1e

    move v10, v6

    goto :goto_2a

    .line 686
    :cond_1e
    iget v4, v2, Lcom/halo/decomp/TouchControls$Button;->code:I

    const/4 v5, -0x2

    if-ne v4, v5, :cond_25

    move v11, v6

    goto :goto_2a

    .line 689
    :cond_25
    iget v2, v2, Lcom/halo/decomp/TouchControls$Button;->code:I

    shl-int v2, v12, v2

    or-int/2addr v3, v2

    :cond_2a
    :goto_2a
    add-int/lit8 v1, v1, 0x1

    goto :goto_5

    .line 693
    :cond_2d
    iget-boolean v2, p0, Lcom/halo/decomp/TouchControls;->active:Z

    iget v1, p0, Lcom/halo/decomp/TouchControls;->moveDX:F

    invoke-static {v1}, Lcom/halo/decomp/TouchControls;->axis(F)I

    move-result v4

    iget v1, p0, Lcom/halo/decomp/TouchControls;->moveDY:F

    invoke-static {v1}, Lcom/halo/decomp/TouchControls;->axis(F)I

    move-result v5

    const/4 v6, 0x0

    const/4 v7, 0x0

    move v8, v10

    move v9, v11

    invoke-static/range {v2 .. v9}, Lcom/halo/decomp/TouchControls;->nativeUpdate(ZIIIIIII)Z

    move-result v1

    iput-boolean v1, p0, Lcom/halo/decomp/TouchControls;->attached:Z

    .line 694
    iget-boolean v2, p0, Lcom/halo/decomp/TouchControls;->active:Z

    if-eqz v2, :cond_56

    if-eqz v1, :cond_56

    if-lez v10, :cond_4f

    move v1, v12

    goto :goto_50

    :cond_4f
    move v1, v0

    :goto_50
    if-lez v11, :cond_53

    move v0, v12

    .line 695
    :cond_53
    invoke-direct {p0, v1, v0}, Lcom/halo/decomp/TouchControls;->sendPlatformInput(ZZ)V

    :cond_56
    return-void
.end method

.method private refreshActive()V
    .registers 12

    .line 386
    invoke-static {}, Landroid/view/InputDevice;->getDeviceIds()[I

    move-result-object v0

    const/4 v1, 0x0

    move v2, v1

    .line 387
    :goto_6
    array-length v3, v0

    const/4 v4, 0x1

    if-ge v2, v3, :cond_17

    .line 388
    aget v3, v0, v2

    invoke-static {v3}, Lcom/halo/decomp/TouchControls;->isPhysicalPad(I)Z

    move-result v3

    if-eqz v3, :cond_14

    move v0, v4

    goto :goto_18

    :cond_14
    add-int/lit8 v2, v2, 0x1

    goto :goto_6

    :cond_17
    move v0, v1

    .line 393
    :goto_18
    iget-boolean v2, p0, Lcom/halo/decomp/TouchControls;->first:Z

    if-nez v2, :cond_23

    .line 394
    iget-boolean v2, p0, Lcom/halo/decomp/TouchControls;->active:Z

    xor-int/lit8 v3, v0, 0x1

    if-ne v2, v3, :cond_23

    return-void

    .line 398
    :cond_23
    iput-boolean v1, p0, Lcom/halo/decomp/TouchControls;->first:Z

    xor-int/2addr v0, v4

    .line 399
    iput-boolean v0, p0, Lcom/halo/decomp/TouchControls;->active:Z

    if-eqz v0, :cond_2c

    move v0, v1

    goto :goto_2e

    :cond_2c
    const/16 v0, 0x8

    .line 400
    :goto_2e
    invoke-virtual {p0, v0}, Lcom/halo/decomp/TouchControls;->setVisibility(I)V

    .line 401
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->releaseAll()V

    .line 402
    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->active:Z

    if-eqz v0, :cond_49

    .line 403
    iput-boolean v1, p0, Lcom/halo/decomp/TouchControls;->attached:Z

    .line 404
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/halo/decomp/TouchControls;->retry:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 405
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/halo/decomp/TouchControls;->retry:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    goto :goto_60

    .line 407
    :cond_49
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->handler:Landroid/os/Handler;

    iget-object v2, p0, Lcom/halo/decomp/TouchControls;->retry:Ljava/lang/Runnable;

    invoke-virtual {v0, v2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 408
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->releasePlatformInput()V

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    .line 409
    invoke-static/range {v3 .. v10}, Lcom/halo/decomp/TouchControls;->nativeUpdate(ZIIIIIII)Z

    .line 410
    iput-boolean v1, p0, Lcom/halo/decomp/TouchControls;->attached:Z

    .line 412
    :goto_60
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->updateGyro()V

    return-void
.end method

.method private releaseAll()V
    .registers 5

    const/4 v0, 0x0

    .line 525
    :goto_1
    iget-object v1, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v2, v1

    const/4 v3, -0x1

    if-ge v0, v2, :cond_e

    .line 526
    aget-object v1, v1, v0

    iput v3, v1, Lcom/halo/decomp/TouchControls$Button;->pointer:I

    add-int/lit8 v0, v0, 0x1

    goto :goto_1

    .line 528
    :cond_e
    iput v3, p0, Lcom/halo/decomp/TouchControls;->lookPointer:I

    .line 529
    iput v3, p0, Lcom/halo/decomp/TouchControls;->movePointer:I

    .line 530
    iput v3, p0, Lcom/halo/decomp/TouchControls;->gearPointer:I

    .line 531
    iput v3, p0, Lcom/halo/decomp/TouchControls;->dragPointer:I

    const/4 v0, 0x0

    .line 532
    iput v0, p0, Lcom/halo/decomp/TouchControls;->moveDY:F

    .line 533
    iput v0, p0, Lcom/halo/decomp/TouchControls;->moveDX:F

    .line 534
    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->active:Z

    if-eqz v0, :cond_23

    .line 535
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->push()V

    goto :goto_26

    .line 537
    :cond_23
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->releasePlatformInput()V

    .line 539
    :goto_26
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return-void
.end method

.method private releasePlatformInput()V
    .registers 4

    .line 716
    new-instance v0, Ljava/util/ArrayList;

    iget-object v1, p0, Lcom/halo/decomp/TouchControls;->keysDown:Ljava/util/HashSet;

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    .line 717
    :goto_b
    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v2, 0x0

    if-eqz v1, :cond_20

    .line 718
    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Integer;

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    invoke-direct {p0, v1, v2}, Lcom/halo/decomp/TouchControls;->setKey(IZ)V

    goto :goto_b

    .line 720
    :cond_20
    invoke-direct {p0, v2}, Lcom/halo/decomp/TouchControls;->setMouseButtons(I)V

    return-void
.end method

.method private resetSettings()V
    .registers 6

    const/high16 v0, 0x3f800000    # 1.0f

    .line 333
    iput v0, p0, Lcom/halo/decomp/TouchControls;->size:F

    .line 334
    iput v0, p0, Lcom/halo/decomp/TouchControls;->lookSens:F

    .line 335
    iput v0, p0, Lcom/halo/decomp/TouchControls;->opacity:F

    const/4 v1, 0x0

    .line 336
    iput-boolean v1, p0, Lcom/halo/decomp/TouchControls;->invertY:Z

    .line 337
    iput-boolean v1, p0, Lcom/halo/decomp/TouchControls;->gyroOn:Z

    .line 338
    iput v0, p0, Lcom/halo/decomp/TouchControls;->gyroSens:F

    .line 339
    iput-boolean v1, p0, Lcom/halo/decomp/TouchControls;->gyroInvertX:Z

    .line 340
    iput-boolean v1, p0, Lcom/halo/decomp/TouchControls;->gyroInvertY:Z

    .line 341
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->updateGyro()V

    move v2, v1

    .line 342
    :goto_17
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v4, v3

    if-ge v2, v4, :cond_2b

    .line 343
    aget-object v3, v3, v2

    const/high16 v4, 0x7fc00000    # Float.NaN

    .line 344
    iput v4, v3, Lcom/halo/decomp/TouchControls$Button;->fx:F

    .line 345
    iput v4, v3, Lcom/halo/decomp/TouchControls$Button;->fy:F

    .line 346
    iput v0, v3, Lcom/halo/decomp/TouchControls$Button;->scale:F

    .line 347
    iput-boolean v1, v3, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    add-int/lit8 v2, v2, 0x1

    goto :goto_17

    :cond_2b
    const/4 v0, 0x0

    .line 349
    iput-object v0, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    .line 350
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->saveSettings()V

    .line 351
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->layout()V

    .line 352
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return-void
.end method

.method private saveSettings()V
    .registers 8

    .line 313
    const-string v0, ","

    :try_start_2
    iget-object v1, p0, Lcom/halo/decomp/TouchControls;->prefs:Landroid/content/SharedPreferences;

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    .line 314
    const-string v2, "size"

    iget v3, p0, Lcom/halo/decomp/TouchControls;->size:F

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    .line 315
    const-string v2, "look"

    iget v3, p0, Lcom/halo/decomp/TouchControls;->lookSens:F

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    .line 316
    const-string v2, "opacity"

    iget v3, p0, Lcom/halo/decomp/TouchControls;->opacity:F

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    .line 317
    const-string v2, "invert"

    iget-boolean v3, p0, Lcom/halo/decomp/TouchControls;->invertY:Z

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 318
    const-string v2, "gyro"

    iget-boolean v3, p0, Lcom/halo/decomp/TouchControls;->gyroOn:Z

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 319
    const-string v2, "gyroSens"

    iget v3, p0, Lcom/halo/decomp/TouchControls;->gyroSens:F

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    .line 320
    const-string v2, "gyroInvX"

    iget-boolean v3, p0, Lcom/halo/decomp/TouchControls;->gyroInvertX:Z

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    .line 321
    const-string v2, "gyroInvY"

    iget-boolean v3, p0, Lcom/halo/decomp/TouchControls;->gyroInvertY:Z

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x0

    .line 322
    :goto_41
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v4, v3

    if-ge v2, v4, :cond_95

    .line 323
    aget-object v3, v3, v2

    .line 324
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "b"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    iget v6, v3, Lcom/halo/decomp/TouchControls$Button;->fx:F

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v6, v3, Lcom/halo/decomp/TouchControls$Button;->fy:F

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget v6, v3, Lcom/halo/decomp/TouchControls$Button;->scale:F

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object v5

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v5

    iget-boolean v3, v3, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    if-eqz v3, :cond_85

    const-string v3, "1"

    goto :goto_87

    :cond_85
    const-string v3, "0"

    :goto_87
    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-interface {v1, v4, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    add-int/lit8 v2, v2, 0x1

    goto :goto_41

    .line 326
    :cond_95
    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_98
    .catch Ljava/lang/RuntimeException; {:try_start_2 .. :try_end_98} :catch_98

    :catch_98
    return-void
.end method

.method private sendPlatformInput(ZZ)V
    .registers 9

    const/4 v0, 0x0

    move v1, v0

    .line 700
    :goto_2
    iget-object v2, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v3, v2

    const/4 v4, 0x1

    if-ge v1, v3, :cond_1c

    .line 701
    aget-object v2, v2, v1

    .line 702
    iget v3, v2, Lcom/halo/decomp/TouchControls$Button;->key:I

    iget v5, v2, Lcom/halo/decomp/TouchControls$Button;->pointer:I

    if-ltz v5, :cond_15

    iget-boolean v2, v2, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    if-nez v2, :cond_15

    goto :goto_16

    :cond_15
    move v4, v0

    :goto_16
    invoke-direct {p0, v3, v4}, Lcom/halo/decomp/TouchControls;->setKey(IZ)V

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    .line 704
    :cond_1c
    iget v1, p0, Lcom/halo/decomp/TouchControls;->moveDY:F

    const v2, -0x414ccccd    # -0.35f

    cmpg-float v1, v1, v2

    if-gez v1, :cond_27

    move v1, v4

    goto :goto_28

    :cond_27
    move v1, v0

    :goto_28
    const/16 v3, 0x33

    invoke-direct {p0, v3, v1}, Lcom/halo/decomp/TouchControls;->setKey(IZ)V

    .line 705
    iget v1, p0, Lcom/halo/decomp/TouchControls;->moveDY:F

    const v3, 0x3eb33333    # 0.35f

    cmpl-float v1, v1, v3

    if-lez v1, :cond_38

    move v1, v4

    goto :goto_39

    :cond_38
    move v1, v0

    :goto_39
    const/16 v5, 0x2f

    invoke-direct {p0, v5, v1}, Lcom/halo/decomp/TouchControls;->setKey(IZ)V

    .line 706
    iget v1, p0, Lcom/halo/decomp/TouchControls;->moveDX:F

    cmpg-float v1, v1, v2

    if-gez v1, :cond_46

    move v1, v4

    goto :goto_47

    :cond_46
    move v1, v0

    :goto_47
    const/16 v2, 0x1d

    invoke-direct {p0, v2, v1}, Lcom/halo/decomp/TouchControls;->setKey(IZ)V

    .line 707
    iget v1, p0, Lcom/halo/decomp/TouchControls;->moveDX:F

    cmpl-float v1, v1, v3

    if-lez v1, :cond_54

    move v1, v4

    goto :goto_55

    :cond_54
    move v1, v0

    :goto_55
    const/16 v2, 0x20

    invoke-direct {p0, v2, v1}, Lcom/halo/decomp/TouchControls;->setKey(IZ)V

    .line 708
    iget v1, p0, Lcom/halo/decomp/TouchControls;->moveDY:F

    const v2, -0x40e66666    # -0.6f

    cmpg-float v1, v1, v2

    if-gez v1, :cond_65

    move v1, v4

    goto :goto_66

    :cond_65
    move v1, v0

    :goto_66
    const/16 v3, 0x13

    invoke-direct {p0, v3, v1}, Lcom/halo/decomp/TouchControls;->setKey(IZ)V

    .line 709
    iget v1, p0, Lcom/halo/decomp/TouchControls;->moveDY:F

    const v3, 0x3f19999a    # 0.6f

    cmpl-float v1, v1, v3

    if-lez v1, :cond_76

    move v1, v4

    goto :goto_77

    :cond_76
    move v1, v0

    :goto_77
    const/16 v5, 0x14

    invoke-direct {p0, v5, v1}, Lcom/halo/decomp/TouchControls;->setKey(IZ)V

    .line 710
    iget v1, p0, Lcom/halo/decomp/TouchControls;->moveDX:F

    cmpg-float v1, v1, v2

    if-gez v1, :cond_84

    move v1, v4

    goto :goto_85

    :cond_84
    move v1, v0

    :goto_85
    const/16 v2, 0x15

    invoke-direct {p0, v2, v1}, Lcom/halo/decomp/TouchControls;->setKey(IZ)V

    .line 711
    iget v1, p0, Lcom/halo/decomp/TouchControls;->moveDX:F

    cmpl-float v1, v1, v3

    if-lez v1, :cond_91

    goto :goto_92

    :cond_91
    move v4, v0

    :goto_92
    const/16 v1, 0x16

    invoke-direct {p0, v1, v4}, Lcom/halo/decomp/TouchControls;->setKey(IZ)V

    if-eqz p1, :cond_9a

    const/4 v0, 0x2

    :cond_9a
    or-int p1, p2, v0

    .line 712
    invoke-direct {p0, p1}, Lcom/halo/decomp/TouchControls;->setMouseButtons(I)V

    return-void
.end method

.method private setKey(IZ)V
    .registers 4

    if-eqz p1, :cond_23

    if-eqz p2, :cond_14

    .line 726
    iget-object p2, p0, Lcom/halo/decomp/TouchControls;->keysDown:Ljava/util/HashSet;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/util/HashSet;->add(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_23

    .line 727
    invoke-static {p1}, Lorg/libsdl/app/SDLActivity;->onNativeKeyDown(I)V

    goto :goto_23

    .line 729
    :cond_14
    iget-object p2, p0, Lcom/halo/decomp/TouchControls;->keysDown:Ljava/util/HashSet;

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    invoke-virtual {p2, v0}, Ljava/util/HashSet;->remove(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_23

    .line 730
    invoke-static {p1}, Lorg/libsdl/app/SDLActivity;->onNativeKeyUp(I)V

    :cond_23
    :goto_23
    return-void
.end method

.method private setMouseButtons(I)V
    .registers 9

    .line 736
    iget v0, p0, Lcom/halo/decomp/TouchControls;->mouseState:I

    not-int v1, v0

    and-int/2addr v1, p1

    not-int v2, p1

    and-int/2addr v2, v0

    const/4 v3, 0x1

    move v4, v3

    :goto_8
    const/4 v5, 0x2

    if-gt v4, v5, :cond_22

    and-int v5, v1, v4

    const/4 v6, 0x0

    if-eqz v5, :cond_16

    or-int/2addr v0, v4

    const/4 v5, 0x0

    .line 742
    invoke-static {v0, v5, v6, v6, v3}, Lorg/libsdl/app/SDLActivity;->onNativeMouse(IIFFZ)V

    goto :goto_1f

    :cond_16
    and-int v5, v2, v4

    if-eqz v5, :cond_1f

    not-int v5, v4

    and-int/2addr v0, v5

    .line 745
    invoke-static {v0, v3, v6, v6, v3}, Lorg/libsdl/app/SDLActivity;->onNativeMouse(IIFFZ)V

    :cond_1f
    :goto_1f
    shl-int/lit8 v4, v4, 0x1

    goto :goto_8

    .line 748
    :cond_22
    iput p1, p0, Lcom/halo/decomp/TouchControls;->mouseState:I

    return-void
.end method

.method private static stick(FFF)[F
    .registers 8

    float-to-double v0, p0

    float-to-double v2, p1

    .line 658
    invoke-static {v0, v1, v2, v3}, Ljava/lang/Math;->hypot(DD)D

    move-result-wide v0

    double-to-float v0, v0

    const v1, 0x3df5c28f    # 0.12f

    mul-float/2addr v1, p2

    cmpg-float v1, v0, v1

    const/4 v2, 0x2

    if-gez v1, :cond_16

    .line 660
    new-array p0, v2, [F

    fill-array-data p0, :array_3e

    return-object p0

    :cond_16
    const/high16 v1, 0x3f800000    # 1.0f

    div-float p2, v0, p2

    .line 662
    invoke-static {v1, p2}, Ljava/lang/Math;->min(FF)F

    move-result p2

    mul-float v1, p2, p2

    const/high16 v3, 0x40000000    # 2.0f

    mul-float/2addr v3, p2

    const/high16 v4, 0x40400000    # 3.0f

    sub-float/2addr v4, v3

    mul-float/2addr v1, v4

    const v3, 0x3eb33333    # 0.35f

    mul-float/2addr v1, v3

    const v3, 0x3f266666    # 0.65f

    mul-float/2addr p2, v3

    add-float/2addr v1, p2

    div-float/2addr p0, v0

    mul-float/2addr p0, v1

    div-float/2addr p1, v0

    mul-float/2addr p1, v1

    .line 664
    new-array p2, v2, [F

    const/4 v0, 0x0

    aput p0, p2, v0

    const/4 p0, 0x1

    aput p1, p2, p0

    return-object p2

    nop

    :array_3e
    .array-data 4
        0x0
        0x0
    .end array-data
.end method

.method private stickRadius()F
    .registers 3

    const/high16 v0, 0x42700000    # 60.0f

    .line 445
    iget v1, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v1, v0

    iget v0, p0, Lcom/halo/decomp/TouchControls;->size:F

    mul-float/2addr v1, v0

    return v1
.end method

.method private stopGyro()V
    .registers 3

    .line 770
    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->gyroRegistered:Z

    if-eqz v0, :cond_b

    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->sensors:Landroid/hardware/SensorManager;

    if-eqz v0, :cond_b

    .line 771
    invoke-virtual {v0, p0}, Landroid/hardware/SensorManager;->unregisterListener(Landroid/hardware/SensorEventListener;)V

    :cond_b
    const/4 v0, 0x0

    .line 773
    iput-boolean v0, p0, Lcom/halo/decomp/TouchControls;->gyroRegistered:Z

    const-wide/16 v0, 0x0

    .line 774
    iput-wide v0, p0, Lcom/halo/decomp/TouchControls;->gyroPrevTime:J

    const/4 v0, -0x1

    .line 775
    iput v0, p0, Lcom/halo/decomp/TouchControls;->gyroPrevRotation:I

    return-void
.end method

.method private static times(F)Ljava/lang/String;
    .registers 3

    .line 872
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/high16 v1, 0x42c80000    # 100.0f

    mul-float/2addr p0, v1

    invoke-static {p0}, Ljava/lang/Math;->round(F)I

    move-result p0

    int-to-float p0, p0

    div-float/2addr p0, v1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    move-result-object p0

    const-string v0, "x"

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    return-object p0
.end method

.method private updateGyro()V
    .registers 5

    .line 758
    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->gyroOn:Z

    const/4 v1, 0x1

    if-eqz v0, :cond_21

    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->gyroSensor:Landroid/hardware/Sensor;

    if-eqz v0, :cond_21

    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->sensors:Landroid/hardware/SensorManager;

    if-eqz v0, :cond_21

    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->active:Z

    if-eqz v0, :cond_21

    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->editMode:Z

    if-nez v0, :cond_21

    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->dialogOpen:Z

    if-nez v0, :cond_21

    .line 759
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->hasWindowFocus()Z

    move-result v0

    if-eqz v0, :cond_21

    move v0, v1

    goto :goto_22

    :cond_21
    const/4 v0, 0x0

    :goto_22
    if-eqz v0, :cond_3a

    .line 760
    iget-boolean v2, p0, Lcom/halo/decomp/TouchControls;->gyroRegistered:Z

    if-nez v2, :cond_3a

    const-wide/16 v2, 0x0

    .line 761
    iput-wide v2, p0, Lcom/halo/decomp/TouchControls;->gyroPrevTime:J

    const/4 v0, -0x1

    .line 762
    iput v0, p0, Lcom/halo/decomp/TouchControls;->gyroPrevRotation:I

    .line 763
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->sensors:Landroid/hardware/SensorManager;

    iget-object v2, p0, Lcom/halo/decomp/TouchControls;->gyroSensor:Landroid/hardware/Sensor;

    invoke-virtual {v0, p0, v2, v1}, Landroid/hardware/SensorManager;->registerListener(Landroid/hardware/SensorEventListener;Landroid/hardware/Sensor;I)Z

    move-result v0

    iput-boolean v0, p0, Lcom/halo/decomp/TouchControls;->gyroRegistered:Z

    goto :goto_43

    :cond_3a
    if-nez v0, :cond_43

    .line 764
    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->gyroRegistered:Z

    if-eqz v0, :cond_43

    .line 765
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->stopGyro()V

    :cond_43
    :goto_43
    return-void
.end method


# virtual methods
.method public onAccuracyChanged(Landroid/hardware/Sensor;I)V
    .registers 3

    return-void
.end method

.method protected onAttachedToWindow()V
    .registers 3

    .line 359
    invoke-super {p0}, Landroid/view/View;->onAttachedToWindow()V

    .line 360
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "input"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/input/InputManager;

    iget-object v1, p0, Lcom/halo/decomp/TouchControls;->handler:Landroid/os/Handler;

    invoke-virtual {v0, p0, v1}, Landroid/hardware/input/InputManager;->registerInputDeviceListener(Landroid/hardware/input/InputManager$InputDeviceListener;Landroid/os/Handler;)V

    .line 361
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->refreshActive()V

    .line 362
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->updateGyro()V

    return-void
.end method

.method protected onDetachedFromWindow()V
    .registers 11

    .line 367
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getContext()Landroid/content/Context;

    move-result-object v0

    const-string v1, "input"

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/hardware/input/InputManager;

    invoke-virtual {v0, p0}, Landroid/hardware/input/InputManager;->unregisterInputDeviceListener(Landroid/hardware/input/InputManager$InputDeviceListener;)V

    .line 368
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->handler:Landroid/os/Handler;

    iget-object v1, p0, Lcom/halo/decomp/TouchControls;->retry:Ljava/lang/Runnable;

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    .line 369
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->stopGyro()V

    .line 370
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->releasePlatformInput()V

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    .line 371
    invoke-static/range {v2 .. v9}, Lcom/halo/decomp/TouchControls;->nativeUpdate(ZIIIIIII)Z

    .line 372
    invoke-super {p0}, Landroid/view/View;->onDetachedFromWindow()V

    return-void
.end method

.method protected onDraw(Landroid/graphics/Canvas;)V
    .registers 11

    .line 1239
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    iget v1, p0, Lcom/halo/decomp/TouchControls;->dp:F

    const/high16 v2, 0x3fc00000    # 1.5f

    mul-float/2addr v1, v2

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1240
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Cap;->ROUND:Landroid/graphics/Paint$Cap;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeCap(Landroid/graphics/Paint$Cap;)V

    .line 1241
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    sget-object v1, Landroid/graphics/Paint$Join;->ROUND:Landroid/graphics/Paint$Join;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeJoin(Landroid/graphics/Paint$Join;)V

    .line 1242
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->pen:Lcom/halo/decomp/TouchControls$CanvasPen;

    iput-object p1, v0, Lcom/halo/decomp/TouchControls$CanvasPen;->c:Landroid/graphics/Canvas;

    const/4 v0, 0x0

    .line 1243
    :goto_1d
    iget-object v1, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v3, v1

    const/high16 v4, 0x40000000    # 2.0f

    const v5, 0x55ffffff    # 3.518437E13f

    if-ge v0, v3, :cond_e4

    .line 1244
    aget-object v1, v1, v0

    .line 1245
    iget-boolean v3, v1, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    if-eqz v3, :cond_33

    iget-boolean v3, p0, Lcom/halo/decomp/TouchControls;->editMode:Z

    if-nez v3, :cond_33

    goto/16 :goto_e0

    .line 1248
    :cond_33
    iget-boolean v3, v1, Lcom/halo/decomp/TouchControls$Button;->hidden:Z

    .line 1249
    iget-object v6, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    if-eqz v3, :cond_3d

    const v7, 0x66ff8a80

    goto :goto_41

    :cond_3d
    invoke-direct {p0, v5}, Lcom/halo/decomp/TouchControls;->fade(I)I

    move-result v7

    :goto_41
    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setColor(I)V

    .line 1250
    iget-boolean v6, p0, Lcom/halo/decomp/TouchControls;->editMode:Z

    if-eqz v6, :cond_5e

    iget-object v6, p0, Lcom/halo/decomp/TouchControls;->selected:Lcom/halo/decomp/TouchControls$Button;

    if-ne v1, v6, :cond_5e

    .line 1251
    iget-object v6, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    const/16 v7, -0x2ab1

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setColor(I)V

    .line 1252
    iget-object v6, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    const/high16 v7, 0x40400000    # 3.0f

    iget v8, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v8, v7

    invoke-virtual {v6, v8}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    goto :goto_66

    .line 1254
    :cond_5e
    iget-object v6, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    iget v7, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v7, v2

    invoke-virtual {v6, v7}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    :goto_66
    if-nez v3, :cond_83

    .line 1257
    iget-object v6, p0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    iget v7, v1, Lcom/halo/decomp/TouchControls$Button;->pointer:I

    if-ltz v7, :cond_6f

    goto :goto_71

    :cond_6f
    const/high16 v5, 0x22000000

    :goto_71
    invoke-direct {p0, v5}, Lcom/halo/decomp/TouchControls;->fade(I)I

    move-result v5

    invoke-virtual {v6, v5}, Landroid/graphics/Paint;->setColor(I)V

    .line 1258
    iget v5, v1, Lcom/halo/decomp/TouchControls$Button;->cx:F

    iget v6, v1, Lcom/halo/decomp/TouchControls$Button;->cy:F

    iget v7, v1, Lcom/halo/decomp/TouchControls$Button;->r:F

    iget-object v8, p0, Lcom/halo/decomp/TouchControls;->fill:Landroid/graphics/Paint;

    invoke-virtual {p1, v5, v6, v7, v8}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1260
    :cond_83
    iget v5, v1, Lcom/halo/decomp/TouchControls$Button;->cx:F

    iget v6, v1, Lcom/halo/decomp/TouchControls$Button;->cy:F

    iget v7, v1, Lcom/halo/decomp/TouchControls$Button;->r:F

    iget-object v8, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    invoke-virtual {p1, v5, v6, v7, v8}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    if-nez v3, :cond_e0

    .line 1262
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    iget v5, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v5, v4

    iget v4, v1, Lcom/halo/decomp/TouchControls$Button;->r:F

    const v6, 0x3db851ec    # 0.09f

    mul-float/2addr v4, v6

    invoke-static {v5, v4}, Ljava/lang/Math;->max(FF)F

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1263
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    sget-object v4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1264
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    const/high16 v4, 0x66000000

    invoke-direct {p0, v4}, Lcom/halo/decomp/TouchControls;->fade(I)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 1265
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->pen:Lcom/halo/decomp/TouchControls$CanvasPen;

    iget v4, v1, Lcom/halo/decomp/TouchControls$Button;->icon:I

    iget v5, v1, Lcom/halo/decomp/TouchControls$Button;->cx:F

    iget v6, p0, Lcom/halo/decomp/TouchControls;->dp:F

    add-float/2addr v5, v6

    iget v6, v1, Lcom/halo/decomp/TouchControls$Button;->cy:F

    iget v7, p0, Lcom/halo/decomp/TouchControls;->dp:F

    add-float/2addr v6, v7

    iget v7, v1, Lcom/halo/decomp/TouchControls$Button;->r:F

    invoke-static {v3, v4, v5, v6, v7}, Lcom/halo/decomp/TouchIcons;->draw(Lcom/halo/decomp/TouchIcons$Pen;IFFF)V

    .line 1266
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;

    const v4, -0x22000001

    invoke-direct {p0, v4}, Lcom/halo/decomp/TouchControls;->fade(I)I

    move-result v4

    invoke-virtual {v3, v4}, Landroid/graphics/Paint;->setColor(I)V

    .line 1267
    iget-object v3, p0, Lcom/halo/decomp/TouchControls;->pen:Lcom/halo/decomp/TouchControls$CanvasPen;

    iget v4, v1, Lcom/halo/decomp/TouchControls$Button;->icon:I

    iget v5, v1, Lcom/halo/decomp/TouchControls$Button;->cx:F

    iget v6, v1, Lcom/halo/decomp/TouchControls$Button;->cy:F

    iget v1, v1, Lcom/halo/decomp/TouchControls$Button;->r:F

    invoke-static {v3, v4, v5, v6, v1}, Lcom/halo/decomp/TouchIcons;->draw(Lcom/halo/decomp/TouchIcons$Pen;IFFF)V

    :cond_e0
    :goto_e0
    add-int/lit8 v0, v0, 0x1

    goto/16 :goto_1d

    .line 1270
    :cond_e4
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    iget v1, p0, Lcom/halo/decomp/TouchControls;->dp:F

    mul-float/2addr v1, v4

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 1271
    iget-object v0, p0, Lcom/halo/decomp/TouchControls;->stroke:Landroid/graphics/Paint;

    invoke-direct {p0, v5}, Lcom/halo/decomp/TouchControls;->fade(I)I

    move-result v1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 1272
    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->editMode:Z

    if-eqz v0, :cond_fd

    .line 1273
    invoke-direct {p0, p1}, Lcom/halo/decomp/TouchControls;->drawEditBar(Landroid/graphics/Canvas;)V

    goto :goto_113

    .line 1275
    :cond_fd
    iget v3, p0, Lcom/halo/decomp/TouchControls;->movePointer:I

    iget v4, p0, Lcom/halo/decomp/TouchControls;->moveX:F

    iget v5, p0, Lcom/halo/decomp/TouchControls;->moveY:F

    iget v6, p0, Lcom/halo/decomp/TouchControls;->moveDX:F

    iget v7, p0, Lcom/halo/decomp/TouchControls;->moveDY:F

    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->stickRadius()F

    move-result v8

    move-object v1, p0

    move-object v2, p1

    invoke-direct/range {v1 .. v8}, Lcom/halo/decomp/TouchControls;->drawStick(Landroid/graphics/Canvas;IFFFFF)V

    .line 1276
    invoke-direct {p0, p1}, Lcom/halo/decomp/TouchControls;->drawGear(Landroid/graphics/Canvas;)V

    :goto_113
    return-void
.end method

.method public onInputDeviceAdded(I)V
    .registers 2

    .line 424
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->refreshActive()V

    return-void
.end method

.method public onInputDeviceChanged(I)V
    .registers 2

    .line 434
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->refreshActive()V

    return-void
.end method

.method public onInputDeviceRemoved(I)V
    .registers 2

    .line 429
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->refreshActive()V

    return-void
.end method

.method public onSensorChanged(Landroid/hardware/SensorEvent;)V
    .registers 16

    .line 784
    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->gyroOn:Z

    const-wide/16 v1, 0x0

    if-eqz v0, :cond_d4

    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->active:Z

    if-eqz v0, :cond_d4

    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->attached:Z

    if-eqz v0, :cond_d4

    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->editMode:Z

    if-nez v0, :cond_d4

    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->dialogOpen:Z

    if-eqz v0, :cond_18

    goto/16 :goto_d4

    .line 788
    :cond_18
    iget-object v0, p1, Landroid/hardware/SensorEvent;->values:[F

    const/4 v3, 0x0

    aget v0, v0, v3

    .line 789
    iget-object v4, p1, Landroid/hardware/SensorEvent;->values:[F

    const/4 v5, 0x1

    aget v4, v4, v5

    .line 790
    invoke-static {v0}, Ljava/lang/Float;->isNaN(F)Z

    move-result v6

    if-nez v6, :cond_d1

    invoke-static {v4}, Ljava/lang/Float;->isNaN(F)Z

    move-result v6

    if-nez v6, :cond_d1

    invoke-static {v0}, Ljava/lang/Float;->isInfinite(F)Z

    move-result v6

    if-nez v6, :cond_d1

    invoke-static {v4}, Ljava/lang/Float;->isInfinite(F)Z

    move-result v6

    if-eqz v6, :cond_3c

    goto/16 :goto_d1

    .line 794
    :cond_3c
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getDisplay()Landroid/view/Display;

    move-result-object v6

    if-nez v6, :cond_44

    move v6, v5

    goto :goto_48

    .line 795
    :cond_44
    invoke-virtual {v6}, Landroid/view/Display;->getRotation()I

    move-result v6

    :goto_48
    const/4 v7, 0x2

    if-eq v6, v5, :cond_59

    if-eq v6, v7, :cond_53

    const/4 v8, 0x3

    if-eq v6, v8, :cond_51

    goto :goto_55

    :cond_51
    neg-float v0, v0

    goto :goto_5a

    :cond_53
    neg-float v4, v4

    neg-float v0, v0

    :goto_55
    move v13, v4

    move v4, v0

    move v0, v13

    goto :goto_5a

    :cond_59
    neg-float v4, v4

    .line 817
    :goto_5a
    invoke-static {v0}, Ljava/lang/Math;->abs(F)F

    move-result v8

    const v9, 0x3c23d70a    # 0.01f

    cmpg-float v8, v8, v9

    const/4 v10, 0x0

    if-gez v8, :cond_67

    move v0, v10

    .line 820
    :cond_67
    invoke-static {v4}, Ljava/lang/Math;->abs(F)F

    move-result v8

    cmpg-float v8, v8, v9

    if-gez v8, :cond_70

    move v4, v10

    .line 823
    :cond_70
    iget-wide v8, p1, Landroid/hardware/SensorEvent;->timestamp:J

    iget-wide v11, p0, Lcom/halo/decomp/TouchControls;->gyroPrevTime:J

    sub-long/2addr v8, v11

    long-to-float v8, v8

    const v9, 0x3089705f    # 1.0E-9f

    mul-float/2addr v8, v9

    cmp-long v1, v11, v1

    if-eqz v1, :cond_8e

    .line 824
    iget v1, p0, Lcom/halo/decomp/TouchControls;->gyroPrevRotation:I

    if-ne v6, v1, :cond_8e

    cmpl-float v1, v8, v10

    if-lez v1, :cond_8e

    const v1, 0x3dcccccd    # 0.1f

    cmpg-float v1, v8, v1

    if-gtz v1, :cond_8e

    move v3, v5

    .line 825
    :cond_8e
    iget v1, p0, Lcom/halo/decomp/TouchControls;->gyroPrevUp:F

    .line 826
    iget v2, p0, Lcom/halo/decomp/TouchControls;->gyroPrevRight:F

    .line 827
    iget-wide v11, p1, Landroid/hardware/SensorEvent;->timestamp:J

    iput-wide v11, p0, Lcom/halo/decomp/TouchControls;->gyroPrevTime:J

    .line 828
    iput v6, p0, Lcom/halo/decomp/TouchControls;->gyroPrevRotation:I

    .line 829
    iput v0, p0, Lcom/halo/decomp/TouchControls;->gyroPrevUp:F

    .line 830
    iput v4, p0, Lcom/halo/decomp/TouchControls;->gyroPrevRight:F

    if-nez v3, :cond_9f

    return-void

    :cond_9f
    const/high16 p1, 0x44160000    # 600.0f

    .line 837
    iget v3, p0, Lcom/halo/decomp/TouchControls;->gyroSens:F

    mul-float/2addr v3, p1

    add-float/2addr v0, v1

    neg-float p1, v0

    const/high16 v0, 0x3f000000    # 0.5f

    mul-float/2addr p1, v0

    mul-float/2addr p1, v8

    mul-float/2addr p1, v3

    .line 838
    iget-boolean v1, p0, Lcom/halo/decomp/TouchControls;->gyroInvertX:Z

    const/high16 v6, -0x40800000    # -1.0f

    const/high16 v9, 0x3f800000    # 1.0f

    if-eqz v1, :cond_b5

    move v1, v6

    goto :goto_b6

    :cond_b5
    move v1, v9

    :goto_b6
    mul-float/2addr p1, v1

    add-float/2addr v4, v2

    neg-float v1, v4

    mul-float/2addr v1, v0

    mul-float/2addr v1, v8

    mul-float/2addr v1, v3

    .line 839
    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->gyroInvertY:Z

    if-eqz v0, :cond_c1

    goto :goto_c2

    :cond_c1
    move v6, v9

    :goto_c2
    mul-float/2addr v1, v6

    cmpl-float v0, p1, v10

    if-nez v0, :cond_cb

    cmpl-float v0, v1, v10

    if-eqz v0, :cond_d0

    .line 841
    :cond_cb
    iget v0, p0, Lcom/halo/decomp/TouchControls;->mouseState:I

    invoke-static {v0, v7, p1, v1, v5}, Lorg/libsdl/app/SDLActivity;->onNativeMouse(IIFFZ)V

    :cond_d0
    return-void

    .line 791
    :cond_d1
    :goto_d1
    iput-wide v1, p0, Lcom/halo/decomp/TouchControls;->gyroPrevTime:J

    return-void

    .line 785
    :cond_d4
    :goto_d4
    iput-wide v1, p0, Lcom/halo/decomp/TouchControls;->gyroPrevTime:J

    return-void
.end method

.method protected onSizeChanged(IIII)V
    .registers 5

    .line 441
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->layout()V

    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .registers 13

    .line 546
    iget-boolean v0, p0, Lcom/halo/decomp/TouchControls;->editMode:Z

    if-eqz v0, :cond_9

    .line 547
    invoke-direct {p0, p1}, Lcom/halo/decomp/TouchControls;->editTouch(Landroid/view/MotionEvent;)Z

    move-result p1

    return p1

    .line 549
    :cond_9
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    move-result v0

    .line 550
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-eqz v0, :cond_101

    const/4 v5, 0x3

    if-eq v0, v4, :cond_b0

    const/4 v6, 0x2

    if-eq v0, v6, :cond_2b

    if-eq v0, v5, :cond_b0

    const/4 v6, 0x5

    if-eq v0, v6, :cond_101

    const/4 v6, 0x6

    if-eq v0, v6, :cond_b0

    .line 651
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->push()V

    .line 652
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return v4

    :cond_2b
    move v0, v3

    .line 618
    :goto_2c
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getPointerCount()I

    move-result v1

    if-ge v0, v1, :cond_a9

    .line 619
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v1

    .line 620
    iget v2, p0, Lcom/halo/decomp/TouchControls;->movePointer:I

    const v5, 0x3f8ccccd    # 1.1f

    if-ne v1, v2, :cond_5c

    .line 621
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v2

    iget v6, p0, Lcom/halo/decomp/TouchControls;->moveX:F

    sub-float/2addr v2, v6

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v6

    iget v7, p0, Lcom/halo/decomp/TouchControls;->moveY:F

    sub-float/2addr v6, v7

    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->stickRadius()F

    move-result v7

    invoke-static {v2, v6, v7}, Lcom/halo/decomp/TouchControls;->stick(FFF)[F

    move-result-object v2

    .line 622
    aget v6, v2, v3

    iput v6, p0, Lcom/halo/decomp/TouchControls;->moveDX:F

    .line 623
    aget v2, v2, v4

    iput v2, p0, Lcom/halo/decomp/TouchControls;->moveDY:F

    goto :goto_89

    :cond_5c
    move v2, v3

    .line 625
    :goto_5d
    iget-object v6, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v7, v6

    if-ge v2, v7, :cond_89

    .line 626
    aget-object v6, v6, v2

    .line 627
    iget v7, v6, Lcom/halo/decomp/TouchControls$Button;->pointer:I

    if-ne v7, v1, :cond_86

    iget v7, v6, Lcom/halo/decomp/TouchControls$Button;->code:I

    const/4 v8, -0x2

    if-ne v7, v8, :cond_86

    .line 628
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v7

    .line 629
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v8

    .line 630
    iget v9, v6, Lcom/halo/decomp/TouchControls$Button;->lastX:F

    sub-float v9, v7, v9

    mul-float/2addr v9, v5

    iget v10, v6, Lcom/halo/decomp/TouchControls$Button;->lastY:F

    sub-float v10, v8, v10

    mul-float/2addr v10, v5

    invoke-direct {p0, v9, v10}, Lcom/halo/decomp/TouchControls;->look(FF)V

    .line 631
    iput v7, v6, Lcom/halo/decomp/TouchControls$Button;->lastX:F

    .line 632
    iput v8, v6, Lcom/halo/decomp/TouchControls$Button;->lastY:F

    :cond_86
    add-int/lit8 v2, v2, 0x1

    goto :goto_5d

    .line 636
    :cond_89
    :goto_89
    iget v2, p0, Lcom/halo/decomp/TouchControls;->lookPointer:I

    if-ne v1, v2, :cond_a6

    .line 637
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v1

    .line 638
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result v2

    .line 639
    iget v6, p0, Lcom/halo/decomp/TouchControls;->lookX:F

    sub-float v6, v1, v6

    mul-float/2addr v6, v5

    .line 640
    iget v7, p0, Lcom/halo/decomp/TouchControls;->lookY:F

    sub-float v7, v2, v7

    mul-float/2addr v7, v5

    .line 641
    iput v1, p0, Lcom/halo/decomp/TouchControls;->lookX:F

    .line 642
    iput v2, p0, Lcom/halo/decomp/TouchControls;->lookY:F

    .line 643
    invoke-direct {p0, v6, v7}, Lcom/halo/decomp/TouchControls;->look(FF)V

    :cond_a6
    add-int/lit8 v0, v0, 0x1

    goto :goto_2c

    .line 646
    :cond_a9
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->push()V

    .line 647
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return v4

    .line 587
    :cond_b0
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v6

    if-ne v0, v5, :cond_ba

    .line 589
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->releaseAll()V

    return v4

    .line 592
    :cond_ba
    iget v0, p0, Lcom/halo/decomp/TouchControls;->gearPointer:I

    const/4 v5, -0x1

    if-ne v6, v0, :cond_d6

    .line 593
    iput v5, p0, Lcom/halo/decomp/TouchControls;->gearPointer:I

    .line 594
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getX(I)F

    move-result v0

    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getY(I)F

    move-result p1

    invoke-direct {p0, v0, p1}, Lcom/halo/decomp/TouchControls;->gearHit(FF)Z

    move-result p1

    if-eqz p1, :cond_d2

    .line 595
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->openSettings()V

    .line 597
    :cond_d2
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return v4

    .line 600
    :cond_d6
    :goto_d6
    iget-object p1, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    array-length v0, p1

    if-ge v3, v0, :cond_ea

    .line 601
    aget-object p1, p1, v3

    iget p1, p1, Lcom/halo/decomp/TouchControls$Button;->pointer:I

    if-ne p1, v6, :cond_e7

    .line 602
    iget-object p1, p0, Lcom/halo/decomp/TouchControls;->buttons:[Lcom/halo/decomp/TouchControls$Button;

    aget-object p1, p1, v3

    iput v5, p1, Lcom/halo/decomp/TouchControls$Button;->pointer:I

    :cond_e7
    add-int/lit8 v3, v3, 0x1

    goto :goto_d6

    .line 605
    :cond_ea
    iget p1, p0, Lcom/halo/decomp/TouchControls;->movePointer:I

    if-ne v6, p1, :cond_f4

    .line 606
    iput v5, p0, Lcom/halo/decomp/TouchControls;->movePointer:I

    .line 607
    iput v2, p0, Lcom/halo/decomp/TouchControls;->moveDY:F

    .line 608
    iput v2, p0, Lcom/halo/decomp/TouchControls;->moveDX:F

    .line 610
    :cond_f4
    iget p1, p0, Lcom/halo/decomp/TouchControls;->lookPointer:I

    if-ne v6, p1, :cond_fa

    .line 611
    iput v5, p0, Lcom/halo/decomp/TouchControls;->lookPointer:I

    .line 613
    :cond_fa
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->push()V

    .line 614
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return v4

    .line 554
    :cond_101
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v0

    .line 555
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getX(I)F

    move-result v5

    .line 556
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getY(I)F

    move-result p1

    .line 557
    iget v1, p0, Lcom/halo/decomp/TouchControls;->gearPointer:I

    if-gez v1, :cond_11d

    invoke-direct {p0, v5, p1}, Lcom/halo/decomp/TouchControls;->gearHit(FF)Z

    move-result v1

    if-eqz v1, :cond_11d

    .line 558
    iput v0, p0, Lcom/halo/decomp/TouchControls;->gearPointer:I

    .line 559
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return v4

    .line 562
    :cond_11d
    invoke-direct {p0, v5, p1, v3}, Lcom/halo/decomp/TouchControls;->hit(FFZ)Lcom/halo/decomp/TouchControls$Button;

    move-result-object v1

    if-eqz v1, :cond_12a

    .line 564
    iput v0, v1, Lcom/halo/decomp/TouchControls$Button;->pointer:I

    .line 565
    iput v5, v1, Lcom/halo/decomp/TouchControls$Button;->lastX:F

    .line 566
    iput p1, v1, Lcom/halo/decomp/TouchControls$Button;->lastY:F

    goto :goto_150

    .line 567
    :cond_12a
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->getWidth()I

    move-result v1

    int-to-float v1, v1

    const v3, 0x3ed70a3d    # 0.42f

    mul-float/2addr v1, v3

    cmpg-float v1, v5, v1

    if-gez v1, :cond_146

    .line 568
    iget v1, p0, Lcom/halo/decomp/TouchControls;->movePointer:I

    if-gez v1, :cond_150

    .line 569
    iput v0, p0, Lcom/halo/decomp/TouchControls;->movePointer:I

    .line 570
    iput v5, p0, Lcom/halo/decomp/TouchControls;->moveX:F

    .line 571
    iput p1, p0, Lcom/halo/decomp/TouchControls;->moveY:F

    .line 572
    iput v2, p0, Lcom/halo/decomp/TouchControls;->moveDY:F

    .line 573
    iput v2, p0, Lcom/halo/decomp/TouchControls;->moveDX:F

    goto :goto_150

    .line 575
    :cond_146
    iget v1, p0, Lcom/halo/decomp/TouchControls;->lookPointer:I

    if-gez v1, :cond_150

    .line 576
    iput v0, p0, Lcom/halo/decomp/TouchControls;->lookPointer:I

    .line 577
    iput v5, p0, Lcom/halo/decomp/TouchControls;->lookX:F

    .line 578
    iput p1, p0, Lcom/halo/decomp/TouchControls;->lookY:F

    .line 580
    :cond_150
    :goto_150
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->push()V

    .line 581
    invoke-virtual {p0}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return v4
.end method

.method public onWindowFocusChanged(Z)V
    .registers 2

    .line 417
    invoke-super {p0, p1}, Landroid/view/View;->onWindowFocusChanged(Z)V

    .line 418
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->releaseAll()V

    .line 419
    invoke-direct {p0}, Lcom/halo/decomp/TouchControls;->updateGyro()V

    return-void
.end method
