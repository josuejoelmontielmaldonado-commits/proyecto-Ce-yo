.class final Lcom/halo/decomp/TouchControls$CanvasPen;
.super Ljava/lang/Object;
.source "TouchControls.java"

# interfaces
.implements Lcom/halo/decomp/TouchIcons$Pen;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/halo/decomp/TouchControls;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x12
    name = "CanvasPen"
.end annotation


# instance fields
.field private final box:Landroid/graphics/RectF;

.field c:Landroid/graphics/Canvas;

.field private final path:Landroid/graphics/Path;

.field final synthetic this$0:Lcom/halo/decomp/TouchControls;


# direct methods
.method private constructor <init>(Lcom/halo/decomp/TouchControls;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            null
        }
    .end annotation

    .line 1193
    iput-object p1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 1194
    new-instance p1, Landroid/graphics/Path;

    invoke-direct {p1}, Landroid/graphics/Path;-><init>()V

    iput-object p1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->path:Landroid/graphics/Path;

    .line 1195
    new-instance p1, Landroid/graphics/RectF;

    invoke-direct {p1}, Landroid/graphics/RectF;-><init>()V

    iput-object p1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->box:Landroid/graphics/RectF;

    return-void
.end method

.method synthetic constructor <init>(Lcom/halo/decomp/TouchControls;Lcom/halo/decomp/TouchControls$1;)V
    .registers 3

    .line 1188
    invoke-direct {p0, p1}, Lcom/halo/decomp/TouchControls$CanvasPen;-><init>(Lcom/halo/decomp/TouchControls;)V

    return-void
.end method


# virtual methods
.method public arc(FFFFF)V
    .registers 15

    .line 1212
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->box:Landroid/graphics/RectF;

    sub-float v1, p1, p3

    sub-float v2, p2, p3

    add-float/2addr p1, p3

    add-float/2addr p2, p3

    invoke-virtual {v0, v1, v2, p1, p2}, Landroid/graphics/RectF;->set(FFFF)V

    .line 1213
    iget-object v3, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->c:Landroid/graphics/Canvas;

    iget-object v4, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->box:Landroid/graphics/RectF;

    iget-object p1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {p1}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object v8

    const/4 v7, 0x0

    move v5, p4

    move v6, p5

    invoke-virtual/range {v3 .. v8}, Landroid/graphics/Canvas;->drawArc(Landroid/graphics/RectF;FFZLandroid/graphics/Paint;)V

    return-void
.end method

.method public circle(FFFZ)V
    .registers 6

    .line 1205
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object v0

    if-eqz p4, :cond_b

    sget-object p4, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    goto :goto_d

    :cond_b
    sget-object p4, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    :goto_d
    invoke-virtual {v0, p4}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1206
    iget-object p4, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->c:Landroid/graphics/Canvas;

    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object v0

    invoke-virtual {p4, p1, p2, p3, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    .line 1207
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {p1}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object p1

    sget-object p2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    return-void
.end method

.method public line(FFFF)V
    .registers 11

    .line 1200
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->c:Landroid/graphics/Canvas;

    iget-object v1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {v1}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object v5

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    return-void
.end method

.method public polygon([F)V
    .registers 6

    .line 1218
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->path:Landroid/graphics/Path;

    invoke-virtual {v0}, Landroid/graphics/Path;->reset()V

    .line 1219
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->path:Landroid/graphics/Path;

    const/4 v1, 0x0

    aget v1, p1, v1

    const/4 v2, 0x1

    aget v2, p1, v2

    invoke-virtual {v0, v1, v2}, Landroid/graphics/Path;->moveTo(FF)V

    const/4 v0, 0x2

    .line 1220
    :goto_11
    array-length v1, p1

    if-ge v0, v1, :cond_22

    .line 1221
    iget-object v1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->path:Landroid/graphics/Path;

    aget v2, p1, v0

    add-int/lit8 v3, v0, 0x1

    aget v3, p1, v3

    invoke-virtual {v1, v2, v3}, Landroid/graphics/Path;->lineTo(FF)V

    add-int/lit8 v0, v0, 0x2

    goto :goto_11

    .line 1223
    :cond_22
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->path:Landroid/graphics/Path;

    invoke-virtual {p1}, Landroid/graphics/Path;->close()V

    .line 1224
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {p1}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object p1

    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1225
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->c:Landroid/graphics/Canvas;

    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->path:Landroid/graphics/Path;

    iget-object v1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {v1}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object v1

    invoke-virtual {p1, v0, v1}, Landroid/graphics/Canvas;->drawPath(Landroid/graphics/Path;Landroid/graphics/Paint;)V

    .line 1226
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {p1}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object p1

    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    return-void
.end method

.method public rect(FFFF)V
    .registers 15

    .line 1231
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object v0

    sget-object v1, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 1232
    iget-object v2, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->c:Landroid/graphics/Canvas;

    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->dp:F
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$2700(Lcom/halo/decomp/TouchControls;)F

    move-result v0

    const/high16 v1, 0x40000000    # 2.0f

    mul-float v7, v0, v1

    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->dp:F
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$2700(Lcom/halo/decomp/TouchControls;)F

    move-result v0

    mul-float v8, v0, v1

    iget-object v0, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {v0}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object v9

    move v3, p1

    move v4, p2

    move v5, p3

    move v6, p4

    invoke-virtual/range {v2 .. v9}, Landroid/graphics/Canvas;->drawRoundRect(FFFFFFLandroid/graphics/Paint;)V

    .line 1233
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$CanvasPen;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->icon:Landroid/graphics/Paint;
    invoke-static {p1}, Lcom/halo/decomp/TouchControls;->access$2600(Lcom/halo/decomp/TouchControls;)Landroid/graphics/Paint;

    move-result-object p1

    sget-object p2, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p1, p2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    return-void
.end method
