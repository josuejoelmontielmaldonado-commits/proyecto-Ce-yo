.class Lcom/halo/decomp/TouchControls$5;
.super Lcom/halo/decomp/TouchControls$Seek;
.source "TouchControls.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/halo/decomp/TouchControls;->openSettings()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/halo/decomp/TouchControls;

.field final synthetic val$gyroLabel:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lcom/halo/decomp/TouchControls;Landroid/widget/TextView;)V
    .registers 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 936
    iput-object p1, p0, Lcom/halo/decomp/TouchControls$5;->this$0:Lcom/halo/decomp/TouchControls;

    iput-object p2, p0, Lcom/halo/decomp/TouchControls$5;->val$gyroLabel:Landroid/widget/TextView;

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/halo/decomp/TouchControls$Seek;-><init>(Lcom/halo/decomp/TouchControls;Lcom/halo/decomp/TouchControls$1;)V

    return-void
.end method


# virtual methods
.method changed(I)V
    .registers 7

    .line 939
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$5;->this$0:Lcom/halo/decomp/TouchControls;

    int-to-double v1, p1

    const-wide/high16 v3, 0x4059000000000000L    # 100.0

    div-double/2addr v1, v3

    const-wide/high16 v3, 0x4030000000000000L    # 16.0

    invoke-static {v3, v4, v1, v2}, Ljava/lang/Math;->pow(DD)D

    move-result-wide v1

    double-to-float p1, v1

    const/high16 v1, 0x3e800000    # 0.25f

    mul-float/2addr p1, v1

    const/high16 v2, 0x40800000    # 4.0f

    # invokes: Lcom/halo/decomp/TouchControls;->clamp(FFF)F
    invoke-static {p1, v1, v2}, Lcom/halo/decomp/TouchControls;->access$1300(FFF)F

    move-result p1

    # setter for: Lcom/halo/decomp/TouchControls;->gyroSens:F
    invoke-static {v0, p1}, Lcom/halo/decomp/TouchControls;->access$1602(Lcom/halo/decomp/TouchControls;F)F

    .line 940
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$5;->val$gyroLabel:Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Sensibilidad del giroscopio: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/halo/decomp/TouchControls$5;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->gyroSens:F
    invoke-static {v1}, Lcom/halo/decomp/TouchControls;->access$1600(Lcom/halo/decomp/TouchControls;)F

    move-result v1

    # invokes: Lcom/halo/decomp/TouchControls;->times(F)Ljava/lang/String;
    invoke-static {v1}, Lcom/halo/decomp/TouchControls;->access$1400(F)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    return-void
.end method
