.class Lcom/halo/decomp/TouchControls$2;
.super Lcom/halo/decomp/TouchControls$Seek;
.source "TouchControls.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/halo/decomp/TouchControls;->openSettings()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/halo/decomp/TouchControls;

.field final synthetic val$sizeLabel:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lcom/halo/decomp/TouchControls;Landroid/widget/TextView;)V
    .registers 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 892
    iput-object p1, p0, Lcom/halo/decomp/TouchControls$2;->this$0:Lcom/halo/decomp/TouchControls;

    iput-object p2, p0, Lcom/halo/decomp/TouchControls$2;->val$sizeLabel:Landroid/widget/TextView;

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/halo/decomp/TouchControls$Seek;-><init>(Lcom/halo/decomp/TouchControls;Lcom/halo/decomp/TouchControls$1;)V

    return-void
.end method


# virtual methods
.method changed(I)V
    .registers 4

    .line 895
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$2;->this$0:Lcom/halo/decomp/TouchControls;

    add-int/lit8 p1, p1, 0x32

    int-to-float p1, p1

    const/high16 v1, 0x42c80000    # 100.0f

    div-float/2addr p1, v1

    # setter for: Lcom/halo/decomp/TouchControls;->size:F
    invoke-static {v0, p1}, Lcom/halo/decomp/TouchControls;->access$902(Lcom/halo/decomp/TouchControls;F)F

    .line 896
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$2;->val$sizeLabel:Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Tama\u00f1o de botones: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/halo/decomp/TouchControls$2;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->size:F
    invoke-static {v1}, Lcom/halo/decomp/TouchControls;->access$900(Lcom/halo/decomp/TouchControls;)F

    move-result v1

    # invokes: Lcom/halo/decomp/TouchControls;->pct(F)Ljava/lang/String;
    invoke-static {v1}, Lcom/halo/decomp/TouchControls;->access$1000(F)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 897
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$2;->this$0:Lcom/halo/decomp/TouchControls;

    # invokes: Lcom/halo/decomp/TouchControls;->layout()V
    invoke-static {p1}, Lcom/halo/decomp/TouchControls;->access$1100(Lcom/halo/decomp/TouchControls;)V

    .line 898
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$2;->this$0:Lcom/halo/decomp/TouchControls;

    invoke-virtual {p1}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return-void
.end method
