.class abstract Lcom/halo/decomp/TouchControls$Seek;
.super Ljava/lang/Object;
.source "TouchControls.java"

# interfaces
.implements Landroid/widget/SeekBar$OnSeekBarChangeListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/halo/decomp/TouchControls;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x402
    name = "Seek"
.end annotation


# instance fields
.field final synthetic this$0:Lcom/halo/decomp/TouchControls;


# direct methods
.method private constructor <init>(Lcom/halo/decomp/TouchControls;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            null
        }
    .end annotation

    .line 847
    iput-object p1, p0, Lcom/halo/decomp/TouchControls$Seek;->this$0:Lcom/halo/decomp/TouchControls;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method synthetic constructor <init>(Lcom/halo/decomp/TouchControls;Lcom/halo/decomp/TouchControls$1;)V
    .registers 3

    .line 847
    invoke-direct {p0, p1}, Lcom/halo/decomp/TouchControls$Seek;-><init>(Lcom/halo/decomp/TouchControls;)V

    return-void
.end method


# virtual methods
.method abstract changed(I)V
.end method

.method public onProgressChanged(Landroid/widget/SeekBar;IZ)V
    .registers 4

    if-eqz p3, :cond_5

    .line 853
    invoke-virtual {p0, p2}, Lcom/halo/decomp/TouchControls$Seek;->changed(I)V

    :cond_5
    return-void
.end method

.method public onStartTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2

    return-void
.end method

.method public onStopTrackingTouch(Landroid/widget/SeekBar;)V
    .registers 2

    .line 863
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$Seek;->this$0:Lcom/halo/decomp/TouchControls;

    # invokes: Lcom/halo/decomp/TouchControls;->saveSettings()V
    invoke-static {p1}, Lcom/halo/decomp/TouchControls;->access$700(Lcom/halo/decomp/TouchControls;)V

    return-void
.end method
