.class Lcom/halo/decomp/TouchControls$12;
.super Ljava/lang/Object;
.source "TouchControls.java"

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/halo/decomp/TouchControls;->openSettings()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/halo/decomp/TouchControls;


# direct methods
.method constructor <init>(Lcom/halo/decomp/TouchControls;)V
    .registers 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            null
        }
    .end annotation

    .line 1006
    iput-object p1, p0, Lcom/halo/decomp/TouchControls$12;->this$0:Lcom/halo/decomp/TouchControls;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .registers 3

    .line 1009
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$12;->this$0:Lcom/halo/decomp/TouchControls;

    # invokes: Lcom/halo/decomp/TouchControls;->enterEdit()V
    invoke-static {p1}, Lcom/halo/decomp/TouchControls;->access$2400(Lcom/halo/decomp/TouchControls;)V

    return-void
.end method
