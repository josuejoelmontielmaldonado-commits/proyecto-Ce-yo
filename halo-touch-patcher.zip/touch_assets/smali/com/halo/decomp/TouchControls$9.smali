.class Lcom/halo/decomp/TouchControls$9;
.super Lcom/halo/decomp/TouchControls$Seek;
.source "TouchControls.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/halo/decomp/TouchControls;->openSettings()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lcom/halo/decomp/TouchControls;

.field final synthetic val$opacityLabel:Landroid/widget/TextView;


# direct methods
.method constructor <init>(Lcom/halo/decomp/TouchControls;Landroid/widget/TextView;)V
    .registers 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010,
            0x1010
        }
        names = {
            null,
            null
        }
    .end annotation

    .line 987
    iput-object p1, p0, Lcom/halo/decomp/TouchControls$9;->this$0:Lcom/halo/decomp/TouchControls;

    iput-object p2, p0, Lcom/halo/decomp/TouchControls$9;->val$opacityLabel:Landroid/widget/TextView;

    const/4 p2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/halo/decomp/TouchControls$Seek;-><init>(Lcom/halo/decomp/TouchControls;Lcom/halo/decomp/TouchControls$1;)V

    return-void
.end method


# virtual methods
.method changed(I)V
    .registers 4

    .line 990
    iget-object v0, p0, Lcom/halo/decomp/TouchControls$9;->this$0:Lcom/halo/decomp/TouchControls;

    add-int/lit8 p1, p1, 0x1e

    int-to-float p1, p1

    const/high16 v1, 0x42c80000    # 100.0f

    div-float/2addr p1, v1

    # setter for: Lcom/halo/decomp/TouchControls;->opacity:F
    invoke-static {v0, p1}, Lcom/halo/decomp/TouchControls;->access$2002(Lcom/halo/decomp/TouchControls;F)F

    .line 991
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$9;->val$opacityLabel:Landroid/widget/TextView;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "Opacidad de los botones: "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    iget-object v1, p0, Lcom/halo/decomp/TouchControls$9;->this$0:Lcom/halo/decomp/TouchControls;

    # getter for: Lcom/halo/decomp/TouchControls;->opacity:F
    invoke-static {v1}, Lcom/halo/decomp/TouchControls;->access$2000(Lcom/halo/decomp/TouchControls;)F

    move-result v1

    # invokes: Lcom/halo/decomp/TouchControls;->pct(F)Ljava/lang/String;
    invoke-static {v1}, Lcom/halo/decomp/TouchControls;->access$1000(F)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {p1, v0}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    .line 992
    iget-object p1, p0, Lcom/halo/decomp/TouchControls$9;->this$0:Lcom/halo/decomp/TouchControls;

    invoke-virtual {p1}, Lcom/halo/decomp/TouchControls;->invalidate()V

    return-void
.end method
