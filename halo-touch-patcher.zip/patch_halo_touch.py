#!/usr/bin/env python3
"""
patch_halo_touch.py

Agrega controles tactiles a un release oficial de Halo CE Universal para Android
(halo-android-release.zip o app-release.apk), lo alinea, lo firma con TU llave y
deja un APK listo para instalar.

Que hace, en orden:
  1. Lee el AndroidManifest (paquete, versionCode) y comprueba que el APK aun no
     tenga la capa tactil.
  2. Desarma el codigo con apktool (sin tocar los recursos).
  3. Copia las clases tactiles (TouchControls*, TouchIcons*) y agrega una linea
     a HaloActivity.onCreate: TouchControls.install(this).
  4. Opcional: cambia el repositorio de actualizaciones del juego (--update-repo)
     o lo desactiva. Sin esto, el actualizador del juego ofreceria el APK oficial,
     que lleva otra firma y Android no lo instalaria encima.
  5. Rearma classes.dex y reconstruye el ZIP conservando byte a byte todo lo demas
     (manifiesto, recursos, libreria nativa, motor), agrega libhalotouch.so con la
     alineacion que Android exige y firma con apksigner (esquema v3; minSdk 28 no lleva v2).

Requisitos: Python 3.8+, Java 17+ (java y keytool en el PATH). Las herramientas
apktool y apksigner se descargan solas de GitHub la primera vez (carpeta tools/).

Uso:
  python3 patch_halo_touch.py halo-android-release.zip -o halo-touch.apk \
      --keystore halo-touch.p12 --create-keystore
  python3 patch_halo_touch.py halo-android-release.zip -o halo-touch.apk \
      --keystore halo-touch.p12            (la clave se pide por HALO_KS_PASS)
"""

import argparse
import getpass
import os
import re
import secrets
import shutil
import string
import struct
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
TOOLS = HERE / "tools"
ASSETS = HERE / "touch_assets"

APKTOOL_URL = "https://github.com/iBotPeaches/Apktool/releases/download/v2.10.0/apktool_2.10.0.jar"
UBER_URL = "https://github.com/patrickfav/uber-apk-signer/releases/download/v1.3.0/uber-apk-signer-1.3.0.jar"
SIGNER_ENTRY = "lib/apksigner_33_0_2.jar"

HOOK = "    invoke-static {p0}, Lcom/halo/decomp/TouchControls;->install(Landroid/app/Activity;)V\n\n"
HOOK_ANCHOR = "    invoke-static {p0}, Lcom/halo/decomp/Updater;->start(Landroid/app/Activity;)V"

# El proyecto cambio de repositorio (cybersecurity/halo-ce-universal en la build 74,
# OpenCommunityEdition/OpenCE en la 125). En vez de fijar un nombre, se lee del
# propio Updater.smali y se exige que la API y la descarga apunten al mismo.
_REPO = r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"
API_RE = re.compile(r"https://api\.github\.com/repos/(" + _REPO + r")/releases/latest")
DOWNLOAD_RE = re.compile(r"https://github\.com/(" + _REPO + r")/releases/download/build-")
# .invalid es un dominio reservado (RFC 2606): nunca resuelve, asi nadie puede
# registrarlo y servir actualizaciones falsas.
DISABLED_API = "https://updates.invalid/halo/releases/latest"
DISABLED_DOWNLOAD = "https://updates.invalid/halo/download/build-"


def log(message):
    print(message, flush=True)


def fail(message):
    print("ERROR: " + message, file=sys.stderr)
    sys.exit(1)


def run(command, **kwargs):
    result = subprocess.run(command, capture_output=True, text=True, **kwargs)
    if result.returncode != 0:
        fail("fallo %s\n%s\n%s" % (" ".join(map(str, command[:3])), result.stdout[-1500:], result.stderr[-1500:]))
    return result.stdout


# ---------------------------------------------------------------- herramientas

def fetch_tools():
    TOOLS.mkdir(exist_ok=True)
    apktool = TOOLS / "apktool.jar"
    signer = TOOLS / "apksigner.jar"
    if not apktool.exists():
        log("Descargando apktool...")
        urllib.request.urlretrieve(APKTOOL_URL, apktool)
    if not signer.exists():
        log("Descargando apksigner...")
        uber = TOOLS / "uber.jar"
        urllib.request.urlretrieve(UBER_URL, uber)
        with zipfile.ZipFile(uber) as z:
            signer.write_bytes(z.read(SIGNER_ENTRY))
        uber.unlink()
    return apktool, signer


# ------------------------------------------------------------------- manifiesto

def manifest_info(axml):
    """Lee package, versionCode y versionName del AndroidManifest binario."""
    strings = []
    pos = 8
    while pos < len(axml):
        ctype, hsize, size = struct.unpack_from("<HHI", axml, pos)
        if ctype == 0x0001:
            count, _styles, flags, str_start, _ss = struct.unpack_from("<5I", axml, pos + 8)
            utf8 = bool(flags & 0x100)
            offsets = struct.unpack_from("<%dI" % count, axml, pos + hsize)
            base = pos + str_start
            for offset in offsets:
                p = base + offset
                if utf8:
                    n = axml[p]
                    p += 2 if n & 0x80 else 1
                    n = axml[p]
                    p += 1
                    if n & 0x80:
                        n = ((n & 0x7F) << 8) | axml[p]
                        p += 1
                    strings.append(axml[p:p + n].decode("utf-8", "replace"))
                else:
                    n = struct.unpack_from("<H", axml, p)[0]
                    p += 2
                    if n & 0x8000:
                        n = ((n & 0x7FFF) << 16) | struct.unpack_from("<H", axml, p)[0]
                        p += 2
                    strings.append(axml[p:p + 2 * n].decode("utf-16le", "replace"))
        elif ctype == 0x0102:
            attr_start, attr_size, attr_count = struct.unpack_from("<HHH", axml, pos + 24)
            info = {}
            for i in range(attr_count):
                a = pos + 16 + attr_start + i * attr_size
                _ns, name, raw, _sz, _r0, dtype, data = struct.unpack_from("<IIIHBBI", axml, a)
                key = strings[name]
                if dtype == 0x03:
                    info[key] = strings[data if raw == 0xFFFFFFFF else raw]
                else:
                    info[key] = data
            return info
        pos += size
    fail("no pude leer el AndroidManifest")


def set_version_code(axml, new_code):
    """Cambia el valor de versionCode en el AndroidManifest binario (mismo tamano, sin reconstruir)."""
    data = bytearray(axml)
    strings = []
    pos = 8
    while pos < len(data):
        ctype, hsize, size = struct.unpack_from("<HHI", data, pos)
        if ctype == 0x0001:
            count, _styles, flags, str_start, _ss = struct.unpack_from("<5I", data, pos + 8)
            utf8 = bool(flags & 0x100)
            offsets = struct.unpack_from("<%dI" % count, data, pos + hsize)
            base = pos + str_start
            for offset in offsets:
                p = base + offset
                if utf8:
                    n = data[p]
                    p += 2 if n & 0x80 else 1
                    n = data[p]
                    p += 1
                    if n & 0x80:
                        n = ((n & 0x7F) << 8) | data[p]
                        p += 1
                    strings.append(bytes(data[p:p + n]).decode("utf-8", "replace"))
                else:
                    n = struct.unpack_from("<H", data, p)[0]
                    p += 2
                    if n & 0x8000:
                        n = ((n & 0x7FFF) << 16) | struct.unpack_from("<H", data, p)[0]
                        p += 2
                    strings.append(bytes(data[p:p + 2 * n]).decode("utf-16le", "replace"))
        elif ctype == 0x0102:
            attr_start, attr_size, attr_count = struct.unpack_from("<HHH", data, pos + 24)
            for i in range(attr_count):
                a = pos + 16 + attr_start + i * attr_size
                _ns, name, _raw, _sz, _r0, dtype, _value = struct.unpack_from("<IIIHBBI", data, a)
                if strings[name] == "versionCode" and dtype in (0x10, 0x11):
                    struct.pack_into("<I", data, a + 16, new_code)
                    return bytes(data)
            fail("el manifiesto no tiene versionCode numerico")
        pos += size
    fail("no pude leer el AndroidManifest")


# ------------------------------------------------------------------------- zip

def read_apk(path):
    path = Path(path)
    if path.suffix.lower() == ".zip":
        with zipfile.ZipFile(path) as z:
            names = [n for n in z.namelist() if n.lower().endswith(".apk")]
            if not names:
                fail("el zip no contiene ningun .apk")
            log("APK dentro del zip: " + names[0])
            return z.read(names[0])
    return path.read_bytes()


def write_apk(source_bytes, output, replace, add):
    """Copia todas las entradas del APK original y alinea las que van sin comprimir.

    Las librerias .so sin comprimir van a multiplos de 16 KiB (requisito de
    extractNativeLibs=false y de los telefonos con paginas de 16 KiB); el resto de
    las entradas sin comprimir, a multiplos de 4 bytes. No se copia el bloque de
    firma original: se firma de nuevo despues.
    """
    import io
    with zipfile.ZipFile(io.BytesIO(source_bytes)) as zin, zipfile.ZipFile(output, "w") as zout:
        def put(name, data, ctype, date_time, attr):
            zi = zipfile.ZipInfo(name, date_time)
            zi.compress_type = ctype
            zi.external_attr = attr
            if ctype == zipfile.ZIP_STORED:
                align = 16384 if name.endswith(".so") else 4
                header_end = zout.fp.tell() + 30 + len(name.encode("utf-8"))
                pad = (-header_end) % align
                if pad:
                    while pad < 6:
                        pad += align
                    zi.extra = struct.pack("<HHH", 0xD935, pad - 4, align) + b"\0" * (pad - 6)
            zout.writestr(zi, data)

        last = None
        for info in zin.infolist():
            if info.is_dir():
                continue
            data = replace.get(info.filename, zin.read(info.filename))
            put(info.filename, data, info.compress_type, info.date_time, info.external_attr)
            last = info
            if info.filename == "lib/arm64-v8a/libmain.so":
                for name, blob in add.items():
                    put(name, blob, zipfile.ZIP_STORED, info.date_time, info.external_attr)
        for name in add:
            if name not in zout.namelist():
                put(name, add[name], zipfile.ZIP_STORED, last.date_time, last.external_attr)


def check_alignment(apk):
    problems = []
    with zipfile.ZipFile(apk) as z, open(apk, "rb") as f:
        for info in z.infolist():
            if info.compress_type != zipfile.ZIP_STORED:
                continue
            f.seek(info.header_offset)
            header = f.read(30)
            name_len, extra_len = struct.unpack("<HH", header[26:30])
            offset = info.header_offset + 30 + name_len + extra_len
            align = 16384 if info.filename.endswith(".so") else 4
            if offset % align:
                problems.append("%s en %d (no multiplo de %d)" % (info.filename, offset, align))
    return problems


# ---------------------------------------------------------------------- smali

def patch_smali(root, update_repo, add_touch=True):
    smali = root / "smali" / "com" / "halo" / "decomp"
    if not smali.is_dir():
        fail("no encuentro com/halo/decomp en el codigo desarmado")

    if add_touch:
        # 1. clases tactiles
        for src in (ASSETS / "smali" / "com" / "halo" / "decomp").glob("*.smali"):
            shutil.copy(src, smali / src.name)

        # 2. gancho en HaloActivity.onCreate
        activity = smali / "HaloActivity.smali"
        text = activity.read_text()
        if "TouchControls" in text:
            fail("HaloActivity ya llama a TouchControls")
        if text.count(HOOK_ANCHOR) != 1:
            fail("HaloActivity.onCreate cambio: no encuentro la llamada a Updater.start; revisa HOOK_ANCHOR")
        activity.write_text(text.replace(HOOK_ANCHOR, HOOK + HOOK_ANCHOR))

    # 3. actualizaciones
    updater = smali / "Updater.smali"
    text = updater.read_text()
    api, download = API_RE.search(text), DOWNLOAD_RE.search(text)
    if not api or not download:
        fail("Updater cambio: no encuentro las direcciones de GitHub (releases/latest y releases/download)")
    repo = api.group(1)
    if download.group(1) != repo:
        fail("Updater apunta a dos repositorios distintos (%s y %s)" % (repo, download.group(1)))
    log("  repositorio oficial del actualizador: " + repo)
    if update_repo:
        text = text.replace(repo, update_repo)
    else:
        text = API_RE.sub(DISABLED_API, text)
        text = DOWNLOAD_RE.sub(DISABLED_DOWNLOAD, text)
        text = text.replace(repo, "disabled/disabled")
    updater.write_text(text)


# ----------------------------------------------------------------------- llave

def random_password(n=24):
    alphabet = string.ascii_letters + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(n))


def create_keystore(path, alias, password):
    env = dict(os.environ, HALO_KS_PASS=password)
    subprocess.run(
        ["keytool", "-genkeypair", "-keystore", str(path), "-storetype", "PKCS12",
         "-storepass:env", "HALO_KS_PASS", "-keypass:env", "HALO_KS_PASS", "-alias", alias,
         "-keyalg", "RSA", "-keysize", "3072", "-validity", "36500",
         "-dname", "CN=Halo CE Touch Build"],
        env=env, check=True, capture_output=True, text=True)


def sign(signer, keystore, alias, password, unsigned, signed):
    env = dict(os.environ, HALO_KS_PASS=password)
    run(["java", "-jar", str(signer), "sign", "--ks", str(keystore), "--ks-key-alias", alias,
         "--ks-pass", "env:HALO_KS_PASS", "--key-pass", "env:HALO_KS_PASS",
         "--v1-signing-enabled", "false", "--v2-signing-enabled", "true",
         "--v3-signing-enabled", "true", "--v4-signing-enabled", "false",
         "--min-sdk-version", "28", "--out", str(signed), str(unsigned)], env=env)
    return run(["java", "-jar", str(signer), "verify", "-v", "--print-certs", str(signed)])


# ------------------------------------------------------------------------ main

def main():
    ap = argparse.ArgumentParser(description="Agrega controles tactiles a un release oficial de Halo CE Universal.")
    ap.add_argument("input", help="halo-android-release.zip o app-release.apk oficial")
    ap.add_argument("-o", "--out", required=True, help="APK de salida, ya firmado")
    ap.add_argument("--keystore", required=True, help="keystore PKCS12 con tu llave de firma")
    ap.add_argument("--alias", default="halotouch")
    ap.add_argument("--create-keystore", action="store_true",
                    help="crea el keystore si no existe (guarda la clave en <keystore>.password.txt)")
    ap.add_argument("--update-repo", metavar="USUARIO/REPO",
                    help="repositorio de GitHub con TUS releases (tag build-N, asset halo-android-release.zip). "
                         "Sin esta opcion el actualizador interno queda desactivado.")
    ap.add_argument("--version-code", type=int, metavar="N",
                    help="cambia el versionCode del APK (para instalarlo encima de una version con numero mayor)")
    ap.add_argument("--keep-work", action="store_true", help="no borrar la carpeta temporal de trabajo")
    args = ap.parse_args()

    for tool in ("java", "keytool"):
        if not shutil.which(tool):
            fail("no encuentro '%s' en el PATH (instala un JDK 17 o superior)" % tool)
    apktool, signer = fetch_tools()

    keystore = Path(args.keystore)
    password = (os.environ.get("HALO_KS_PASS") or "").strip() or None
    if not keystore.exists():
        if not args.create_keystore:
            fail("no existe %s; usa --create-keystore para crearlo" % keystore)
        password = password or random_password()
        create_keystore(keystore, args.alias, password)
        pw_file = Path(str(keystore) + ".password.txt")
        pw_file.write_text(password + "\n")
        os.chmod(pw_file, 0o600)
        log("Llave nueva creada: %s (clave en %s). GUARDA LOS DOS ARCHIVOS: sin ellos no podras actualizar." % (keystore, pw_file))
    if not password:
        password = getpass.getpass("Clave del keystore: ")

    apk_bytes = read_apk(args.input)
    with zipfile.ZipFile(__import__("io").BytesIO(apk_bytes)) as z:
        info = manifest_info(z.read("AndroidManifest.xml"))
        dex = z.read("classes.dex")
        add_touch = b"Lcom/halo/decomp/TouchControls;" not in dex
        if b"Lcom/halo/decomp/HaloActivity;" not in dex:
            fail("no parece un APK de Halo CE Universal")
        if not add_touch:
            log("Este APK ya trae su propia capa tactil (fork): NO se agrega la nuestra; solo se cambia el "
                "actualizador, la firma y, si lo pides, el versionCode.")
        manifest = z.read("AndroidManifest.xml")
    log("Paquete %s, versionCode %s (%s)" % (info.get("package"), info.get("versionCode"), info.get("versionName")))

    work = Path(tempfile.mkdtemp(prefix="halo-touch-"))
    try:
        src_apk = work / "in.apk"
        src_apk.write_bytes(apk_bytes)
        decoded = work / "decoded"
        log("Desarmando el codigo...")
        run(["java", "-jar", str(apktool), "d", "-r", "-f", "-o", str(decoded), str(src_apk)])
        patch_smali(decoded, args.update_repo, add_touch)
        log("Armando classes.dex...")
        rebuilt = work / "rebuilt.apk"
        run(["java", "-jar", str(apktool), "b", "-f", "-api", "28", "-o", str(rebuilt), str(decoded)])
        with zipfile.ZipFile(rebuilt) as z:
            new_dex = z.read("classes.dex")
        if not new_dex.startswith(b"dex\n039"):
            fail("classes.dex nuevo tiene una version inesperada: %r" % new_dex[:8])

        replace = {"classes.dex": new_dex}
        add = {}
        if add_touch:
            add["lib/arm64-v8a/libhalotouch.so"] = (ASSETS / "lib" / "arm64-v8a" / "libhalotouch.so").read_bytes()
        if args.version_code is not None:
            replace["AndroidManifest.xml"] = set_version_code(manifest, args.version_code)
            log("versionCode: %s -> %d" % (info.get("versionCode"), args.version_code))
        unsigned = work / "unsigned.apk"
        write_apk(apk_bytes, unsigned, replace, add)
        problems = check_alignment(unsigned)
        if problems:
            fail("alineacion incorrecta: " + "; ".join(problems))

        out = Path(args.out)
        log("Firmando...")
        report = sign(signer, keystore, args.alias, password, unsigned, out)
        problems = check_alignment(out)
        if problems:
            fail("alineacion incorrecta tras firmar: " + "; ".join(problems))
        log(report.strip())
        log("\nListo: %s (%d bytes)" % (out, out.stat().st_size))
        log("Actualizaciones internas: " + (args.update_repo if args.update_repo else "desactivadas"))
    finally:
        if args.keep_work:
            log("Carpeta de trabajo: %s" % work)
        else:
            shutil.rmtree(work, ignore_errors=True)


if __name__ == "__main__":
    main()
