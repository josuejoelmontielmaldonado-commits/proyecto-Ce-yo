# Halo CE Universal + controles táctiles

Esta carpeta agrega controles táctiles a cualquier release oficial de
[halo-ce-universal / OpenCE](https://github.com/OpenCommunityEdition/OpenCE) (antes `cybersecurity/halo-ce-universal`) para Android
y lo firma con tu propia llave, para que las versiones siguientes se instalen
encima de la anterior sin perder datos.

## Qué contiene

| Archivo | Para qué sirve |
| --- | --- |
| `patch_halo_touch.py` | Inyecta la capa táctil, alinea y firma. Es todo el proceso. |
| `touch_assets/smali/` | Las clases táctiles. `TouchControls*` es la versión 2 (ajustes y editor, compilada desde `reference/TouchControls.java`); `TouchIcons*` son los iconos de tu APK build 51. |
| `touch_assets/lib/arm64-v8a/libhalotouch.so` | Librería nativa de 4,6 KB. Solo llama a funciones de joystick virtual de SDL3. |
| `reference/TouchControls.java` | Código fuente de la versión 2 (de aquí salió el smali). `reference/TouchIcons.java` es solo lectura (iconos de la build 51). |

## Primera instalación (una sola vez)

Tu APK actual (build 51) está firmado con la llave «Halo Touch Patch». El APK nuevo
va firmado con otra llave, y Android no permite instalar una app encima de otra
con distinta firma. Hay que desinstalar una vez.

1. **Respalda tus datos.** Al desinstalar, Android borra `Android/data/com.halo.decomp/files/`:
   `maps/` (~1,8 GB), `save/` (partidas), `config.toml`. Los `maps/` se recuperan
   desde tu ISO dentro de la app. Las partidas solo se salvan copiando `save/` antes
   (con un explorador de archivos que abra `Android/data`, o con adb).
2. Desinstala «Halo» (el APK build 51).
3. Instala `halo-touch-build74.apk`.
4. Abre la app, elige tu ISO otra vez y espera a que se copien los mapas.

Si todavía tienes el keystore con el que se firmó el APK build 51 («Halo Touch Patch»),
no hace falta nada de lo anterior: firma con ese keystore (`--keystore su-archivo
--alias su-alias`) y el APK se instala encima, conservando todos los datos.

## Actualizar a futuras builds

Cuando salga una build nueva del proyecto original:

1. Descarga `halo-android-release.zip` de la página de Releases.
2. Ejecuta, con la misma llave:

   ```
   export HALO_KS_PASS="$(cat halo-touch.p12.password.txt)"
   python3 patch_halo_touch.py halo-android-release.zip -o halo-touch-buildNN.apk --keystore halo-touch.p12
   ```
3. Instala el APK resultante encima. Mantiene el mismo paquete y la misma firma, y
   el `versionCode` es el del proyecto original, así que Android lo trata como
   actualización y conserva `maps/`, partidas y ajustes.

Requisitos: Python 3.8+ y Java 17+ (`java` y `keytool` en el PATH). La primera vez
descarga apktool y apksigner de GitHub y los guarda en `tools/`. Puede correr en un
PC, en Termux o en GitHub Actions.

## El actualizador interno del juego

El juego revisa si hay una build nueva en el repositorio oficial. Ese APK oficial lleva
otra firma y Android no lo instalaría encima, así que el parche **desactiva** esa
revisión por defecto (apunta a `updates.invalid`, un dominio reservado que nunca resuelve).

Si quieres actualizaciones dentro del juego, publica tus APK parcheados como
releases en un repositorio tuyo y usa `--update-repo TU_USUARIO/TU_REPO`. El juego
espera un tag `build-NN` y un archivo `halo-android-release.zip` que contenga el APK.

En tu instalación actual (build 51) conviene poner `[update]` / `auto = false` en
`config.toml`, o elegir «Do not ask again», para que no ofrezca una actualización
que Android va a rechazar.

## Actualización automática dentro del juego (GitHub Actions)

El juego oficial tiene una opción de actualización: consulta el último release de GitHub, descarga
`halo-android-release.zip` y lanza el instalador. Con el parche puedes tener lo mismo apuntando a **tu** repositorio,
y un flujo de GitHub Actions (`.github/workflows/auto-patch.yml`) que cada hora revisa si el proyecto original sacó
una build nueva, la parcha, la firma con tu llave y la publica como release. Resultado: el juego te ofrece la
actualización con los controles táctiles ya incluidos, sin que toques una computadora.

Pasos (se pueden hacer desde el navegador del teléfono):

1. Crea un repositorio **público** en GitHub (el juego consulta la API sin iniciar sesión, por eso debe ser público).
2. Crea el archivo `.github/workflows/auto-patch.yml` con el contenido del archivo del mismo nombre.
3. Sube a la raíz del repositorio `halo-touch-patcher.zip` tal cual, sin descomprimir: el flujo lo abre solo.
4. En Settings → Secrets and variables → Actions crea dos secretos:
   `HALO_KS_BASE64` (el texto de `halo-touch.p12.base64.txt`) y `HALO_KS_PASS` (el texto de `halo-touch.p12.password.txt`).
5. En la pestaña Actions habilita los flujos y ejecuta «Parchar y publicar» con *Run workflow*.
6. Cuando termine, en Releases aparece `build-NN` con `halo-android-release.zip`. Descomprímelo e instala el APK
   encima de tu juego (misma llave). Desde ese momento el actualizador interno apunta a tu repositorio.

Notas:

- GitHub desactiva los flujos programados tras 60 días sin actividad en el repositorio; vuelve a activarlo en Actions.
- Solo se actualiza si la firma coincide, así que usa siempre la misma llave. La llave queda únicamente en los
  secretos del repositorio; el flujo la borra del ejecutor al terminar.
- Este flujo nunca se ejecutó (no tengo acceso a Actions desde donde trabajo). Las piezas por separado sí se verificaron:
  el parche, la redirección del actualizador y que el zip tiene el formato que el juego espera.
- El proyecto original publica builds muy seguido (varias por día) y a veces cambia la versión de red del
  multijugador: un APK de otra build no se une a partidas de una build distinta.

## Usar el APK del fork (theLlamaNet 3.1)

El fork trae su propia capa táctil (con FOV, botón de cámara, vibración, trucos en vivo y menús táctiles, que viven en
su motor nativo). El parchador lo detecta solo y **no** agrega la nuestra: únicamente cambia el actualizador, la firma
y, si lo pides, el número de versión.

```
export HALO_KS_PASS="$(cat halo-touch.p12.password.txt)"
python3 patch_halo_touch.py halo-ce-android-3.1-release.apk -o fork-firmado.apk \
    --keystore halo-touch.p12 --version-code 1000
```

- El APK de la release 3.1 viene **sin firmar** y con `versionCode` 1. Android no instala APK sin firmar, y no deja
  instalar encima de una versión con número mayor (por ejemplo, la build 143). Con `--version-code 1000` queda mayor.
- Ese número es un límite hacia arriba: para volver a las builds del proyecto original (143 y siguientes) hay que
  desinstalar antes, y eso borra `Android/data/com.halo.decomp/files/`.
- El motor del fork usa versión de red 11; el proyecto original va en 17. No se unen a las mismas partidas en línea.

## Tu llave de firma

`halo-touch.p12` y `halo-touch.p12.password.txt` son la llave. Guárdalos juntos y
con copia: quien tenga esa llave puede publicar APK que tu teléfono acepta como
actualización, y sin ella no podrás actualizar encima.

Esta llave se generó en el entorno de Claude. Para un uso personal sirve. Si algún día
repartes el APK a otras personas, genera una llave propia con
`python3 patch_halo_touch.py ... --keystore otra.p12 --create-keystore` en tu equipo.


## Ajustes y editor de disposición (versión 2)

Arriba a la izquierda hay un botón con un engranaje. Tócalo y se abre **Controles táctiles**:

- **Tamaño de botones**: 50 % a 200 %, para todos los botones y la palanca.
- **Sensibilidad de la cámara**: 0,25x a 4x para el arrastre del dedo.
- **Invertir eje vertical** de la cámara.
- **Opacidad** de los botones: 30 % a 100 %.
- **Giroscopio** (apuntar moviendo el teléfono): activar, sensibilidad e invertir eje horizontal o vertical.
  Mueve la cámara igual que el dedo, así que se suma al arrastre. Los signos de los ejes salen de razonar el
  código para las 4 orientaciones y la escala (600 px por radián) es una estimación: si al girar a la derecha
  la mira va a la izquierda, marca «invertir horizontal» (y lo mismo con el vertical).
- **Editar disposición**: arrastra cualquier botón a donde quieras. Toca un botón para elegirlo y usa
  TAMAÑO − / + para cambiar solo ese botón (sin botón elegido cambia el tamaño de todos), OCULTAR /
  MOSTRAR para quitarlo o devolverlo, y LISTO para salir.
- **Restablecer**: devuelve todo a la disposición original (pide confirmación).

Todo se guarda en los datos privados de la app, así que sobrevive a las actualizaciones hechas con la misma
llave. Desinstalar la app lo borra. No hay FOV, vibración ni botón de cámara: eso vive dentro del
motor del juego (código nativo) y esta capa no lo toca.

## Qué se comprobó y qué no

Comprobado con los releases oficiales build 74 y build 125 (el parche detecta solo el repositorio del actualizador):

- El manifiesto, los recursos, `libmain.so`, `libSDL3.so` y `halo_guest.elf` quedan idénticos
  byte a byte. Solo cambia `classes.dex` y se agrega `libhalotouch.so`.
- Al volver a desarmar el APK final, las únicas diferencias de código respecto al oficial
  son las 6 clases táctiles, una línea en `HaloActivity.onCreate` y las cadenas del actualizador.
- Las 3 funciones de `SDLActivity` y los 8 símbolos de SDL3 que usa la capa táctil existen
  igual en la build 74.
- Las librerías nativas quedan sin comprimir y alineadas a 16 KiB, y la firma v3 (Android 9 o superior) verifica; no lleva v1 ni v2.

**La versión 2 se compiló sin el SDK de Android** (contra declaraciones de prueba escritas a mano, con D8 y baksmali de jadx 1.5.1). Se revisó que las llamadas al framework de Android (se listaron una por una) tengan la firma correcta, que el APK se arme y firme y que los archivos nativos queden idénticos, pero el código nuevo **nunca se ejecutó**. **No se probó en un teléfono.** No pude ejecutar la app, así que no sé cómo se ve ni cómo
responde el control en tu OPPO. Si algo falla, el registro está en
`Android/data/com.halo.decomp/files/debug.txt`.

## Esquema de botones (según el código)

Arriba a la izquierda está el engranaje de ajustes. Para moverte, toca y arrastra en el 42 % izquierdo de la pantalla: el joystick aparece
donde pones el dedo. Para mirar, arrastra en el resto de la pantalla, o desliza el dedo
sobre FIRE mientras disparas. Botones: FIRE (gatillo derecho), JUMP (A), USE (X),
MELEE (B), WPN (Y), GREN (gatillo izquierdo), GRN2 (R1), ZOOM (R3), LIGHT (L1),
CROUCH (L3), BACK y START. Esto sale de leer el código, no de verlo funcionar.
