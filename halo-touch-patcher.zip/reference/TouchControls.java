package com.halo.decomp;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.hardware.input.InputManager;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.InputDevice;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import org.libsdl.app.SDLActivity;

/**
 * Halo CE touch overlay, v2: same input path as the original layer (virtual
 * joystick through libhalotouch + SDL keys/mouse), plus a settings dialog
 * (button size, camera sensitivity, invert Y, opacity), a layout editor
 * (drag, resize, hide buttons) and persistence in SharedPreferences.
 */
public class TouchControls extends View implements InputManager.InputDeviceListener, SensorEventListener {
    private static final int A = 0;
    private static final int B = 1;
    private static final int X = 2;
    private static final int Y = 3;
    private static final int BACK = 4;
    private static final int START = 6;
    private static final int L3 = 7;
    private static final int R3 = 8;
    private static final int L1 = 9;
    private static final int R1 = 10;
    private static final int LT = -1;
    private static final int RT = -2;

    private static final int DISC = 0x22000000;
    private static final int DISC_PRESSED = 0x55FFFFFF;
    private static final int RING = 0x55FFFFFF;
    private static final int ICON = 0xDDFFFFFF;
    private static final int ICON_SHADOW = 0x66000000;
    private static final int STICK_BASE = 0x30FFFFFF;
    private static final int STICK_KNOB = 0x80FFFFFF;
    private static final int EDIT_BG = 0xCC102030;
    private static final int EDIT_SELECTED = 0xFFFFD54F;
    private static final int EDIT_HIDDEN = 0x66FF8A80;

    private static final float KEY_ON = 0.35f;
    private static final float ARROW_ON = 0.6f;
    private static final float LOOK_GAIN = 1.1f;

    private static final String PREFS = "halotouch";
    // Mouse counts per radian of phone rotation at 1x gyro sensitivity.
    private static final float GYRO_PIXELS_PER_RADIAN = 600.0f;

    private boolean active;
    private boolean attached;
    private final Button[] buttons;
    private final float dp;
    private final Paint fill;
    private boolean first;
    private final Handler handler;
    private final Paint icon;
    private final HashSet<Integer> keysDown;
    private int lookPointer;
    private float lookX;
    private float lookY;
    private int mouseState;
    private float moveDX;
    private float moveDY;
    private int movePointer;
    private float moveX;
    private float moveY;
    private final CanvasPen pen;
    private final Runnable retry;
    private final Paint stroke;
    private final Paint text;

    // user settings
    private float size = 1.0f;      // 0.5 .. 2.0, all buttons and the stick
    private float lookSens = 1.0f;  // 0.25 .. 4.0
    private boolean invertY = false;
    private float opacity = 1.0f;   // 0.3 .. 1.0
    private final SharedPreferences prefs;

    // gyroscope aiming
    private boolean gyroOn = false;
    private float gyroSens = 1.0f;      // 0.25 .. 4.0
    private boolean gyroInvertX = false;
    private boolean gyroInvertY = false;
    private SensorManager sensors;
    private Sensor gyroSensor;
    private boolean gyroRegistered = false;
    private long gyroPrevTime = 0;
    private int gyroPrevRotation = -1;
    private float gyroPrevUp = 0.0f;
    private float gyroPrevRight = 0.0f;

    // settings button / editor state
    private int gearPointer = -1;
    private boolean editMode = false;
    private Button selected = null;
    private int dragPointer = -1;
    private float dragDX;
    private float dragDY;
    private boolean dialogOpen = false;

    private static native boolean nativeUpdate(boolean z, int i, int i2, int i3, int i4, int i5, int i6, int i7);

    static {
        System.loadLibrary("halotouch");
    }

    private static final class Button {
        final float bottomDp;
        final int code;
        float cx;
        float cy;
        final int icon;
        int key;
        final String label;
        float lastX;
        float lastY;
        final float leftDp;
        int pointer = -1;
        float r;
        final float radiusDp;
        final float rightDp;
        final float topDp;
        // user customisation
        float fx = Float.NaN;   // custom centre as a fraction of the view, NaN = default
        float fy = Float.NaN;
        float scale = 1.0f;
        boolean hidden = false;

        Button(String label, int code, float left, float right, float top, float bottom, float radiusDp) {
            this.label = label;
            this.code = code;
            this.key = TouchControls.keyFor(code);
            this.icon = TouchControls.iconFor(label);
            this.leftDp = left;
            this.rightDp = right;
            this.topDp = top;
            this.bottomDp = bottom;
            this.radiusDp = radiusDp;
        }
    }

    private static int iconFor(String label) {
        if (label.equals("FIRE")) return 0;
        if (label.equals("JUMP")) return 1;
        if (label.equals("USE")) return 2;
        if (label.equals("MELEE")) return 3;
        if (label.equals("WPN")) return 4;
        if (label.equals("GREN")) return 5;
        if (label.equals("GRN2")) return 6;
        if (label.equals("ZOOM")) return 7;
        if (label.equals("LIGHT")) return 8;
        if (label.equals("CROUCH")) return 9;
        if (label.equals("BACK")) return 10;
        return 11;
    }

    private static int keyFor(int code) {
        switch (code) {
            case 0:
                return 62;
            case 1:
                return 34;
            case 2:
                return 33;
            case 3:
                return 61;
            case 4:
                return 131;
            case 6:
                return 111;
            case 7:
                return 31;
            case 8:
                return 54;
            case 9:
                return 45;
            case 10:
                return 52;
            default:
                return 0;
        }
    }

    public static void install(Activity activity) {
        activity.addContentView(new TouchControls(activity), new ViewGroup.LayoutParams(-1, -1));
    }

    public TouchControls(Context context) {
        super(context);
        float n = Float.NaN;
        this.buttons = new Button[]{
            new Button("FIRE", RT, n, 95.0f, n, 115.0f, 46.0f),
            new Button("JUMP", A, n, 195.0f, n, 45.0f, 30.0f),
            new Button("USE", X, n, 205.0f, n, 150.0f, 30.0f),
            new Button("MELEE", B, n, 100.0f, n, 215.0f, 28.0f),
            new Button("WPN", Y, n, 38.0f, n, 215.0f, 22.0f),
            new Button("GREN", LT, n, 35.0f, n, 50.0f, 26.0f),
            new Button("GRN2", R1, n, 200.0f, 40.0f, n, 24.0f),
            new Button("ZOOM", R3, n, 60.0f, 40.0f, n, 24.0f),
            new Button("LIGHT", L1, 60.0f, n, 40.0f, n, 24.0f),
            new Button("CROUCH", L3, 130.0f, n, 40.0f, n, 24.0f),
            new Button("BACK", BACK, n, n, 30.0f, n, 20.0f),
            new Button("START", START, n, n, 30.0f, n, 20.0f)};
        this.fill = new Paint(1);
        this.stroke = new Paint(1);
        this.text = new Paint(1);
        this.handler = new Handler(Looper.getMainLooper());
        this.movePointer = -1;
        this.lookPointer = -1;
        this.keysDown = new HashSet<Integer>();
        this.active = true;
        this.retry = new Runnable() {
            @Override
            public void run() {
                if (TouchControls.this.active && !TouchControls.this.attached) {
                    TouchControls.this.push();
                    if (!TouchControls.this.attached) {
                        TouchControls.this.handler.postDelayed(this, 500L);
                    }
                }
            }
        };
        this.first = true;
        this.icon = new Paint(1);
        this.pen = new CanvasPen();
        this.dp = context.getResources().getDisplayMetrics().density;
        this.fill.setStyle(Paint.Style.FILL);
        this.stroke.setStyle(Paint.Style.STROKE);
        this.stroke.setStrokeWidth(2.0f * this.dp);
        this.text.setTextAlign(Paint.Align.CENTER);
        this.text.setColor(-1);
        this.text.setTextSize(11.0f * this.dp);
        this.prefs = context.getSharedPreferences(PREFS, 0);
        loadSettings();
        Object sm = context.getSystemService("sensor");
        if (sm instanceof SensorManager) {
            this.sensors = (SensorManager) sm;
            this.gyroSensor = this.sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        }
    }

    // ------------------------------------------------------------ settings

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }

    private void loadSettings() {
        try {
            this.size = clamp(prefs.getFloat("size", 1.0f), 0.5f, 2.0f);
            this.lookSens = clamp(prefs.getFloat("look", 1.0f), 0.25f, 4.0f);
            this.opacity = clamp(prefs.getFloat("opacity", 1.0f), 0.3f, 1.0f);
            this.invertY = prefs.getBoolean("invert", false);
            this.gyroOn = prefs.getBoolean("gyro", false);
            this.gyroSens = clamp(prefs.getFloat("gyroSens", 1.0f), 0.25f, 4.0f);
            this.gyroInvertX = prefs.getBoolean("gyroInvX", false);
            this.gyroInvertY = prefs.getBoolean("gyroInvY", false);
            for (int i = 0; i < buttons.length; i++) {
                String s = prefs.getString("b" + i, null);
                if (s == null) {
                    continue;
                }
                String[] p = s.split(",");
                if (p.length < 4) {
                    continue;
                }
                try {
                    Button b = buttons[i];
                    float fx = Float.parseFloat(p[0]);
                    float fy = Float.parseFloat(p[1]);
                    b.scale = clamp(Float.parseFloat(p[2]), 0.5f, 2.0f);
                    b.hidden = p[3].equals("1");
                    if (fx >= 0.0f && fx <= 1.0f && fy >= 0.0f && fy <= 1.0f) {
                        b.fx = fx;
                        b.fy = fy;
                    }
                } catch (NumberFormatException e) {
                    // ignore a damaged entry, keep the defaults
                }
            }
        } catch (RuntimeException e) {
            // damaged preferences: keep defaults
        }
    }

    private void saveSettings() {
        try {
            SharedPreferences.Editor ed = prefs.edit();
            ed.putFloat("size", size);
            ed.putFloat("look", lookSens);
            ed.putFloat("opacity", opacity);
            ed.putBoolean("invert", invertY);
            ed.putBoolean("gyro", gyroOn);
            ed.putFloat("gyroSens", gyroSens);
            ed.putBoolean("gyroInvX", gyroInvertX);
            ed.putBoolean("gyroInvY", gyroInvertY);
            for (int i = 0; i < buttons.length; i++) {
                Button b = buttons[i];
                ed.putString("b" + i, b.fx + "," + b.fy + "," + b.scale + "," + (b.hidden ? "1" : "0"));
            }
            ed.apply();
        } catch (RuntimeException e) {
            // settings are a convenience, never crash the game over them
        }
    }

    private void resetSettings() {
        size = 1.0f;
        lookSens = 1.0f;
        opacity = 1.0f;
        invertY = false;
        gyroOn = false;
        gyroSens = 1.0f;
        gyroInvertX = false;
        gyroInvertY = false;
        updateGyro();
        for (int i = 0; i < buttons.length; i++) {
            Button b = buttons[i];
            b.fx = Float.NaN;
            b.fy = Float.NaN;
            b.scale = 1.0f;
            b.hidden = false;
        }
        selected = null;
        saveSettings();
        layout();
        invalidate();
    }

    // ------------------------------------------------------------ lifecycle

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        ((InputManager) getContext().getSystemService("input")).registerInputDeviceListener(this, this.handler);
        refreshActive();
        updateGyro();
    }

    @Override
    protected void onDetachedFromWindow() {
        ((InputManager) getContext().getSystemService("input")).unregisterInputDeviceListener(this);
        this.handler.removeCallbacks(this.retry);
        stopGyro();
        releasePlatformInput();
        nativeUpdate(false, 0, 0, 0, 0, 0, 0, 0);
        super.onDetachedFromWindow();
    }

    private static boolean isPhysicalPad(int id) {
        InputDevice device = InputDevice.getDevice(id);
        if (device == null || device.isVirtual()) {
            return false;
        }
        int sources = device.getSources();
        return (sources & 16777232) == 16777232 && (sources & 1025) == 1025;
    }

    private void refreshActive() {
        boolean pad = false;
        int[] ids = InputDevice.getDeviceIds();
        for (int i = 0; i < ids.length; i++) {
            if (isPhysicalPad(ids[i])) {
                pad = true;
                break;
            }
        }
        if (!this.first) {
            if (this.active == (!pad)) {
                return;
            }
        }
        this.first = false;
        this.active = !pad;
        setVisibility(this.active ? 0 : 8);
        releaseAll();
        if (this.active) {
            this.attached = false;
            this.handler.removeCallbacks(this.retry);
            this.handler.post(this.retry);
        } else {
            this.handler.removeCallbacks(this.retry);
            releasePlatformInput();
            nativeUpdate(false, 0, 0, 0, 0, 0, 0, 0);
            this.attached = false;
        }
        updateGyro();
    }

    @Override
    public void onWindowFocusChanged(boolean z) {
        super.onWindowFocusChanged(z);
        releaseAll();
        updateGyro();
    }

    @Override
    public void onInputDeviceAdded(int i) {
        refreshActive();
    }

    @Override
    public void onInputDeviceRemoved(int i) {
        refreshActive();
    }

    @Override
    public void onInputDeviceChanged(int i) {
        refreshActive();
    }

    // --------------------------------------------------------------- layout

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        layout();
    }

    private float stickRadius() {
        return 60.0f * this.dp * this.size;
    }

    private void layout() {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) {
            return;
        }
        for (int i = 0; i < buttons.length; i++) {
            Button b = buttons[i];
            b.r = b.radiusDp * this.dp * this.size * b.scale;
            float cx;
            float cy;
            if (!Float.isNaN(b.fx) && !Float.isNaN(b.fy)) {
                cx = b.fx * w;
                cy = b.fy * h;
            } else {
                if (!Float.isNaN(b.leftDp)) {
                    cx = b.leftDp * this.dp;
                } else if (!Float.isNaN(b.rightDp)) {
                    cx = w - (b.rightDp * this.dp);
                } else {
                    cx = w / 2.0f;
                }
                if (!Float.isNaN(b.topDp)) {
                    cy = (b.topDp * this.dp) + b.r;
                } else if (!Float.isNaN(b.bottomDp)) {
                    cy = h - (b.bottomDp * this.dp);
                } else {
                    cy = h / 2.0f;
                }
                if (b.code == BACK) {
                    cx = (w / 2.0f) - (b.r + 20.0f * this.dp);
                }
                if (b.code == START) {
                    cx = (w / 2.0f) + (b.r + 20.0f * this.dp);
                }
            }
            b.cx = clamp(cx, b.r, Math.max(b.r, w - b.r));
            b.cy = clamp(cy, b.r, Math.max(b.r, h - b.r));
        }
    }

    private Button hit(float x, float y, boolean includeHidden) {
        for (int i = 0; i < buttons.length; i++) {
            Button b = buttons[i];
            if (b.hidden && !includeHidden) {
                continue;
            }
            float dx = x - b.cx;
            float dy = y - b.cy;
            float rr = b.r * 1.25f;
            if ((dx * dx) + (dy * dy) <= rr * rr) {
                return b;
            }
        }
        return null;
    }

    private float gearX() {
        return 22.0f * this.dp;
    }

    private float gearY() {
        return 22.0f * this.dp;
    }

    private float gearR() {
        return 14.0f * this.dp;
    }

    private boolean gearHit(float x, float y) {
        float dx = x - gearX();
        float dy = y - gearY();
        float rr = gearR() * 1.8f;
        return (dx * dx) + (dy * dy) <= rr * rr;
    }

    private void releaseAll() {
        for (int i = 0; i < buttons.length; i++) {
            buttons[i].pointer = -1;
        }
        this.lookPointer = -1;
        this.movePointer = -1;
        this.gearPointer = -1;
        this.dragPointer = -1;
        this.moveDY = 0.0f;
        this.moveDX = 0.0f;
        if (this.active) {
            push();
        } else {
            releasePlatformInput();
        }
        invalidate();
    }

    // ---------------------------------------------------------------- touch

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (editMode) {
            return editTouch(e);
        }
        int action = e.getActionMasked();
        int index = e.getActionIndex();
        switch (action) {
            case 0:
            case 5: {
                int id = e.getPointerId(index);
                float x = e.getX(index);
                float y = e.getY(index);
                if (gearPointer < 0 && gearHit(x, y)) {
                    gearPointer = id;
                    invalidate();
                    return true;
                }
                Button b = hit(x, y, false);
                if (b != null) {
                    b.pointer = id;
                    b.lastX = x;
                    b.lastY = y;
                } else if (x < getWidth() * 0.42f) {
                    if (this.movePointer < 0) {
                        this.movePointer = id;
                        this.moveX = x;
                        this.moveY = y;
                        this.moveDY = 0.0f;
                        this.moveDX = 0.0f;
                    }
                } else if (this.lookPointer < 0) {
                    this.lookPointer = id;
                    this.lookX = x;
                    this.lookY = y;
                }
                push();
                invalidate();
                return true;
            }
            case 1:
            case 3:
            case 6: {
                int id = e.getPointerId(index);
                if (action == 3) {
                    releaseAll();
                    return true;
                }
                if (id == gearPointer) {
                    gearPointer = -1;
                    if (gearHit(e.getX(index), e.getY(index))) {
                        openSettings();
                    }
                    invalidate();
                    return true;
                }
                for (int i = 0; i < buttons.length; i++) {
                    if (buttons[i].pointer == id) {
                        buttons[i].pointer = -1;
                    }
                }
                if (id == this.movePointer) {
                    this.movePointer = -1;
                    this.moveDY = 0.0f;
                    this.moveDX = 0.0f;
                }
                if (id == this.lookPointer) {
                    this.lookPointer = -1;
                }
                push();
                invalidate();
                return true;
            }
            case 2: {
                for (int i = 0; i < e.getPointerCount(); i++) {
                    int id = e.getPointerId(i);
                    if (id == this.movePointer) {
                        float[] s = stick(e.getX(i) - this.moveX, e.getY(i) - this.moveY, stickRadius());
                        this.moveDX = s[0];
                        this.moveDY = s[1];
                    } else {
                        for (int j = 0; j < buttons.length; j++) {
                            Button b = buttons[j];
                            if (b.pointer == id && b.code == RT) {
                                float x2 = e.getX(i);
                                float y2 = e.getY(i);
                                look((x2 - b.lastX) * LOOK_GAIN, (y2 - b.lastY) * LOOK_GAIN);
                                b.lastX = x2;
                                b.lastY = y2;
                            }
                        }
                    }
                    if (id == this.lookPointer) {
                        float x3 = e.getX(i);
                        float y3 = e.getY(i);
                        float dx = (x3 - this.lookX) * LOOK_GAIN;
                        float dy = (y3 - this.lookY) * LOOK_GAIN;
                        this.lookX = x3;
                        this.lookY = y3;
                        look(dx, dy);
                    }
                }
                push();
                invalidate();
                return true;
            }
            default:
                push();
                invalidate();
                return true;
        }
    }

    private static float[] stick(float dx, float dy, float radius) {
        float len = (float) Math.hypot(dx, dy);
        if (len < 0.12f * radius) {
            return new float[]{0.0f, 0.0f};
        }
        float m = Math.min(1.0f, len / radius);
        float g = (m * m * (3.0f - (2.0f * m)) * KEY_ON) + (m * 0.65f);
        return new float[]{(dx / len) * g, (dy / len) * g};
    }

    private void look(float dx, float dy) {
        if (this.active && this.attached) {
            dx *= this.lookSens;
            dy *= this.lookSens * (this.invertY ? -1.0f : 1.0f);
            if (dx != 0.0f || dy != 0.0f) {
                SDLActivity.onNativeMouse(this.mouseState, 2, dx, dy, true);
            }
        }
    }

    private void push() {
        int lt = 0;
        int rt = 0;
        int mask = 0;
        for (int i = 0; i < buttons.length; i++) {
            Button b = buttons[i];
            if (b.pointer >= 0 && !b.hidden) {
                if (b.code == LT) {
                    lt = 32767;
                } else if (b.code == RT) {
                    rt = 32767;
                } else {
                    mask |= 1 << b.code;
                }
            }
        }
        this.attached = nativeUpdate(this.active, mask, axis(this.moveDX), axis(this.moveDY), 0, 0, lt, rt);
        if (this.active && this.attached) {
            sendPlatformInput(lt > 0, rt > 0);
        }
    }

    private void sendPlatformInput(boolean leftTrigger, boolean rightTrigger) {
        for (int i = 0; i < buttons.length; i++) {
            Button b = buttons[i];
            setKey(b.key, b.pointer >= 0 && !b.hidden);
        }
        setKey(51, this.moveDY < -0.35f);
        setKey(47, this.moveDY > KEY_ON);
        setKey(29, this.moveDX < -0.35f);
        setKey(32, this.moveDX > KEY_ON);
        setKey(19, this.moveDY < -0.6f);
        setKey(20, this.moveDY > ARROW_ON);
        setKey(21, this.moveDX < -0.6f);
        setKey(22, this.moveDX > ARROW_ON);
        setMouseButtons((rightTrigger ? 1 : 0) | (leftTrigger ? 2 : 0));
    }

    private void releasePlatformInput() {
        Iterator<Integer> it = new ArrayList<Integer>(this.keysDown).iterator();
        while (it.hasNext()) {
            setKey(it.next().intValue(), false);
        }
        setMouseButtons(0);
    }

    private void setKey(int key, boolean down) {
        if (key != 0) {
            if (down) {
                if (this.keysDown.add(Integer.valueOf(key))) {
                    SDLActivity.onNativeKeyDown(key);
                }
            } else if (this.keysDown.remove(Integer.valueOf(key))) {
                SDLActivity.onNativeKeyUp(key);
            }
        }
    }

    private void setMouseButtons(int mask) {
        int pressed = mask & (this.mouseState ^ (-1));
        int released = this.mouseState & (mask ^ (-1));
        int state = this.mouseState;
        for (int bit = 1; bit <= 2; bit <<= 1) {
            if ((pressed & bit) != 0) {
                state |= bit;
                SDLActivity.onNativeMouse(state, 0, 0.0f, 0.0f, true);
            } else if ((released & bit) != 0) {
                state &= bit ^ (-1);
                SDLActivity.onNativeMouse(state, 1, 0.0f, 0.0f, true);
            }
        }
        this.mouseState = mask;
    }

    private static int axis(float v) {
        return Math.max(-32768, Math.min(32767, Math.round(32767.0f * v)));
    }

    // ------------------------------------------------------------------ gyroscope

    private void updateGyro() {
        boolean need = this.gyroOn && this.gyroSensor != null && this.sensors != null
            && this.active && !this.editMode && !this.dialogOpen && hasWindowFocus();
        if (need && !this.gyroRegistered) {
            this.gyroPrevTime = 0;
            this.gyroPrevRotation = -1;
            this.gyroRegistered = this.sensors.registerListener(this, this.gyroSensor, SensorManager.SENSOR_DELAY_GAME);
        } else if (!need && this.gyroRegistered) {
            stopGyro();
        }
    }

    private void stopGyro() {
        if (this.gyroRegistered && this.sensors != null) {
            this.sensors.unregisterListener(this);
        }
        this.gyroRegistered = false;
        this.gyroPrevTime = 0;
        this.gyroPrevRotation = -1;
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        if (!this.gyroOn || !this.active || !this.attached || this.editMode || this.dialogOpen) {
            this.gyroPrevTime = 0;
            return;
        }
        float x = event.values[0];
        float y = event.values[1];
        if (Float.isNaN(x) || Float.isNaN(y) || Float.isInfinite(x) || Float.isInfinite(y)) {
            this.gyroPrevTime = 0;
            return;
        }
        Display display = getDisplay();
        int rotation = display == null ? 1 : display.getRotation();
        // Angular velocity (rad/s) about the screen's up axis and right axis.
        float up;
        float right;
        switch (rotation) {
            case 1:
                up = x;
                right = -y;
                break;
            case 2:
                up = -y;
                right = -x;
                break;
            case 3:
                up = -x;
                right = y;
                break;
            default:
                up = y;
                right = x;
                break;
        }
        if (Math.abs(up) < 0.01f) {
            up = 0.0f;
        }
        if (Math.abs(right) < 0.01f) {
            right = 0.0f;
        }
        float dt = (event.timestamp - this.gyroPrevTime) * 1.0e-9f;
        boolean valid = this.gyroPrevTime != 0 && rotation == this.gyroPrevRotation && dt > 0.0f && dt <= 0.1f;
        float prevUp = this.gyroPrevUp;
        float prevRight = this.gyroPrevRight;
        this.gyroPrevTime = event.timestamp;
        this.gyroPrevRotation = rotation;
        this.gyroPrevUp = up;
        this.gyroPrevRight = right;
        if (!valid) {
            return;
        }
        // Turning the phone right (clockwise from above) gives negative up-axis
        // rotation and must move the view right; tilting the top away from you
        // (looking up) gives negative right-axis rotation and must move it up.
        float scale = GYRO_PIXELS_PER_RADIAN * this.gyroSens;
        float dx = -(up + prevUp) * 0.5f * dt * scale * (this.gyroInvertX ? -1.0f : 1.0f);
        float dy = -(right + prevRight) * 0.5f * dt * scale * (this.gyroInvertY ? -1.0f : 1.0f);
        if (dx != 0.0f || dy != 0.0f) {
            SDLActivity.onNativeMouse(this.mouseState, 2, dx, dy, true);
        }
    }

    // ------------------------------------------------------------- settings UI

    private abstract class Seek implements SeekBar.OnSeekBarChangeListener {
        abstract void changed(int progress);

        @Override
        public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
            if (fromUser) {
                changed(p);
            }
        }

        @Override
        public void onStartTrackingTouch(SeekBar s) {
        }

        @Override
        public void onStopTrackingTouch(SeekBar s) {
            saveSettings();
        }
    }

    private static String pct(float v) {
        return Math.round(v * 100.0f) + "%";
    }

    private static String times(float v) {
        return (Math.round(v * 100.0f) / 100.0f) + "x";
    }

    private void openSettings() {
        if (dialogOpen) {
            return;
        }
        releaseAll();
        final Context c = getContext();
        int pad = Math.round(16.0f * this.dp);
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad / 2, pad, 0);

        final TextView sizeLabel = new TextView(c);
        sizeLabel.setText("Tamaño de botones: " + pct(this.size));
        box.addView(sizeLabel);
        SeekBar sizeBar = new SeekBar(c);
        sizeBar.setMax(150);
        sizeBar.setProgress(Math.round(this.size * 100.0f) - 50);
        sizeBar.setOnSeekBarChangeListener(new Seek() {
            @Override
            void changed(int p) {
                TouchControls.this.size = (50 + p) / 100.0f;
                sizeLabel.setText("Tamaño de botones: " + pct(TouchControls.this.size));
                TouchControls.this.layout();
                TouchControls.this.invalidate();
            }
        });
        box.addView(sizeBar);

        final TextView lookLabel = new TextView(c);
        lookLabel.setText("Sensibilidad de la cámara: " + times(this.lookSens));
        box.addView(lookLabel);
        SeekBar lookBar = new SeekBar(c);
        lookBar.setMax(100);
        lookBar.setProgress(Math.round((float) (100.0 * Math.log(this.lookSens / 0.25f) / Math.log(16.0))));
        lookBar.setOnSeekBarChangeListener(new Seek() {
            @Override
            void changed(int p) {
                TouchControls.this.lookSens = clamp(0.25f * (float) Math.pow(16.0, p / 100.0), 0.25f, 4.0f);
                lookLabel.setText("Sensibilidad de la cámara: " + times(TouchControls.this.lookSens));
            }
        });
        box.addView(lookBar);

        CheckBox gyroBox = new CheckBox(c);
        gyroBox.setText(this.gyroSensor == null ? "Giroscopio (no disponible en este teléfono)" : "Apuntar con el giroscopio");
        gyroBox.setChecked(this.gyroOn);
        gyroBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                TouchControls.this.gyroOn = checked;
                TouchControls.this.saveSettings();
            }
        });
        box.addView(gyroBox);

        final TextView gyroLabel = new TextView(c);
        gyroLabel.setText("Sensibilidad del giroscopio: " + times(this.gyroSens));
        box.addView(gyroLabel);
        SeekBar gyroBar = new SeekBar(c);
        gyroBar.setMax(100);
        gyroBar.setProgress(Math.round((float) (100.0 * Math.log(this.gyroSens / 0.25f) / Math.log(16.0))));
        gyroBar.setOnSeekBarChangeListener(new Seek() {
            @Override
            void changed(int p) {
                TouchControls.this.gyroSens = clamp(0.25f * (float) Math.pow(16.0, p / 100.0), 0.25f, 4.0f);
                gyroLabel.setText("Sensibilidad del giroscopio: " + times(TouchControls.this.gyroSens));
            }
        });
        box.addView(gyroBar);

        CheckBox gyroX = new CheckBox(c);
        gyroX.setText("Invertir giroscopio horizontal");
        gyroX.setChecked(this.gyroInvertX);
        gyroX.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                TouchControls.this.gyroInvertX = checked;
                TouchControls.this.saveSettings();
            }
        });
        box.addView(gyroX);

        CheckBox gyroY = new CheckBox(c);
        gyroY.setText("Invertir giroscopio vertical");
        gyroY.setChecked(this.gyroInvertY);
        gyroY.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                TouchControls.this.gyroInvertY = checked;
                TouchControls.this.saveSettings();
            }
        });
        box.addView(gyroY);

        CheckBox invert = new CheckBox(c);
        invert.setText("Invertir eje vertical de la cámara");
        invert.setChecked(this.invertY);
        invert.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean checked) {
                TouchControls.this.invertY = checked;
                TouchControls.this.saveSettings();
            }
        });
        box.addView(invert);

        final TextView opacityLabel = new TextView(c);
        opacityLabel.setText("Opacidad de los botones: " + pct(this.opacity));
        box.addView(opacityLabel);
        SeekBar opacityBar = new SeekBar(c);
        opacityBar.setMax(70);
        opacityBar.setProgress(Math.round(this.opacity * 100.0f) - 30);
        opacityBar.setOnSeekBarChangeListener(new Seek() {
            @Override
            void changed(int p) {
                TouchControls.this.opacity = (30 + p) / 100.0f;
                opacityLabel.setText("Opacidad de los botones: " + pct(TouchControls.this.opacity));
                TouchControls.this.invalidate();
            }
        });
        box.addView(opacityBar);

        ScrollView scroll = new ScrollView(c);
        scroll.addView(box);

        dialogOpen = true;
        updateGyro();
        new AlertDialog.Builder(c)
            .setTitle("Controles táctiles")
            .setView(scroll)
            .setPositiveButton("Listo", null)
            .setNegativeButton("Editar disposición", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int which) {
                    TouchControls.this.enterEdit();
                }
            })
            .setNeutralButton("Restablecer", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int which) {
                    TouchControls.this.confirmReset();
                }
            })
            .setOnDismissListener(new DialogInterface.OnDismissListener() {
                @Override
                public void onDismiss(DialogInterface d) {
                    TouchControls.this.dialogOpen = false;
                    TouchControls.this.saveSettings();
                    TouchControls.this.updateGyro();
                }
            })
            .show();
    }

    private void confirmReset() {
        new AlertDialog.Builder(getContext())
            .setTitle("Restablecer")
            .setMessage("Se restauran tamaño, posición, sensibilidad y opacidad de todos los botones.")
            .setPositiveButton("Restablecer", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface d, int which) {
                    TouchControls.this.resetSettings();
                }
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    // ------------------------------------------------------------ layout editor

    private void enterEdit() {
        editMode = true;
        selected = null;
        releaseAll();
        updateGyro();
        invalidate();
    }

    private void exitEdit() {
        editMode = false;
        selected = null;
        dragPointer = -1;
        saveSettings();
        layout();
        releaseAll();
        updateGyro();
    }

    private static final int BAR_ITEMS = 4;

    private float barItemW() {
        return 84.0f * this.dp;
    }

    private float barGap() {
        return 6.0f * this.dp;
    }

    private float barH() {
        return 38.0f * this.dp;
    }

    private float barLeft() {
        float total = BAR_ITEMS * barItemW() + (BAR_ITEMS - 1) * barGap();
        return (getWidth() - total) / 2.0f;
    }

    private float barTop() {
        return (getHeight() - barH()) / 2.0f;
    }

    private int barHit(float x, float y) {
        if (y < barTop() || y > barTop() + barH()) {
            return -1;
        }
        for (int i = 0; i < BAR_ITEMS; i++) {
            float l = barLeft() + i * (barItemW() + barGap());
            if (x >= l && x <= l + barItemW()) {
                return i;
            }
        }
        return -1;
    }

    private void barAction(int item) {
        if (item == 0 || item == 1) {
            float step = item == 0 ? -0.1f : 0.1f;
            if (selected != null) {
                selected.scale = clamp(Math.round((selected.scale + step) * 10.0f) / 10.0f, 0.5f, 2.0f);
            } else {
                size = clamp(Math.round((size + step) * 10.0f) / 10.0f, 0.5f, 2.0f);
            }
            layout();
        } else if (item == 2) {
            if (selected != null) {
                selected.hidden = !selected.hidden;
            }
        } else {
            exitEdit();
            return;
        }
        saveSettings();
        invalidate();
    }

    private boolean editTouch(MotionEvent e) {
        int action = e.getActionMasked();
        int index = e.getActionIndex();
        switch (action) {
            case 0:
            case 5: {
                int id = e.getPointerId(index);
                float x = e.getX(index);
                float y = e.getY(index);
                int item = barHit(x, y);
                if (item >= 0) {
                    barAction(item);
                    return true;
                }
                if (dragPointer < 0) {
                    Button b = hit(x, y, true);
                    if (b != null) {
                        selected = b;
                        dragPointer = id;
                        dragDX = x - b.cx;
                        dragDY = y - b.cy;
                    } else {
                        selected = null;
                    }
                }
                invalidate();
                return true;
            }
            case 2: {
                if (dragPointer >= 0 && selected != null) {
                    for (int i = 0; i < e.getPointerCount(); i++) {
                        if (e.getPointerId(i) == dragPointer) {
                            int w = getWidth();
                            int h = getHeight();
                            float r = selected.r;
                            selected.cx = clamp(e.getX(i) - dragDX, r, Math.max(r, w - r));
                            selected.cy = clamp(e.getY(i) - dragDY, r, Math.max(r, h - r));
                            selected.fx = selected.cx / w;
                            selected.fy = selected.cy / h;
                        }
                    }
                }
                invalidate();
                return true;
            }
            case 1:
            case 3:
            case 6: {
                int id = e.getPointerId(index);
                if (id == dragPointer) {
                    dragPointer = -1;
                    saveSettings();
                }
                invalidate();
                return true;
            }
            default:
                return true;
        }
    }

    // ---------------------------------------------------------------- drawing

    private int fade(int color) {
        int a = Math.round(((color >>> 24) & 0xFF) * this.opacity);
        return (a << 24) | (color & 0xFFFFFF);
    }

    private final class CanvasPen implements TouchIcons.Pen {
        private final RectF box;
        Canvas c;
        private final Path path;

        private CanvasPen() {
            this.path = new Path();
            this.box = new RectF();
        }

        @Override
        public void line(float x1, float y1, float x2, float y2) {
            this.c.drawLine(x1, y1, x2, y2, TouchControls.this.icon);
        }

        @Override
        public void circle(float x, float y, float r, boolean filled) {
            TouchControls.this.icon.setStyle(filled ? Paint.Style.FILL : Paint.Style.STROKE);
            this.c.drawCircle(x, y, r, TouchControls.this.icon);
            TouchControls.this.icon.setStyle(Paint.Style.STROKE);
        }

        @Override
        public void arc(float x, float y, float r, float start, float sweep) {
            this.box.set(x - r, y - r, x + r, y + r);
            this.c.drawArc(this.box, start, sweep, false, TouchControls.this.icon);
        }

        @Override
        public void polygon(float[] pts) {
            this.path.reset();
            this.path.moveTo(pts[0], pts[1]);
            for (int i = 2; i < pts.length; i += 2) {
                this.path.lineTo(pts[i], pts[i + 1]);
            }
            this.path.close();
            TouchControls.this.icon.setStyle(Paint.Style.FILL);
            this.c.drawPath(this.path, TouchControls.this.icon);
            TouchControls.this.icon.setStyle(Paint.Style.STROKE);
        }

        @Override
        public void rect(float l, float t, float r, float b) {
            TouchControls.this.icon.setStyle(Paint.Style.FILL);
            this.c.drawRoundRect(l, t, r, b, 2.0f * TouchControls.this.dp, 2.0f * TouchControls.this.dp, TouchControls.this.icon);
            TouchControls.this.icon.setStyle(Paint.Style.STROKE);
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        this.stroke.setStrokeWidth(1.5f * this.dp);
        this.icon.setStrokeCap(Paint.Cap.ROUND);
        this.icon.setStrokeJoin(Paint.Join.ROUND);
        this.pen.c = canvas;
        for (int i = 0; i < buttons.length; i++) {
            Button b = buttons[i];
            if (b.hidden && !editMode) {
                continue;
            }
            boolean ghost = b.hidden;
            this.stroke.setColor(ghost ? EDIT_HIDDEN : fade(RING));
            if (editMode && b == selected) {
                this.stroke.setColor(EDIT_SELECTED);
                this.stroke.setStrokeWidth(3.0f * this.dp);
            } else {
                this.stroke.setStrokeWidth(1.5f * this.dp);
            }
            if (!ghost) {
                this.fill.setColor(fade(b.pointer >= 0 ? DISC_PRESSED : DISC));
                canvas.drawCircle(b.cx, b.cy, b.r, this.fill);
            }
            canvas.drawCircle(b.cx, b.cy, b.r, this.stroke);
            if (!ghost) {
                this.icon.setStrokeWidth(Math.max(this.dp * 2.0f, b.r * 0.09f));
                this.icon.setStyle(Paint.Style.STROKE);
                this.icon.setColor(fade(ICON_SHADOW));
                TouchIcons.draw(this.pen, b.icon, b.cx + this.dp, b.cy + this.dp, b.r);
                this.icon.setColor(fade(ICON));
                TouchIcons.draw(this.pen, b.icon, b.cx, b.cy, b.r);
            }
        }
        this.stroke.setStrokeWidth(this.dp * 2.0f);
        this.stroke.setColor(fade(RING));
        if (editMode) {
            drawEditBar(canvas);
        } else {
            drawStick(canvas, this.movePointer, this.moveX, this.moveY, this.moveDX, this.moveDY, stickRadius());
            drawGear(canvas);
        }
    }

    private void drawGear(Canvas canvas) {
        float x = gearX();
        float y = gearY();
        float r = gearR();
        this.fill.setColor(fade(gearPointer >= 0 ? DISC_PRESSED : DISC));
        canvas.drawCircle(x, y, r, this.fill);
        this.stroke.setStrokeWidth(1.5f * this.dp);
        canvas.drawCircle(x, y, r, this.stroke);
        this.icon.setStrokeWidth(Math.max(this.dp * 1.5f, r * 0.12f));
        this.icon.setStyle(Paint.Style.STROKE);
        this.icon.setColor(fade(ICON));
        canvas.drawCircle(x, y, r * 0.34f, this.icon);
        for (int i = 0; i < 8; i++) {
            double a = i * Math.PI / 4.0;
            float cx = (float) Math.cos(a);
            float cy = (float) Math.sin(a);
            canvas.drawLine(x + cx * r * 0.52f, y + cy * r * 0.52f, x + cx * r * 0.78f, y + cy * r * 0.78f, this.icon);
        }
    }

    private void drawEditBar(Canvas canvas) {
        float h = barH();
        float top = barTop();
        String[] labels = new String[]{
            "TAMAÑO −", "TAMAÑO +", (selected != null && selected.hidden) ? "MOSTRAR" : "OCULTAR", "LISTO"};
        this.text.setTextSize(11.0f * this.dp);
        for (int i = 0; i < BAR_ITEMS; i++) {
            float l = barLeft() + i * (barItemW() + barGap());
            this.fill.setColor(EDIT_BG);
            canvas.drawRoundRect(l, top, l + barItemW(), top + h, 8.0f * this.dp, 8.0f * this.dp, this.fill);
            this.text.setColor(-1);
            canvas.drawText(labels[i], l + barItemW() / 2.0f, top + h / 2.0f + 4.0f * this.dp, this.text);
        }
        String hint;
        if (selected == null) {
            hint = "Toca un botón para elegirlo y arrástralo. TAMAÑO cambia todos.";
        } else {
            hint = selected.label + " · tamaño " + pct(selected.scale) + (selected.hidden ? " · oculto" : "");
        }
        float tw = Math.min(getWidth() - 16.0f * this.dp, 420.0f * this.dp);
        float hl = (getWidth() - tw) / 2.0f;
        float ht = top - 36.0f * this.dp;
        this.fill.setColor(EDIT_BG);
        canvas.drawRoundRect(hl, ht, hl + tw, ht + 28.0f * this.dp, 8.0f * this.dp, 8.0f * this.dp, this.fill);
        this.text.setColor(-1);
        canvas.drawText(hint, getWidth() / 2.0f, ht + 18.0f * this.dp, this.text);
    }

    private void drawStick(Canvas canvas, int pointer, float x, float y, float dx, float dy, float radius) {
        if (pointer >= 0) {
            this.fill.setColor(fade(STICK_BASE));
            canvas.drawCircle(x, y, radius, this.fill);
            canvas.drawCircle(x, y, radius, this.stroke);
            this.fill.setColor(fade(STICK_KNOB));
            canvas.drawCircle((dx * radius) + x, (dy * radius) + y, 0.4f * radius, this.fill);
        }
    }
}
