package com.halo.decomp;

final class TouchIcons {
    static final int BACK = 10;
    static final int CROUCH = 9;
    static final int FIRE = 0;
    static final int GRENADE = 5;
    static final int GRENADE_SWAP = 6;
    static final int JUMP = 1;
    static final int LIGHT = 8;
    static final int MELEE = 3;
    static final int PAUSE = 11;
    static final int RELOAD = 2;
    static final int SWAP_WEAPON = 4;
    static final int ZOOM = 7;

    interface Pen {
        void arc(float f, float f2, float f3, float f4, float f5);

        void circle(float f, float f2, float f3, boolean z);

        void line(float f, float f2, float f3, float f4);

        void polygon(float[] fArr);

        void rect(float f, float f2, float f3, float f4);
    }

    private TouchIcons() {
    }

    static void draw(Pen pen, int i, float f, float f2, float f3) {
        switch (i) {
            case 0:
                pen.circle(f, f2, 0.34f * f3, false);
                pen.circle(f, f2, 0.07f * f3, true);
                float f4 = 0.5f * f3;
                float f5 = 0.74f * f3;
                pen.line(f - f5, f2, f - f4, f2);
                pen.line(f + f4, f2, f + f5, f2);
                pen.line(f, f2 - f5, f, f2 - f4);
                pen.line(f, f4 + f2, f, f5 + f2);
                break;
            case 1:
                chevron(pen, f, f2 - (0.28f * f3), 0.42f * f3, 0.3f * f3, true);
                chevron(pen, f, f2 + (0.06f * f3), 0.42f * f3, 0.3f * f3, true);
                break;
            case 2:
                float f6 = 0.4f * f3;
                float radians = (float) Math.toRadians(25.0f + 285.0f);
                pen.arc(f, f2, f6, 25.0f, 285.0f);
                head(pen, f + (((float) Math.cos(radians)) * f6), f2 + (((float) Math.sin(radians)) * f6), -((float) Math.sin(radians)), (float) Math.cos(radians), 0.22f * f3);
                break;
            case 3:
                int i2 = 0;
                while (true) {
                    int i3 = i2;
                    if (i3 >= 8) {
                        break;
                    } else {
                        double radians2 = Math.toRadians((i3 * 45) + 22.5d);
                        float f7 = (i3 % 2 == 0 ? 0.72f : 0.5f) * f3;
                        float f8 = 0.16f * f3;
                        pen.line((((float) Math.cos(radians2)) * f8) + f, (f8 * ((float) Math.sin(radians2))) + f2, (((float) Math.cos(radians2)) * f7) + f, (f7 * ((float) Math.sin(radians2))) + f2);
                        i2 = i3 + 1;
                    }
                }
            case 4:
                float f9 = 0.44f * f3;
                float f10 = 0.2f * f3;
                pen.line(f - f9, f2 - f10, f + f9, f2 - f10);
                head(pen, f + f9, f2 - f10, 1.0f, 0.0f, 0.2f * f3);
                pen.line(f + f9, f2 + f10, f - f9, f2 + f10);
                head(pen, f - f9, f2 + f10, -1.0f, 0.0f, 0.2f * f3);
                break;
            case GRENADE /* 5 */:
                grenade(pen, f, f2, f3, 1.0f);
                break;
            case GRENADE_SWAP /* 6 */:
                grenade(pen, f, f2 - (0.16f * f3), f3, 0.66f);
                float f11 = 0.34f * f3;
                float f12 = f2 + (0.5f * f3);
                pen.line(f - f11, f12, f + f11, f12);
                head(pen, f + f11, f12, 1.0f, 0.0f, 0.15f * f3);
                head(pen, f - f11, f12, -1.0f, 0.0f, 0.15f * f3);
                break;
            case ZOOM /* 7 */:
                float f13 = f - (0.1f * f3);
                float f14 = f2 - (0.1f * f3);
                float f15 = 0.3f * f3;
                pen.circle(f13, f14, f15, false);
                pen.line((0.72f * f15) + f13, (f15 * 0.72f) + f14, (0.46f * f3) + f, (0.46f * f3) + f2);
                pen.line(f13 - (0.13f * f3), f14, (0.13f * f3) + f13, f14);
                pen.line(f13, f14 - (0.13f * f3), f13, f14 + (0.13f * f3));
                break;
            case 8:
                float f16 = f2 - (0.08f * f3);
                float f17 = 0.24f * f3;
                pen.circle(f, f16, f17, false);
                pen.line(f - (0.12f * f3), (0.26f * f3) + f2, (0.12f * f3) + f, (0.26f * f3) + f2);
                pen.line(f - (0.08f * f3), (0.4f * f3) + f2, (0.08f * f3) + f, (0.4f * f3) + f2);
                float f18 = (0.1f * f3) + f17;
                float f19 = (0.24f * f3) + f17;
                int length = new int[]{-90, -45, -135, 0, 180}.length;
                for (int i4 = 0; i4 < length; i4++) {
                    double radians3 = Math.toRadians(r8[i4]);
                    pen.line((((float) Math.cos(radians3)) * f18) + f, (((float) Math.sin(radians3)) * f18) + f16, (((float) Math.cos(radians3)) * f19) + f, (((float) Math.sin(radians3)) * f19) + f16);
                }
                break;
            case CROUCH /* 9 */:
                chevron(pen, f, f2 - (0.22f * f3), 0.42f * f3, 0.3f * f3, false);
                chevron(pen, f, f2 + (0.12f * f3), 0.42f * f3, 0.3f * f3, false);
                break;
            case BACK /* 10 */:
                float f20 = 0.42f * f3;
                pen.line(f + f20, f2, f - f20, f2);
                head(pen, f - f20, f2, -1.0f, 0.0f, 0.26f * f3);
                break;
            case PAUSE /* 11 */:
                pen.rect(f - (0.32f * f3), f2 - (0.36f * f3), f - (0.08f * f3), (0.36f * f3) + f2);
                pen.rect((0.08f * f3) + f, f2 - (0.36f * f3), (0.32f * f3) + f, (0.36f * f3) + f2);
                break;
        }
    }

    private static void chevron(Pen pen, float f, float f2, float f3, float f4, boolean z) {
        float f5 = z ? 1.0f : -1.0f;
        pen.line(f - f3, (f5 * f4) + f2, f, f2);
        pen.line(f, f2, f + f3, (f5 * f4) + f2);
    }

    private static void head(Pen pen, float f, float f2, float f3, float f4, float f5) {
        float hypot = (float) Math.hypot(f3, f4);
        float f6 = f3 / hypot;
        float f7 = f4 / hypot;
        float f8 = -f7;
        pen.polygon(new float[]{(f6 * f5 * 0.6f) + f, (f7 * f5 * 0.6f) + f2, (f - ((f6 * f5) * 0.7f)) + (f8 * f5), (f2 - ((f7 * f5) * 0.7f)) + (f6 * f5), (f - ((f6 * f5) * 0.7f)) - (f8 * f5), (f2 - ((f7 * f5) * 0.7f)) - (f6 * f5)});
    }

    private static void grenade(Pen pen, float f, float f2, float f3, float f4) {
        float f5 = 0.34f * f3 * f4;
        float f6 = (0.12f * f3 * f4) + f2;
        pen.circle(f, f6, f5, false);
        pen.line(f - ((0.11f * f3) * f4), f6 - f5, f - ((0.11f * f3) * f4), f2 - ((0.5f * f3) * f4));
        pen.line((0.11f * f3 * f4) + f, f6 - f5, (0.11f * f3 * f4) + f, f2 - ((0.5f * f3) * f4));
        pen.line(f - ((0.11f * f3) * f4), f2 - ((0.5f * f3) * f4), (0.11f * f3 * f4) + f, f2 - ((0.5f * f3) * f4));
        pen.line((0.11f * f3 * f4) + f, f2 - ((0.44f * f3) * f4), (0.42f * f3 * f4) + f, f2 - ((0.3f * f3) * f4));
        pen.circle(f - ((0.3f * f3) * f4), f2 - ((0.5f * f3) * f4), 0.1f * f3 * f4, false);
    }
}
